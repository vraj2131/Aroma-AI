import pymysql
from typing import List, Dict, Any
from config import *
from csv_config import getCSVDetails
from CSVEditor import CSVEditor
from generic_function import connect_db, get_sharepoint_configs

class QuestionnaireStatusLogReport:
    def __init__(self, cursor, db_conn) -> None:
        self.cursor = cursor
        self.db_conn = db_conn


    def get_db_data(self,db_name):
        self.cursor.execute(f'SELECT * FROM {db_name} WHERE cron_status=0')
        return self.cursor.fetchall()

    def update_kbox_status(self, kbox_number, status=2):
        self.cursor.execute(f"UPDATE kbox_ai_report_list SET cron_status=%s WHERE kbox_number=%s",[status,kbox_number])

    def get_kbox_db_connection(self, kbox_number):
        response = connect_db(oneaudit_db_host, oneaudit_db_user, oneaudit_db_pw, f"{kbox_number}_db")
        oneaudit_db_conn = None
        oneaudit_cursor = None
        if response["success"] == "true":
            oneaudit_db_conn = response["data"]
            oneaudit_cursor = oneaudit_db_conn.cursor(pymysql.cursors.DictCursor)

        return oneaudit_db_conn, oneaudit_cursor


    def update_kbox_ai_report_cron_status():

        self.cursor.execute('SELECT * FROM kbox_ai_report_list')
        data = self.cursor.fetchall()

        where_clause_list = ["kbox_number","dashboard_id","year","instance_id"]
        where_clause_and = []
        for row in data:
            where_clause =' AND '.join([f"{key}={row[key]}" if isinstance(row[key], int) else f"{key}='{row[key]}'" for key in where_clause_list])
            where_clause_and.append(f"({where_clause})")
        whereclause_str = " OR ".join(where_clause_and)

        query = f"""UPDATE kbox_ai_report_list SET cron_status = 2 WHERE {whereclause_str}"""
        self.cursor.execute(query)
        self.db_conn.commit()

    def get_regln_id_list(self, oneaudit_db_conn, oneaudit_cursor, kbox_number):
        oneaudit_cursor.execute("SELECT regln_id FROM evs_regln_master")
        regln_id_list = oneaudit_cursor.fetchall()
        regln_id_list = [regln_id["regln_id"] for regln_id in regln_id_list]
        return regln_id_list

    def get_ev_link_master_data(self, oneaudit_cursor, instance_id, link_code):
        query = f"SELECT inst_id, link_id FROM ev_link_master WHERE inst_id ={instance_id} AND link_code='{link_code}'"
        print(query)
        oneaudit_cursor.execute(query)
        records = oneaudit_cursor.fetchall()
        # print(records)
        if records:
            return records[0]

        return

    def get_regln_details(self, oneaudit_cursor, instance_id, link_id):
        query = f"SELECT rm.regln_id, inst_id, link_id, regln_name FROM evs_regln_master rm JOIN ev_link_regln_map lrm ON rm.regln_id=lrm.regln_id WHERE inst_id={instance_id} AND link_id='{link_id}'"
        oneaudit_cursor.execute(query)
        records = oneaudit_cursor.fetchall()
        if records:
            return records[0]

        return

    def get_regln_details_with_dash(self, oneaudit_cursor, dashboard_id, instance_id, reg_name):

        query = f"SELECT r.regln_id, r.regln_name FROM ev_inst_dash_map d JOIN evs_regln_master r ON r.regln_id = d.regln_id WHERE  d.inst_id =%s AND r.regln_name =%s"
        oneaudit_cursor.execute(query,[instance_id,reg_name])
        records = oneaudit_cursor.fetchall()
        if records:
            return records[0]

        return

    def get_quest_details(self, oneaudit_cursor, link_id):
        query = f"SELECT tqm.tpl_ques_id as tpl_ques_id, tqm.cc_ques_no as cc_ques_no FROM ev_link_tpl_ques_map ltq JOIN evs_tpl_ques_map tqm ON ltq.tpl_ques_id=tqm.tpl_ques_id WHERE ltq.link_id={link_id}"
        oneaudit_cursor.execute(query)
        records = oneaudit_cursor.fetchall()
        if records:
            return records

        return []

    def get_quest_details_new(self, oneaudit_cursor, instance_id, link_code):
    
        query = f"SELECT tqm.tpl_ques_id as tpl_ques_id, tqm.cc_ques_no as cc_ques_no FROM ev_link_master lm JOIN evs_tpl_ques_map tqm ON tqm.tpl_id = lm.tpl_id WHERE lm.inst_id =%s AND lm.link_code =%s"
        oneaudit_cursor.execute(query,[instance_id,link_code])
        records = oneaudit_cursor.fetchall()
        if records:
            return records

        return []

    def process_status_log(self, kbox_details):

        # change the database as a active database
        kbox = kbox_details["kbox_number"]
        assessor = kbox_details['assessor']
        project_id = kbox_details['project_id']
        oneaudit_db_conn, oneaudit_cursor = self.get_kbox_db_connection(kbox)

        kbox_number = ''.join(filter(lambda i: i.isdigit(), kbox)) #get numeric values

        params = {}
        where = ""


        # check if there is any update at the kbox end
        sql = "SELECT sut.kbox, sut.status_updated_on FROM client_global_db.status_update_track AS sut WHERE sut.`status`= 1 AND sut.kbox = 'clientk" + kbox_number + "' " + where
        if len(params) > 0:
            oneaudit_cursor.execute(sql, params)
        else:
            oneaudit_cursor.execute(sql)

        result = []
        if oneaudit_cursor.rowcount > 0:
            ev_link_master_data = self.get_ev_link_master_data(oneaudit_cursor, kbox_details["instance_id"], kbox_details["link_code"])
            if not ev_link_master_data:
                return
            inst_id = ev_link_master_data["inst_id"]
            link_id = ev_link_master_data["link_id"]
            regln_details = self.get_regln_details(oneaudit_cursor, inst_id, link_id)

            # regln_details = self.get_regln_details_with_dash(oneaudit_cursor, kbox_details['dashboard_id'], inst_id,kbox_details["regulation"])
            print("regln_details", regln_details)

            if regln_details is None:
                return []

            # ques_detail_list = self.get_quest_details(oneaudit_cursor, link_id)
            # ques_detail_list = self.get_quest_details_new(oneaudit_cursor, kbox_details['dashboard_id'], inst_id,kbox_details["regulation"])
            ques_detail_list = self.get_quest_details_new(oneaudit_cursor, inst_id,kbox_details["link_code"])
            # Queries to get following data

            csv_data = []
            if len(ques_detail_list) > 0:
                for ques_details in ques_detail_list:
                    ai_full_partial = "Full"
                    # Get the details for current year: If question is passed, accepted and iterations.

                    # Get QA ierations
                    current_AQA_TO_UE = 0
                    sql = "SELECT * FROM ev_status_track WHERE inst_id = %s AND regln_id = %s AND tpl_ques_id = %s AND status=1 ORDER BY status_track_id ASC "
                    oneaudit_cursor.execute(sql, [str(inst_id), str(regln_details["regln_id"]), str(ques_details["tpl_ques_id"])])
                    if oneaudit_cursor.rowcount > 0:
                        res = oneaudit_cursor.fetchall()
                        for row in res:
                            if row["qa_interations"] > 0:
                                current_AQA_TO_UE = int(row["qa_interations"]) - 1
                            else:
                                current_AQA_TO_UE = 0

                    current_UE_TO_II = 0
                    curr_UE_TO_ABA_OR_AQA = 0
                    curr_UE_TO_PASS = 0
                    curr_AQA_TO_PASS = 0
                    curr_start_id  = ""
                    curr_accept_id = ""
                    curr_qa_start_id = ""
                    curr_pass_id = ""
                    curr_regln_level_status_id_user = 0
                    sql = "SELECT `status_log_id`, `int_status_id`, `user_id` FROM ev_status_log WHERE inst_id = %s AND regln_id = %s AND tpl_ques_id = %s AND status=1"
                    oneaudit_cursor.execute(sql, [str(inst_id), str(regln_details["regln_id"]), str(ques_details["tpl_ques_id"])])
                    #print(oneaudit_cursor._last_executed)
                    if oneaudit_cursor.rowcount > 0:
                        res = oneaudit_cursor.fetchall()
                        for row in res:
                            if str(row["int_status_id"]) == '2' and curr_start_id == "":
                                curr_start_id = str(row["status_log_id"])
                            if ((str(row["int_status_id"]) == '4' or str(row["int_status_id"]) == '5') and curr_accept_id == ""):
                                curr_accept_id = str(row["status_log_id"])
                                curr_regln_level_status_id_user = str(row["user_id"])
                            if ((str(row["int_status_id"]) == '6' or str(row["int_status_id"]) == '7') and curr_pass_id == ""):
                                curr_pass_id = str(row["status_log_id"])
                            if str(row["int_status_id"]) == '3':
                                current_UE_TO_II = current_UE_TO_II + 1
                            if ((str(row["int_status_id"]) == '5') and curr_qa_start_id == ""):
                                curr_qa_start_id = str(row["status_log_id"])

                        Was_Pre_Check_viewed_by_Assessor = "No"
                        if curr_start_id != "" and curr_accept_id != "":
                            sql = "SELECT a.int_status_id, a.created_on, b.created_on, b.int_status_id, TIMESTAMPDIFF(DAY, a.created_on, b.created_on) AS timedifference \
                                    FROM ev_status_log b, ev_status_log a \
                                    WHERE a.status_log_id = %s AND b.status_log_id = %s"
                            oneaudit_cursor.execute(sql, [curr_start_id, curr_accept_id])
                            #print(oneaudit_cursor._last_executed)
                            if oneaudit_cursor.rowcount > 0:
                                res = oneaudit_cursor.fetchall()
                                for row in res:
                                    curr_UE_TO_ABA_OR_AQA = row["timedifference"]

                            if int(curr_UE_TO_ABA_OR_AQA) > 0:
                                sql = "SELECT * FROM ev_ai_precheck_view_log WHERE inst_id = %s AND cc_ques_no = %s and user_id = %s"
                                oneaudit_cursor.execute(sql, [str(inst_id), str(ques_details["cc_ques_no"]), curr_regln_level_status_id_user])
                                #print(oneaudit_cursor._last_executed)
                                if oneaudit_cursor.rowcount > 0:
                                    Was_Pre_Check_viewed_by_Assessor = "Yes"

                        if curr_start_id != "" and curr_pass_id != "":
                            sql = "SELECT a.int_status_id, a.created_on, b.created_on, b.int_status_id, TIMESTAMPDIFF(DAY, a.created_on, b.created_on) AS timedifference \
                                    FROM ev_status_log b, ev_status_log a \
                                    WHERE a.status_log_id = %s AND b.status_log_id = %s AND a.status = 1 AND b.status=1 "
                            oneaudit_cursor.execute(sql, [curr_start_id, curr_pass_id])
                            #print(oneaudit_cursor._last_executed)
                            if oneaudit_cursor.rowcount > 0:
                                res = oneaudit_cursor.fetchall()
                                for row in res:
                                    curr_UE_TO_PASS = row["timedifference"]

                        if curr_qa_start_id != "" and curr_pass_id != "":
                            sql = "SELECT a.int_status_id, a.created_on, b.created_on, b.int_status_id, TIMESTAMPDIFF(DAY, a.created_on, b.created_on) AS timedifference \
                                    FROM ev_status_log b, ev_status_log a \
                                    WHERE a.status_log_id = %s AND b.status_log_id = %s AND a.status = 1 AND b.status=1"
                            oneaudit_cursor.execute(sql, [curr_qa_start_id, curr_pass_id])
                            #print(oneaudit_cursor._last_executed)
                            if oneaudit_cursor.rowcount > 0:
                                res = oneaudit_cursor.fetchall()
                                for row in res:
                                    curr_AQA_TO_PASS = row["timedifference"]

                    csv_data.append([
                        kbox_number,
                        project_id,
                        kbox_details['dashboard_id'],
                        kbox_details["dashboard_name"],
                        ques_details["cc_ques_no"],
                        regln_details["regln_name"],
                        kbox_details["link_code"],
                        assessor,
                        current_UE_TO_II,
                        current_AQA_TO_UE,
                        curr_UE_TO_ABA_OR_AQA,
                        curr_AQA_TO_PASS,
                        curr_UE_TO_PASS,
                    ])

                return csv_data

        return []


    def write_data_to_sharepoint(self):

        response = {'error':'', 'msg':""}

        # report_config = getCustomEReportheader('ai_archive_report')
        report_config = {
            "script_folder": 'Database Files', ## decide later
            "sub_folder": 'AI Reports',
            "csv_filename": "ai_archive_report.csv",
            "csv_header":{
                'Kbox Number': 0,
                'Project Id': 1,
                'Dashboard Id': 2,
                'Dashboard Name': 3,
                'Question Number': 4,
                'Regulation': 5,
                'link Code': 6,
                'Assessor': 7,
                'Customer Iteration - For all the questions Iterations (Under Evaluation to Incomplete Information in 1 iteration)': 8,
                'Assessor Iterations - For all the questions Iterations (Assigned for QA to Under Evaluation is 1 iteration)': 9,
                'Accept Time in days (Under Evaluation to Accepted by Assessor/Assigned to QA)': 10,
                'Time in days (Assigned for QA to Pass/Pass with comments)': 11,
                'Total Time in days - (Under Evaluation to Pass/Pass with Comments)': 12
            }
        }

        ## Get sharepoint configs ##
        sharepoint_configs = get_sharepoint_configs('BI')

        report_config.update({"sharepoint_host":sharepoint_host, 'sharepoint_site_url':sharepoint_host+"/sites/"+sharepoint_configs['site_name'],"doc_base_library":sharepoint_configs['doc_base_library']})


        csv_data = self.get_report_data()

        print(f"Total CSV Data: {len(csv_data)}")

        if len(csv_data)>0:
            # ## object invokation
            fn_obj = CSVEditor(report_config)

            ## Check if file exist
            if fn_obj.csvExist():
                csv_created = fn_obj.deleteOldCSV(fn_obj.s3_file_name)

            csv_created = fn_obj.createCSVWithHeaders()
            s3_file_name = fn_obj.writeDataToCSV(csv_data)
            response['error'] = fn_obj.upload_s3_report_to_sharepoint('BI')
            response['msg'] = s3_file_name

        else:
            response['msg'] = "No data found for report"

        return response

    def process(self):
        #store kbox list from kbox_ai_report_list
        kbox_data = self.get_db_data("kbox_ai_report_list")
        final_csv_data = []
        for kbox_details in kbox_data:
            self.update_kbox_status(kbox_details["kbox_number"], 2) # Inprogress
            csv_data = self.process_status_log(kbox_details)
            final_csv_data.extend(csv_data)
        self.write_data_to_sharepoint(final_csv_data)
        for kbox_details in kbox_data:
            self.update_kbox_status(kbox_details["kbox_number"], 1) # Completed
        self.db_conn.commit()

    def prepare_kbox_list(self):
        try:
            self.cursor.execute("TRUNCATE TABLE kbox_ai_report_list")
            self.db_conn.commit()

            sql_query = """
                INSERT INTO kbox_ai_report_list (
                    dashboard_id,
                    kbox_number,
                    project_id,
                    dashboard_name,
                    year,
                    instance_id,
                    link_code,
                    regulation,
                    assessor,
                    cron_status
                )
                SELECT DISTINCT m.dashboard_id,
                    m.kbox_name AS kbox_number,
                t.project_id,
                c.dash_config_name AS dashboard_name, YEAR(c.test_date) AS YEAR, CAST(m.controlsheet AS SIGNED) AS instance_id, JSON_UNQUOTE(JSON_EXTRACT(m.controlsheet_details, '$.link_href')) AS link_code,
                    m.regulation,
                    c.assessor,
                    0 AS cron_status
                FROM
                    kbox_dashboard_controlsheet_mapping m
                LEFT JOIN cw_configuration c ON c.config_id = m.dashboard_id
                LEFT JOIN project_config_mapping cm ON cm.config_id = c.config_id
                LEFT JOIN cw_project_tickets t ON t.project_id = cm.project_id
                WHERE
                m.controlsheet NOT LIKE '%ai%' AND c.config_type='Dashboard Configuration Details'
                AND cm.department NOT IN ('Cybersecurity Services','Pro Services')
                AND t.summary = 'Kick-off' AND t.phase_name = 'Kick-Off and Strategy'
                AND JSON_UNQUOTE(JSON_EXTRACT(t.milestone_data, '$.actual_rr')) LIKE '%2023%'
                """
            self.cursor.execute(sql_query)
            self.db_conn.commit()
            return True

        except Exception as e:
            print(f"Error: {e}")
            return False


    def check_cron_status(self):
        pending_entries = self.get_db_data_count("kbox_ai_report_list")

        return 1 if pending_entries > 0 else 0

    def get_pending_records(self, limit=8):
        # Your implementation for getting pending records (kbox_numbers) with a specified limit
        self.cursor.execute(f'SELECT distinct(kbox_number) FROM kbox_ai_report_list WHERE cron_status = 0 LIMIT {limit}')
        result = self.cursor.fetchall()

        kbox_numbers = [row['kbox_number'] for row in result]
        return kbox_numbers


    def pull_archive_data(self,kbox_number):
        #store kbox list from kbox_ai_report_list
        kbox_data = self.get_db_data_for_kbox(kbox_number)

        final_csv_data = []
        for kbox_details in kbox_data:
            self.update_kbox_status(kbox_details["kbox_number"], 2) # Inprogress
            csv_data = self.process_status_log(kbox_details)
            if csv_data:
                final_csv_data.extend(csv_data)
        self.insert_data(final_csv_data)
        for kbox_details in kbox_data:
            self.update_kbox_status(kbox_details["kbox_number"], 1) # Completed
        self.db_conn.commit()

    def get_db_data_for_kbox(self,kbox):

        self.cursor.execute(f'SELECT * FROM kbox_ai_report_list WHERE cron_status=0 and kbox_number=%s',[kbox])
        return self.cursor.fetchall()

    def get_db_data_count(self, db_name):
        self.cursor.execute(f'SELECT COUNT(*) as pending_entries FROM {db_name} WHERE cron_status=0')
        result = self.cursor.fetchone()

        # Extract the value of 'pending_entries'
        pending_entries = result['pending_entries'] if result else 0

        return pending_entries

    def insert_data(self, csv_data):
        insert_query = """
        INSERT INTO `kbox_ai_archive_report_data` (
            `kbox_number`,
            `project_id`,
            `dashboard_id`,
            `dashboard_name`,
            `question_number`,
            `regulation`,
            `link_code`,
            `assessor`,
            `customer_iterations`,
            `assessor_iterations`,
            `accept_time_days`,
            `qa_time_days`,
            `total_time_days`
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        try:
            if csv_data:
                for row in csv_data:

                    self.cursor.execute(insert_query, row)
                self.db_conn.commit()
        except Exception as e:
            # Handle the exception (e.g., log the error, print a message, etc.)
            print(f"Error during data insertion: {e}")

    def get_report_data(self):

        csv_data = []

        self.cursor.execute("""
            SELECT
                kbox_number,
                project_id,
                dashboard_id,
                dashboard_name,
                question_number,
                regulation,
                link_code,
                assessor,
                customer_iterations,
                assessor_iterations,
                accept_time_days,
                qa_time_days,
                total_time_days
            FROM kbox_ai_archive_report_data_19March2024
        """)

        rows = self.cursor.fetchall()

        for row in rows:

            csv_data.append([row["kbox_number"],row["project_id"],row["dashboard_id"],row["dashboard_name"],row["question_number"],row["regulation"],row["link_code"],row["assessor"],row["customer_iterations"],row["assessor_iterations"],row["accept_time_days"],row["qa_time_days"],row["total_time_days"]])
        return csv_data