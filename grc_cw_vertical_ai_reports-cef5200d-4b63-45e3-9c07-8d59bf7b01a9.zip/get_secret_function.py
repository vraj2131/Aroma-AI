import boto3
import base64
import json
import os

from botocore.exceptions import ClientError

region_name = os.environ["SECRET_REGION_NAME"]
db_secret_name = os.environ["DB_SECRET_NAME"]
sharepoint_secret_name = os.environ["SHAREPOINT_SECRET_NAME"]

oa_db_secret_name = os.environ["OA_DB_SECRET"]
cchub_secret_name = 'dev/cchub/api'


def get_mysql_secret():
    return get_secret(db_secret_name)

def get_sharepoint_secret():
    return get_secret(sharepoint_secret_name)

def get_oa_db_secret():
    return get_secret(oa_db_secret_name)
    
def get_cchub_secret():
    return get_secret(cchub_secret_name)

def get_secret(secret_name):

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    return_config = {}
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )

    except ClientError as e:
        print(e.response['Error']['Message'])

    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.

        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            secret_details = json.loads(secret)
            # configs = json.loads(secret_details['details'])
            # return_config = configs
            return_config = secret_details
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            return_config = decoded_binary_secret

    return return_config
