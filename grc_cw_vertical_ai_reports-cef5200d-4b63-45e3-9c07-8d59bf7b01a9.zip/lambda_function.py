import time

import json
import traceback

import pymysql

from process_manager import ProcessManager
from generic_function import connect_db, calculate_x_days_before_today
from error_notification import draft_failure_email
from oa_services import OASetup
from questionnaire_status_log import QuestionnaireStatusLogReport
from datetime import datetime, timedelta
from feedback_report_processor import FeedbackReportProcessor

from ReportHandler import ReportHandler
from table_processor import TableProcessor

def lambda_handler(event, context):
    response = connect_db()
    print(response)
    if response["success"] == "true":
        todo = ''
        try:
            db_conn = response["data"]
            cursor = db_conn.cursor(pymysql.cursors.DictCursor)


            if 'todo' in event:
                todo = event["todo"]

            oai = OASetup()
            oa_mgr = ProcessManager(db_conn, cursor, oai)
            if todo == "is_report_pending":
                return oa_mgr.has_report_pending()

            elif todo == "get_pending_report":
                data = oa_mgr.get_pending_report_details()
                return {"statusCode": 200, "data": data}

            elif todo == "fetch_and_generate":
                report_name = event.get("report_name")
                # params = event.get("report_params")
                # params=params
                params = event.get("params", {}) 
                return oa_mgr.fetch_and_generate_report(report_name, params)

            elif todo == "mark_report_completed":
                return oa_mgr.mark_all_report_completed()

            elif todo == "setup_db":
                return oa_mgr.create_db()

            elif todo == "questionnaire_report":
                QA = QuestionnaireStatusLogReport(cursor, db_conn)
                QA.process()
                return

            if todo == 'isKboxPendingForExecution':
                QA = QuestionnaireStatusLogReport(cursor, db_conn)
                return {"report_found": QA.check_cron_status()}

            if todo == 'getPendingKboxRecords':
                QA = QuestionnaireStatusLogReport(cursor, db_conn)
                kbox_numbers = QA.get_pending_records()
                return {"statusCode": 200, "data": kbox_numbers}

            if todo == 'PullArchiveData':
                QA = QuestionnaireStatusLogReport(cursor, db_conn)
                kbox_number = event['kbox_number']
                QA.pull_archive_data(kbox_number)
                time.sleep(7)
                return {
                    "statusCode": 500,
                    "body": json.dumps({"success":True})
                }

            if todo == 'generateAiArchiveReport':
                QA = QuestionnaireStatusLogReport(cursor, db_conn)
                response = QA.write_data_to_sharepoint()
                return {
                    'statusCode': 200,
                    'body': json.dumps(response)
                }

            if todo == 'feedback_report_daily':
                previous_days = 1
                payloads = [
                    {"report_name":"type_1_rejection", "survey_id": 1, "report_type": "rejection", "start_date": calculate_x_days_before_today(previous_days), "end_date": datetime.now().strftime("%d/%m/%Y")},
                    {"report_name":"type_2_rejection", "survey_id": 2, "report_type": "rejection", "start_date": calculate_x_days_before_today(previous_days), "end_date": datetime.now().strftime("%d/%m/%Y")},
                    {"report_name":"type_1_all", "survey_id": 1, "report_type": "", "start_date": calculate_x_days_before_today(previous_days), "end_date": datetime.now().strftime("%d/%m/%Y")},
                    {"report_name":"type_2_all", "survey_id": 2, "report_type": "", "start_date": calculate_x_days_before_today(previous_days), "end_date": datetime.now().strftime("%d/%m/%Y")},
                ]

                response =[]
                for payload in payloads:

                    frp = FeedbackReportProcessor(db_conn, cursor, payload)
                    status = frp.process()
                    response.append(status)


                # payload = {
                #     "survey_id": event.get("survey_id", 1),
                #     "report_type": event.get("report_type", "rejection"),
                #     "start_date": event.get("start_date"),
                #     "end_date": event.get("end_date")
                # }

                # frp = FeedbackReportProcessor(db_conn, cursor, payload)
                # status = frp.process()
                return {
                    "statusCode": 200,
                    "body": json.dumps(response)
                }

            if todo in ["get_entity_and_user_assignment_report","get_download_certificate_report","get_exported_best_practice_report", "get_users_using_best_practice_hashtag"]:

                # Create an instance of ReportHandler and handle the report
                report_handler = ReportHandler()

                response = report_handler.handle_report(todo)

                return {
                    "statusCode": 200,
                    "body": json.dumps(response)
                }

            if todo in ["ev_ready_for_review","ev_user_noti_settings_log", "ev_policy_tpl_download_logs", "ev_audit_log_export"]:

                # Create an instance of ReportHandler and handle the report
                report_handler = ReportHandler()
                response = report_handler.handle_report_v2(todo)
                return {
                    "statusCode": 200,
                    "body": json.dumps(response)
                }

            if todo in ["ev_custom_sample_table_processor"]:
                table_name = event.get("table_name")
                table_processor = TableProcessor(db_conn, cursor)
                response = table_processor.process_table(todo, table_name)

                return {
                    "statusCode": 200,
                    "body": json.dumps(response)
                }

        except:
            response = draft_failure_email(event, traceback.format_exc())
            print(f"failure mail sent - {response}")
            db_conn.close()
            return {
                "statusCode": 500,
                "error_msg": traceback.format_exc()
            }



    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
