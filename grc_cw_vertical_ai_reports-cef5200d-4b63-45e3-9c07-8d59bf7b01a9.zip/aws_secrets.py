import pymysql,json,os
from generic_function import *
from get_secret_function import *

class Secretes:

	def __init__(self):
		self.mysql_db = None
		self.cursor = None
		self.connect_db()
		self.secrete_repo = self.get_secrets_from_db()
		

	def connect_db(self):
		db_configs = get_mysql_secret()
		print(db_configs)
		import sys
		sys.exit()
		try:
			self.mysql_db = pymysql.connect(host=db_configs['host'], user=db_configs['username'], passwd=db_configs['password'], database=os.environ["DB_NAME"])
			self.cursor = self.mysql_db.cursor(pymysql.cursors.DictCursor)
			print("Connected to SLA DB")
		except Exception as e:
			print("Failed to connect to SLA DB:", e)
			
		
	def insert_secrets_to_db(self):
		response = {"success":"false",'message':''}
		self.cursor.execute("TRUNCATE `aws_secrete`")
		
		db_configs = get_mysql_secret()
		if len(db_configs)>0:
			sql ="replace into aws_secrete (secrete_name,secrete_value) values (%s,%s)"
			self.cursor.execute(sql,["db_configs",json.dumps(db_configs),])
		
		### sf_configs
		sf_configs = get_sf_secret()
		if len(sf_configs)>0:
			sql ="replace into aws_secrete (secrete_name,secrete_value) values (%s,%s)"
			self.cursor.execute(sql,["sf_configs",json.dumps(sf_configs),])
		
		### sla_secrets 
		sla_secrets = get_sla_secret()
		if len(sla_secrets)>0:
			sql ="replace into aws_secrete (secrete_name,secrete_value) values (%s,%s)"
			self.cursor.execute(sql,["sla_secrets",json.dumps(sla_secrets),])
		
		#### oa_secret_data
		oa_secret_data = get_oa_secret()
		if len(oa_secret_data)>0:
			sql ="replace into aws_secrete (secrete_name,secrete_value) values (%s,%s)"
			self.cursor.execute(sql,["oa_secret_data",json.dumps(oa_secret_data),])
			
		#### cc_db_configs
		cc_db_configs = get_cchub_db_secret()
		if len(cc_db_configs)>0:
			sql ="replace into aws_secrete (secrete_name,secrete_value) values (%s,%s)"
			self.cursor.execute(sql,["cc_db_configs",json.dumps(cc_db_configs),])
	
		#### cw_configs
		cw_configs = get_cw_secret()
		if len(cc_db_configs)>0:
			sql ="replace into aws_secrete (secrete_name,secrete_value) values (%s,%s)"
			self.cursor.execute(sql,["cw_configs",json.dumps(cw_configs),])
		
		#### cchub_apis_secret
		cchub_apis_secret = get_cchub_api_secret()
		if len(cc_db_configs)>0:
			sql ="replace into aws_secrete (secrete_name,secrete_value) values (%s,%s)"
			self.cursor.execute(sql,["cchub_apis_secret",json.dumps(cchub_apis_secret),])
		
		self.mysql_db.commit()
	
	
	def get_secrets_from_db(self):
		secrete_repo = {}
		sql = "select * from aws_secrete"
		self.cursor.execute(sql)
		result = self.cursor.fetchall()
		if len(result)>0:
			for row in result:
				secrete_repo.update({
					row['secrete_name']:json.loads(row['secrete_value'])
				})
		
		return secrete_repo
	
	
	def get_secret(self,secrete_name):
		return self.secrete_repo.get(secrete_name)
					
			