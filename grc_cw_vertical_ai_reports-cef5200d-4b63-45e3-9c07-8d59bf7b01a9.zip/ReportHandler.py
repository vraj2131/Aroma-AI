from config import *
import pymysql
import requests
import time
import json
from datetime import datetime, timedelta

from generic_function import get_sharepoint_configs, connect_db
from CSVEditor import CSVEditor
from csv_config import getReportHandlerConfig, getDirectReportsCsvDetails

class ReportHandler:
	def __init__(self):
		self.db_host = db_host
		self.db_user = db_user
		self.db_pw = db_pw
		self.db_name = db_name
		self.base_url = OA_HOST+'/oai'
		self.api_headers = {
			'Content-Type': 'application/json',
			'x-api-key': OAI_X_API_KEY,
			'kbox': 'ClientK1675',
			'user_id': '1'
		}

		self.max_retries = 2
		self.retry_delay = 5


	def fetch_api_data(self, report_name):
		retries = 0

		while retries < self.max_retries:
			try:
				report_url = f"{self.base_url}/reports/internal-reports?report_name={report_name}"
				response = requests.get(report_url, headers=self.api_headers)
				if response.status_code == 200:
					return response.json()['data']
				else:
					print(f"Error: API request failed with status code {response.status_code}")
					retries += 1
					time.sleep(self.retry_delay)
			except Exception as e:
				print("Error: ", e)
				retries += 1
				time.sleep(self.retry_delay)

		# If all retries fail, return an empty list
		print(f"Error: API request failed after {self.max_retries} retries")
		return []
			
	
		
	def fetch_report_data(self,report_name, params):
		count = 0
		curr_page = 1
		all_data = []
	   
		params.update({"curr_page":1})
		while True:
			
			# # Update the headers with the current page number
			params['curr_page'] = curr_page
			
			report_url = f"{self.base_url}/reports/internal-reports?report_name={report_name}&{'&'.join([f'{key}={value}' for key, value in params.items()])}"
			# report_url = f"{self.base_url}/reports/internal-reports?report_name={report_name}"  # Start with report_name
			# if params:
			# 	query_string = ""
			# 	for key, value in params.items():
			# 		if not query_string:  # First parameter
			# 			query_string = f"?{key}={value}"
			# 		else:  # Subsequent parameters
			# 			query_string += f"&{key}={value}"
			# 	report_url += query_string

			# print(f"Constructed URL: {report_url}")  # VERY IMPORTANT: Print the URL for debugging


			
			res = requests.get(report_url, headers=self.api_headers)
		   
			if res is None:
				print("Failed to receive a response from the API")
				return None

			if res.status_code == 200:
				status = res.json().get("error", "")
				if status == 'false':
					data = res.json().get("data", {})
					all_data.extend(data)
					
					# Check for pagination
					next_page = res.headers.get('next_page')
					if next_page and next_page != '0':
						curr_page = int(res.headers.get('curr_page', curr_page)) + 1
					else:
						break  # Exit the loop if no next page
				else:
					print(report_url)
					print(f"Error: {res.text}")
					return None
			else:
				print(report_url)
				print(f"Error: {res.text}")
				return None

		return all_data if all_data else []
		

	def handle_report(self, report_name):
		# Check if the report_name exists in the configuration

		# Get report configuration
		report_config =  getReportHandlerConfig(report_name.lower())

		# Fetch data from API
		if report_name == "get_entity_and_user_assignment_report":
			
			from_time = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
			to_time = (datetime.now()).strftime("%Y-%m-%d %H:%M:%S")
			params_time = {
				"from_timestamp": from_time,
				"to_timestamp": to_time
			}

			api_data =  self.fetch_report_data(report_name,params_time)
		else:
			api_data = self.fetch_api_data(report_name)

		db_response =  connect_db()
		db_conn = db_response['data']
		
		
		print("api_data", api_data)
		if db_response['success']:
			db_conn = db_response['data']
			if api_data:
					for record in api_data:
						self.insert_data(db_conn, report_config, record)
					print("Data inserted/updated successfully.")
			else:
				print("No data found from the API.")

			## write to file
			resp = self.process_report_data(db_conn, report_name, report_config)

			return resp
		else:
			print("Failed to connect to the database:", db_response['message'])
			response_data = {
				"success": False,
				"msg": "Failed to connect to the database"
			}

			return response_data

	def insert_data(self, db_conn, report_config, record):
		try:
			
			record = self.format_last_accessed_time(record)
					
			cursor = db_conn.cursor()
			fields_mapping = {key: val for key, val in report_config['fields_mapping'].items() if key.lower() not in ['project id','beta'] }
			columns = ', '.join(fields_mapping.values())
			values = ', '.join(['%s'] * len(fields_mapping))
			
			
			query = f"INSERT INTO {report_config['table_name']} ({columns}) VALUES ({values}) " \
					f"ON DUPLICATE KEY UPDATE {', '.join([f'{col} = VALUES({col})' for col in fields_mapping.values() if col not in report_config['table_identifier']])}"
		
			cursor.execute(query, list(record.values()))
			db_conn.commit()
		except Exception as e:
			print("Error: ", e)
			db_conn.rollback()

	def format_last_accessed_time(self, record):
		# Check if 'last_accessed_time' is in the record
		if 'last_accessed_time' in record:
			# Parse the original date-time string
			original_time = datetime.fromisoformat(record['last_accessed_time'])
			
			# Reformat it to the desired format (e.g., "YYYY-MM-DD HH:MM:SS")
			formatted_time = original_time.strftime('%Y-%m-%d %H:%M:%S')
			
			# Update the record with the formatted date-time string
			record['last_accessed_time'] = formatted_time
	
		return record


	def get_report_data(self, db_conn, cursor, report_config, kbox_to_exclude=None, user_to_exclude=None):
		try:

			table_name = report_config['table_name']
			kbox_field = report_config['kbox_field']
			user_field = report_config['user_field'] if 'user_field' in report_config else None
			dashboard_field = report_config['dashboard_field'] if 'dashboard_field' in report_config else None

			conditions = []
			if kbox_field and kbox_to_exclude:
				kbox_to_exclude__str = ",".join([str(val) if isinstance(val, int) else f"'{val}'" for val in kbox_to_exclude])
				conditions.append(f"{kbox_field} NOT IN ({kbox_to_exclude__str})")

				# conditions.append(f"{kbox_field} NOT IN ({', '.join(kbox_to_exclude)})")
			if user_field and user_to_exclude:
				user_to_exclude__str = ",".join([f"'{val}'" if isinstance(val, str) else f"{val}" for val in user_to_exclude])
				conditions.append(f"{user_field} NOT IN ({user_to_exclude__str})")
			query = f"SELECT * FROM {table_name} tbl"

			if dashboard_field:
				query = f"SELECT tbl.*, pcm.project_id as Project_ID FROM {table_name} tbl LEFT JOIN project_config_mapping pcm ON tbl.{dashboard_field}=pcm.config_id AND pcm.department NOT IN ('Cybersecurity Services','Pro Services') and pcm.project_status in ('New','In Progress','In Progress - AT RISK')"

			# query = f"SELECT * FROM {table_name}"
			if conditions:
				query += " WHERE " + " AND ".join(conditions)

			cursor.execute(query)
			data = cursor.fetchall()
			db_conn.close()
			return data

		except Exception as e:
			print("Error: ", e)
			return []


	def process_report_data(self, db_conn, report_name,report_config):

		cursor = db_conn.cursor(pymysql.cursors.DictCursor)

		report_data_from_db = self.get_report_data(db_conn, cursor, report_config, kbox_to_exclude, user_to_exclude)
		print(f"Processing report: {report_name}")
		if report_data_from_db:
			print(f"Data retrieved successfully for report: {report_name}.  Number of rows: {len(report_data_from_db)}")
			csv_header = report_config.get("csv_header")
			fields_mapping = report_config.get("fields_mapping")
			# fields_mapping = {key: val for key, val in report_config['fields_mapping'].items() if key.lower() not in ['beta'] }
			
			csv_data = []

			for row in report_data_from_db:
				data = []
				for col in csv_header:
					data.append(row[fields_mapping[col]])
				csv_data.append(data)

			# Writing data into csv file
			if len(csv_data)>0:
				print(f"CSV data prepared for report: {report_name}. Number of rows: {len(csv_data)}")
				sharepoint_configs =  get_sharepoint_configs('BI')

				report_config.update({"sharepoint_host":sharepoint_host, 'sharepoint_site_url':sharepoint_host+"/sites/"+sharepoint_configs['site_name'],"doc_base_library":sharepoint_configs['doc_base_library']})

				# ## object invokation
				fn_obj = CSVEditor(report_config)

				## Check if file exist
				if fn_obj.csvExist():
					print(f"CSV file exists. Deleting old CSV for report: {report_name}")
					csv_created = fn_obj.deleteOldCSV(fn_obj.s3_file_name)

				csv_created = fn_obj.createCSVWithHeaders()
				s3_file_name = fn_obj.writeDataToCSV(csv_data)
				error = fn_obj.upload_s3_report_to_sharepoint('BI')
				response_data = {
					"success": error,
					"msg": s3_file_name
				}

				return response_data


		else:

			response_data = {
					"success": False,
					"msg": "No data found for the report:" + report_name
				}

			return response_data
	
	def handle_report_v2(self, report_name):
		report_data_from_db = {}
		# Check if the report_name exists in the configuration
		
		print("report_name------",report_name)
		# Get report configuration
		report_config =  getDirectReportsCsvDetails(report_name.lower())
		
		db_response =  connect_db()
		db_conn = db_response['data']

		if db_response['success']:
			db_conn = db_response['data']

			## write to file
			resp = self.process_report_data(db_conn, report_name, report_config)

			return resp
		else:
			print("Failed to connect to the database:", db_response['message'])
			
		return report_data_from_db

