import os

#csv config
TEMP_PATH = '/tmp/'
SCRIPT_FOLDER = ''
CSV_FILENAME = ''
TEMP_FILEPATH = TEMP_PATH+CSV_FILENAME

S3_BUCKET_FOR_TEMP_SLA = os.environ['S3_BUCKET_FOR_TEMP_REPORT']

CSV_HEADERS = []

TIMESHEET_REPORTS_TYPES = ['config_report','resource_errort_report','resource_admin_time_report']

def getCSVDetails(report_name='config_report'):

	if report_name == 'config_report':

		csv_header = {
			"Site and Cert" : "site_cert",
			"Company Name" : "company_name",
			"Site Name" : "site_name",
			"Site ID" : "site_id",
			"Configuration Name" : "dashboard_name",
			"Vertical" : "vertical",
			"GCOE" : "gcoe",
			"Target Cert" : "target_cert_date",
			"Status" : "status",
			"Warranty Expiration" : "warrantyexpirationdate",
			"Company Id" : "company_identifier",
			"ACE" : "ace",
			"Report Automation" : "report_automation",
			"PCI DSS" : "pcidss",
			"HIPAA" : "hipaa",
			"ISO" : "iso",
			"SOC" : "soc",
			"Other Cert" : "other_cert",
			"CC Certification Type" : "cc_cert_type",
			"Target100P" : "target_100p",
			"Actual100P" : "actual_100p",
			"Actual RR" : "actual_rr",
			"External IP" : "externalip",
			"Internal IP" : "internalip",
			"New Cert" : "new_cert",
			"Last Target Cert Date" : "last_cert_date",
			"Cert Date" : "cert_date",
			"SR Service Rec ID" : "service_rec_id",
			"Client Size Category" : "client_size_cat",

		}
		csv_file_name = 'ConfigurationFile.csv'

	if report_name == 'resource_errort_report':

		csv_header = {
			"Site and Cert" : "site_cert",
			"Company Name" : "company_name",
			"Site Name" : "site_name",
			"Site ID" : "site_id",
			"Configuration Name" : "dashboard_name",
			"Status" : "status",
			"Cert Date" : "cert_date",
			"Target Cert" : "target_cert_date",
			"SR Service Rec ID" : "service_rec_id",
			"Summary" : "summary",
			"Member ID" : "member_id",
			"Time Added" : "date",
			"Actual Hours" : "actual_hours",
			"Service Sub Type" : "subtype",
			"ActualRR" : "actual_rr"
		}
		csv_file_name = 'ResourceEffortTimeFile.csv'

	if report_name == 'resource_errort_report_v2':

		csv_header = {
			"Site and Cert" : "site_cert",
			"Company Name" : "company_name",
			"Site Name" : "site_name",
			"Site ID" : "site_id",
			"Configuration Name" : "dashboard_name",
			"Status" : "status",
			"Cert Date" : "cert_date",
			"Target Cert" : "target_cert_date",
			"SR Service Rec ID" : "service_rec_id",
			"Summary" : "summary",
			"Member ID" : "member_id",
			"Time Added" : "date",
			"Actual Hours" : "actual_hours",
			"Service Sub Type" : "subtype",
			"ActualRR" : "actual_rr"
		}
		csv_file_name = 'ResourceEffortTimeFileV2.csv'

	if report_name == 'resource_admin_time_report':

		csv_header = {
			"Member ID" : "member_id",
			"ChargeCode" : "ChargeCode",
			"Some of Hours" : "actual_hours",
			"Month & Year" : "date"
		}
		csv_file_name = 'ResourceAdminTimeFile.csv'


	if report_name == 'tester_time_report_v1':

		csv_header = {
			"Year" : "year",
			"Month" : "month",
			"Ticket" : "ticket_id",
			"Total Hours" : "hours",
			"Status" : "status",
			"Kbox" : "company_identifier",
			"Company" : "company",
			"Dashboard" : "dashboard",
			"Site" : "site",
			"Members":"Members"
		}
		csv_file_name = 'TesterTimeReport_v1.csv'


	if report_name == 'NewProjects':

		csv_header = {
			"Company"			:"Company",
			"Sales Order No."		:"Sales Order No.",
			"Project #"			:"Project #",
			"Project Name"      :"Project Name",
			"Site"              :"Site",
			"Project Manager"   :"Project Manager",
			"Project Type"      :"Project Type",
			"Project Start Date":"Project Start Date",
			"Project End Date"  :"Project End Date",
			"Actual Hours"      :"Actual Hours",
			"Project Board"     :"Project Board",
			"Project Status"    :"Project Status",
		}
		csv_file_name = 'Projects_Report.csv'

	if report_name == 'NewProjectsScorecardReport':

		csv_header = {
			"Company"			:"Company",
			"Sales Order No."	:"Sales Order No.",
			"Project #"			:"Project #",
			"Project Name"      :"Project Name",
			"Site"              :"Site",
			"Project Manager"   :"Project Manager",
			"Project Type"      :"Project Type",
			"Project Start Date":"Project Start Date",
			"Project End Date"  :"Project End Date",
			"Actual Hours"      :"Actual Hours",
			"Project Board"     :"Project Board",
			"Project Status"    :"Project Status",
			"ACV"    			:"ACV",
			"Estimated Hours"   :"Estimated Hours",
			"Actual 100p"    	:"Actual 100p",
			"Assessor"    		:"Assessor",
			"First or Recert"   :"First or Recert",
			"Ticket"  			:"Ticket",
			"Dashboard ID"  	:"Dashboard ID",
			"Dashboard Name"	:"Dashboard Name",
			"Dashboard Status"  :"Dashboard Status",
			"GCOE Auditor"			:"GCOE Auditor",
			"Target Cert"       	:"Target Cert",
			"New Target Cert Date"  :"New Target Cert Date",
			"Contract Expiration Date"  :"Contract Expiration Date",
			"TCV"    			:"TCV",
			"Actual RR"    		:"Actual RR",
			"Notes"             :"Notes",
			"PCI DSS"           :"PCI DSS",
			"Segmentation"      :"Segmentation",
			"other_cert"    	:"other_cert",
			"Budgeted Hours"    :"Budgeted Hours",
			"CSM"   			:"CSM",
			"Account Manager"   :"Account Manager"

		}
		csv_file_name = 'Project_Report_Scorecard.csv'

	if report_name == 'DashboardList':

		csv_header = {
			"ID"	          :"ID",
			"Dashboard Name" :"Dashboard Name",
			"Status" :"Status"
		}
		csv_file_name = 'DashboardList.csv'

	if report_name == 'getProjectProducts':

		csv_header = {

			"Project #"		:"Project #",
			"Project Name"	:"Project Name",
			"Product"		:"Product",
			"Kbox"			:"Kbox",
			"Company"		:"Company",
			"Site"			:"Site",
			"Price"         :"Price"

		}
		csv_file_name = 'Products_Report.csv'

	if report_name == 'getProjectConfigs':

		csv_header = {

			"Project #"			:"Project #",
			"Project Name"		:"Project Name",
			"Kbox"				:"Kbox",
			"Company"			:"Company",
			"Site"				:"Site",
			"Config Name" 		:"Config Name",
			"Config Type"		:"Config Type",
			"Config Status"		:"Config Status",
			"Product Group"		:"Product Group",
			"New Dashboard"		:"New Dashboard",
			"New Cert"			:"New Cert",
			"Test Date"			:"Test Date",
			"Target Cert Date"	:"Target Cert Date",
			"Portal Date"		:"Portal Date",
			"Segmentation"		:"Segmentation",
		    "New Target Cert Date"	:"New Target Cert Date",
		    "Cert Date"         :"Cert Date"
		}
		csv_file_name = 'Project_Config_Report.csv'
	if report_name in ['odr_cert','odr_css']:

		csv_header = {
			"Project Id"		:"project_id",
			"Project Name"      :"project_name",
			"Project Board"     :"project_board",
			"project Type"      :"project_type",
			"ticket_id"         :"ticket_id",
			"summary"           :"summary",
			"status"            :"status",
			"Ticket Owner"      :"owner_name",
			"Identifier"        :"Identifier",
			"Company"           :"Company",
			"Site Id"           :"Site Id",
			"Site Name"         :"Site Name",
			"Due Date"          :"Due Date",
			"Status Changed on" :"Status Changed on",
			"Updated By"        :"Updated By",
			"Ticket Created"    :"date_entered"
		}
		if report_name == 'odr_cert':
			csv_file_name = 'Cert'
		elif report_name == 'odr_css':
			csv_file_name = 'Only_CSS'

	if report_name == 'projectNotesReport':

		csv_header = [
			"Project Id",
			"Project Name",
			"Note",
			"Flag",
			"Updated by",
			"Updated on"
		]
		csv_file_name = 'Project_Notes_Report.csv'

	if report_name == 'RiskTicketsReport':

		csv_header = [
			"Project ID",
			"Ticket ID",
			"Item",
			"Status",
			"Summary Description"
		]
		csv_file_name = 'Risk_Tikets_Report.csv'
	
	if report_name == 'projectCertificationRepo':

		csv_header = [
				"Company",
				"Sales Order No.",
				"Project #",
				"Project Name",
				"Site",
				"Project Manager",
				"Project Type",
				"Project Start Date",
				"Project End Date",
				"Actual Hours",
				"Project Board",
				"Project Status",
				"ACV",
				"Estimated Hours",
				"Actual 100p",
				"Assessor",
				"First or Recert",
				"Ticket",
				"Dashboard ID",
				"Dashboard Name",
				"Dashboard Status",
				"GCOE Auditor",
				"Target Cert",
				"New Target Cert Date",
				"Contract Expiration Date",
				"TCV",
				"Config Actual RR",
				"Notes",
				"PCI DSS",
				"Segmentation",
				"other_cert",
				"Actual RR"
		]
		
		csv_file_name = 'Project_certification_report.csv'
	
	if report_name == 'projectCertificationReportv2':

		csv_header = [
				"Company",
				"Sales Order No.",
				"Project #",
				"Project Name",
				"Site",
				"Project Manager",
				"Project Type",
				"Project Start Date",
				"Project End Date",
				"Actual Hours",
				"Project Board",
				"Project Status",
				"ACV",
				"Estimated Hours",
				"Actual 100p",
				"Assessor",
				"First or Recert",
				"Ticket",
				"Dashboard ID",
				"Dashboard Name",
				"Dashboard Status",
				"GCOE Auditor",
				"Target Cert",
				"New Target Cert Date",
				"Contract Expiration Date",
				"TCV",
				"Config Actual RR",
				"Notes",
				"PCI DSS",
				"Segmentation",
				"other_cert",
				"Actual RR"
		]
		
		csv_file_name = 'Project_certification_report_v2.csv'


	if report_name in ['DashboardList','NewProjectsScorecardReport', 'NewProjects', 'getProjectProducts', 'getProjectConfigs','odr_cert','odr_css','projectNotesReport']:
		report_config= {
			"script_folder": 'Cybersecurity services',
			"sub_folder": '',
			"csv_filename": csv_file_name,
			"csv_header": csv_header
		}
	elif report_name in ['americas_new_cert','americas_re_cert','apac_new_cert','apac_re_cert']:

		csv_header = {

			"Company"             :"Company",
			"Sales Order No."     :  "Sales Order No.",
			"Project #"           :  "Project #",
			"Project Name"        :  "Project Name",
			"Site"                :  "Site",
			"Project Manager"     :  "Project Manager",
			"Project Type"        :  "Project Type",
			"Project Start Date"  :  "Project Start Date",
			"Project End Date"    :  "Project End Date",
			"Actual Hours"        :  "Actual Hours",
			"Project Board"       :  "Project Board",
			"Project Status"      :  "Project Status",
			"TargetKC"            :  "TargetKC",
			"TargetSU"            :  "TargetSU",
			"TargetSP"            :  "TargetSP",
			"Target50U"           :  "Target50U",
			"Target50P"           :  "Target50P",
			"Target100U"          :  "Target100U",
			"Target100P"          :  "Target100P",
			"TargetRR"            :  "TargetRR",
			"ActualKC"            :  "ActualKC",
			"ActualSU"            :  "ActualSU",
			"ActualSP"            :  "ActualSP",
			"Actual50U"           :  "Actual50U",
			"Actual50P"           :  "Actual50P",
			"Actual100U"          :  "Actual100U",
			"Actual100P"          :  "Actual100P",
			"ActualRR"            :  "ActualRR",
		}
		if report_name == 'americas_new_cert':
			csv_file_name = "Americas_NewCert"
		if report_name == 'americas_re_cert':
			csv_file_name = "Americas_ReCert"
		if report_name == 'apac_new_cert':
			csv_file_name = "Apac_NewCert"
		if report_name == 'apac_re_cert':
			csv_file_name = "Apac_ReCert"
		report_config= {
			"script_folder": 'IT Certification',
			"sub_folder": '',
			"csv_filename": csv_file_name,
			"csv_header": csv_header
		}
	else:

		report_config= {
				"script_folder": 'timesheet_reports',
				"csv_filename": csv_file_name,
				"csv_header": csv_header
		}


	return report_config


def projectReportDetails(report_name='ProductionReportsNewProjects'):

	if report_name == 'ProductionReportsNewProjects':

		header_1 = ["Project Board","New Projects Count"]
		header_2 = ["Project #","Project Name","Site","Project Manager","Project Type","Project Start Date","Project End Date","Project Board"]
		file_name = 'ProductionReportsNewProjects'

	report_config= {

			"script_folder": 'project_report',
			"filename": file_name,
			"header_1": header_1,
			"header_2": header_2
	}
	return report_config

def css_projects_daily_sla_tracking(report_name='config_report'):

	if report_name == 'config_report':

		csv_header = {
			"Project Ticket No." : "Project Ticket No.",
			"KBox Number" : "KBox Number",
			"Configuration Name" : "Configuration Name",
			"Client Segmentation" : "Client Segmentation",
			"Project Ticket Vertical" : "Project Ticket Vertical",
			"Territory" : "Project Ticket Territory",
			"Project Ticket Subtype" : "Project Ticket Subtype",
			"Item" : "Project Ticket Item",
			"Project Ticket Owner" : "Project Ticket Owner",
			"Project Ticket creation date" : "Project Ticket Creation Date",
			"Project Ticket Due Date" : "Project Ticket Due Date",
			"Project Ticket Status" : "Project Ticket Status",
			"Project Ticket Status ID" : "Project Ticket Status ID",
			"Project Ticket Board Name" : "Project Ticket Board Name",
			"Project Ticket Phase Name" : "Project Ticket Phase Name",
			"Project Ticket Site Name" : "Project Ticket Site Name",
			"Project Ticket Last Update" : "Project Ticket Last Update",
			"Project Ticket Last Updated By" : "Project Ticket Last Updated By",
			"Project Type" : "Project Type",
			"Project Department" : "Project Department",
			"Project Status" : "Project Data Status",
			"Project Manager Name" : "Project Manager Name",
			"Project Name" : "Project Name",
			"Project Assessor" : "Project Assessor"
		}
		csv_file_name = 'CSS_Projects_Daily_SLA_tracking.csv'
		report_config= {
			"script_folder": 'Cybersecurity services',
			"sub_folder": '',
			"csv_filename": csv_file_name,
			"csv_header": csv_header
		}

		return report_config