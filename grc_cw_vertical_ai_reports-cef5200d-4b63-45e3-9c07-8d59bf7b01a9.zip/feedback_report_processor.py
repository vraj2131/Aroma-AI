import json
from datetime import datetime, timedelta
from typing import Dict, Any, List

from generic_function import get_insert_query, get_sharepoint_configs
from csv_config import getFeedbackCSVDetails
from config import sharepoint_host, kbox_to_exclude, user_to_exclude, OA_HOST, OAI_X_API_KEY
import requests

from CSVEditor import CSVEditor

class FeedbackReportProcessor:
    def __init__(self, db_conn, cursor, payload: Dict) -> None:
        self.url = OA_HOST+'/cfp/feedback/report/daily'
        self.headers = {
            'application': 'ClientK1',
            'module': 'statboard',
            'content-type': 'application/json',
            'start': payload.get("start_date") or (datetime.now() - timedelta(days=1)).strftime("%d/%m/%Y"),
            'end': payload.get("end_date") or (datetime.now()).strftime("%d/%m/%Y"),
            'export': '1',
            'x-api-key': OAI_X_API_KEY,
            'email': 'grcteam@controlcase.com',
            'survey_id': f"{payload.get('survey_id', 2)}",
            
        }
        if payload.get("report_type"):
            self.headers['report_type'] = payload["report_type"]
        self.table_name = "feedback_report"
        self.db_conn = db_conn
        self.cursor = cursor
        self.report_name = payload["report_name"]
        self.survey_id = payload["survey_id"]
    
    def get_data_from_api(self):
        
        response = requests.request("GET", self.url, headers=self.headers, data={})
        
        if response.status_code == 200:
            data = response.json()

            inner_body = json.loads(data["body"])
            
            if inner_body:
                first_index_data = inner_body[next(iter(inner_body))]
                return first_index_data
        
        return {}
        
    def transform_data(self, api_data: Dict) -> List[Dict[str, Any]]:
        
        if self.survey_id == 1:
            
            column_to_rename = {"Response Time": "response_time", "Client Name": "client_name", "Portal Number": "portal_number", "Email Address": "email_address","Please rate your experience with our user interface and dashboard.":"rate_your_experience","We Promise to do better,  Please take out a few minutes to help us improve.":"help_us_improve"}
        elif self.survey_id == 2:
            column_to_rename = {"Response Time": "response_time", "Client Name": "client_name", "Portal Number": "portal_number", "Email Address": "email_address","Please rate your experience with our AI Pre-checks Assistant":"rate_your_experience","We Promise to do better,  Please take out a few minutes to help us improve.":"help_us_improve"}
            
        table_col = ["reponse_id", "survey_id","report_type","response_time", "client_name", "portal_number", "email_address"]
        
        transformed_data = []
        for response_id, response_details in api_data.items():

            record = {
                "response_id": response_id,
            }
            # print("response_details")
            # print(response_details)
            for key, val in response_details.items():
                if key in column_to_rename:
                    record[column_to_rename[key]] = val

            record["survey_id"] = self.headers.get("survey_id")
            record["report_type"] = self.headers.get("report_type",None)
        
            transformed_data.append(record)
        
        return transformed_data
    
    def load_data_to_db(self, records) -> bool:
        query = get_insert_query(self.table_name, records, has_replace=True)
        self.cursor.execute(query)
        self.db_conn.commit()
        return True
    
    def process(self) -> bool:
        response = {}
        api_data = self.get_data_from_api()
        print(f"Total Records from API: {len(api_data)}")
        # print(api_data)
        records = self.transform_data(api_data)
        print(f"Total Records To Push In DB: {len(records)}")
        # print(records)
        
        response.update({self.report_name:{"success":"","data":{},"msg":""}})
        if len(records)>0:
            success = self.load_data_to_db(records)
        else:
            response[self.report_name]["msg"] = "No data found for report"
            
        report_data_from_db = self.get_report_data(kbox_to_exclude, user_to_exclude)
        
        report_config = getFeedbackCSVDetails(self.report_name)
        sharepoint_configs = get_sharepoint_configs('BI')
        report_config.update({"sharepoint_host":sharepoint_host, 'sharepoint_site_url':sharepoint_host+"/sites/"+sharepoint_configs['site_name'],"doc_base_library":sharepoint_configs['doc_base_library']})
        csv_data = []
        
        for idx, row in enumerate(report_data_from_db):
            
            fields_mapping = report_config.get("fields_mapping")
            csv_header = report_config.get("csv_header")
            data = []
            for col in csv_header:
                data.append(row[fields_mapping[col]])
                
            csv_data.append(data)
    
        # Writing data into csv file
        if len(csv_data)>0:
    
            # ## object invokation
            fn_obj = CSVEditor(report_config)
    
            ## Check if file exist
            if fn_obj.csvExist():
                csv_created = fn_obj.deleteOldCSV(fn_obj.s3_file_name)
    
            csv_created = fn_obj.createCSVWithHeaders()
            s3_file_name = fn_obj.writeDataToCSV(csv_data)
            error = fn_obj.upload_s3_report_to_sharepoint('BI')
            response_data = {
                "success": error,
                "msg": s3_file_name
            }
            if self.report_name in response:
                response[self.report_name].update(response_data)
            else:
                response[self.report_name] = response_data

        return response
        
    def get_report_data(self, kbox_to_exclude, user_to_exclude):
        
        survey_id = self.headers.get("survey_id")
        report_type = self.headers.get("report_type",'')
            
        where_clause = []
        query = f"SELECT * FROM feedback_report f WHERE survey_id ={survey_id} "
        if report_type =='':
            query = query + " and report_type=''"
        else:
            query = query + f" and report_type='{report_type}'"

        if kbox_to_exclude:

            # kbox_to_exclude__str = ",".join([f"{val}" for val in kbox_to_exclude])
            kbox_to_exclude__str = ",".join([str(val) if isinstance(val, int) else f"'{val}'" for val in kbox_to_exclude])
            where_clause.append(f"portal_number NOT IN ({kbox_to_exclude__str})")
        
        if user_to_exclude:
            # user_to_exclude_str = ",".join([f"'{val}'" for val in user_to_exclude])
            user_to_exclude__str = ",".join([f"'{val}'" if isinstance(val, str) else f"{val}" for val in user_to_exclude])
            where_clause.append(f"email_address NOT IN ({user_to_exclude__str})")
        
        if where_clause:
            where_clause__str = " AND ".join(where_clause)
            query += f" AND {where_clause__str}"
        
        print("kbox exlude quary: ",query)
        self.cursor.execute(query)
        data = self.cursor.fetchall()
        print(f"Total number of records: {len(data)}")
        return data
        
        