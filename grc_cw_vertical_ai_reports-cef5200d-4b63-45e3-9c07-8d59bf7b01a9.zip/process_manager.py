import json
import time
from datetime import datetime, timedelta

from csv_config import getCSVDetails
from generic_function import get_sharepoint_configs, get_insert_query, get_delete_query, get_update_query, get_select_query
from config import sharepoint_host, kbox_to_exclude, user_to_exclude, ACTIVE_PROJECT_STATUSES
from CSVEditor import CSVEditor

class ProcessManager:
    def __init__(self, db_conn, cursor, oai):
        self.db_conn = db_conn
        self.cursor = cursor
        self.oai = oai
        self.table_name = "ai_reports_manager"

        self.script_default_hrs = 1000

    def get_pending_report_details(self, limit=2):
        # First check if we have any data in table
        # query = f"SELECT name, api_url, params FROM {self.table_name} WHERE status=0"

        report_list = []
        query = f"SELECT name FROM {self.table_name} WHERE status=0"
        self.cursor.execute(query)
        records = self.cursor.fetchall()
        print(records)
        if records:
            for rept in records:
                report_list.append(rept['name'])
            return report_list

        return []

    def update_report_status(self, status, report_name=None):
        if report_name:
            query = f"UPDATE {self.table_name} SET status={status} WHERE name='{report_name}'"
        else:
            query = f"UPDATE {self.table_name} SET status={status}"
        self.cursor.execute(query)
        self.db_conn.commit()

        if report_name and status ==1:
            self.update_last_execution_time(report_name)

    def has_report_pending(self):
        records = self.get_pending_report_details()
        return {"report_found": 1 if len(records) else 0}

    def has_report_processing_completed(self):
        records = self.get_pending_report_details()
        return {"report_process_completed": 0 if len(records) else 1}

    def get_report_metadata(self, report_name):
        query = f"SELECT id, api_url, last_execution FROM {self.table_name} where name='{report_name}'"
        self.cursor.execute(query)
        records = self.cursor.fetchall()

        if records:
            record = records[0]
            # api_url = "/reports/grc/ai_embeddings"
            id  = record['id']
            api_url = record['api_url']
            last_execution = record['last_execution']
            # Calculate from_time and to_time
            if last_execution:
                from_time = (last_execution - timedelta(days=8)).strftime("%Y-%m-%d %H:%M:%S")

            else:
                from_time = (datetime.now() - timedelta(hours=self.script_default_hrs)).strftime("%Y-%m-%d %H:%M:%S")

            to_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            ##timestamp
            
            # if last_execution:
            #     from_time = int(last_execution.timestamp())
            # else:
            #     from_time = int((datetime.now() - timedelta(hours=self.script_default_hrs)).timestamp())

            # to_time = int(datetime.now().timestamp())

            # from_time = (datetime.now() - timedelta(days=200)).strftime("%Y-%m-%d %H:%M:%S")
            # to_time = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
            params_time = {
                "from_timestamp": from_time,
                "to_timestamp": to_time
            }

            # Include from_time and to_time in the returned records
            return {
                "id": id,
                "api_url": api_url,
                "params": params_time
            }

        return {}

    def fetch_report_data(self, report_metadata, params):
        count = 0
        curr_page = 1
        all_data = []
        
        params = report_metadata.get("params")
        params.update({"curr_page": 1})
        while True:
            
            # Update the headers with the current page number
            params['curr_page'] = curr_page
            
         
            self.oai.headers['curr_page'] = str(curr_page)
            res = self.oai.api_call(uri=report_metadata.get("api_url"), body=params, headers=self.oai.headers, method="GET")
            print(res)
            if res is None:
                print("Failed to receive a response from the API")
                return None

            print(res.status_code)
            if res.status_code == 200:
                status = res.json().get("error", "")
                if status == 'false':
                    data = res.json().get("data", [])
                    all_data.extend(data)
                    
                    # Check for pagination
                    next_page = res.headers.get('next_page')
                    if next_page and next_page != '0':
                        curr_page = int(res.headers.get('curr_page', curr_page)) + 1
                    else:
                        break  # Exit the loop if no next page
                else:
                    print(report_metadata.get("api_url"))
                    print(f"Error: {res.text}")
                    return None
            else:
                print(report_metadata.get("api_url"))
                print(f"Error: {res.text}")
                return None

        return all_data if all_data else None


    def upsert_data(self, report_data, report_name, skip_existing_record=False):
        report_config = getCSVDetails(report_name)
        batch_size = 999
        total_rows = len(report_data)
        report_config = getCSVDetails(report_name)

        for batch_num in range(0, total_rows+1, batch_size):
            # Delete all existing data
            records = report_data[batch_num: batch_num + batch_size]
            
            mapping_field = report_config["table_field_mapping"]
            print(f'mapping_field: {mapping_field}')
            
            identifiers = report_config["table_identifier"]
            print(f'identifiers: {identifiers}')
            if identifiers:
                # Delete duplicate records
                select_query = get_select_query(report_name, records, mapping_field, identifiers)
                print(select_query)
                self.cursor.execute(select_query)

                existing_records = {"".join([f"{record[mapping_field[key]]}" for key in identifiers]): record for record in self.cursor.fetchall()}
                print("existing_records", existing_records)
                new_records = []
                for record in records:

                    key = "".join([f"{record[key]}" for key in identifiers])

                    if key in existing_records:
                        if not skip_existing_record:
                            update_query = get_update_query(report_name, record, mapping_field, identifiers)
                            print("update_query", update_query)
                            self.cursor.execute(update_query)
                    else:
                        new_records.append(record)
                        # existing_records.append(key)
            else:
                new_records = records

            # insert new records
            if new_records:
                insert_query = get_insert_query(report_name, new_records, mapping_field)
                print("Insert Query", insert_query)
                self.cursor.execute(insert_query)

        self.db_conn.commit()

    def get_report_data_bkp(self, report_name: str, kbox_field, user_field, kbox_to_exclude, user_to_exclude, dashboard_field):
        query = f"SELECT rpt.*, pcm.project_id as Project_ID FROM {report_name} rpt LEFT JOIN project_config_mapping pcm ON rpt.{dashboard_field}=pcm.config_id AND pcm.department NOT IN ('Cybersecurity Services','Pro Services') "
        where_clause = []
    
        if kbox_to_exclude and kbox_field:
            kbox_to_exclude_str = ",".join([f"'{val}'" if isinstance(val, str) else str(val) for val in kbox_to_exclude])
            where_clause.append(f"{kbox_field} NOT IN ({kbox_to_exclude_str})")
    
        if user_to_exclude and user_field:
            user_to_exclude_str = ",".join([f"'{val}'" if isinstance(val, str) else str(val) for val in user_to_exclude])
            where_clause.append(f"{user_field} NOT IN ({user_to_exclude_str})")
    
        UPDATED_PROJECT_STATUSES = ACTIVE_PROJECT_STATUSES + ['Completed']
        project_statuses = ",".join([f'"{sts}"' for sts in UPDATED_PROJECT_STATUSES])
        query += f" AND pcm.project_status IN ({project_statuses})"
      
        if where_clause:
            where_clause_str = " AND ".join(where_clause)
            query += f" WHERE {where_clause_str}"
    
        print("Final query: ", query)
        self.cursor.execute(query)
        data = self.cursor.fetchall()
        print(f"Total number of records: {len(data)}")
        return data

    def get_report_data(self, report_name: str, kbox_field, user_field, kbox_to_exclude, user_to_exclude, dashboard_field, date_field='updated_at'):
        # Query to get active projects excluding 'Completed'
        active_project_query = f"""
            SELECT rpt.*, pcm.project_id as Project_ID 
            FROM {report_name} rpt 
            LEFT JOIN project_config_mapping pcm 
            ON rpt.{dashboard_field} = pcm.config_id 
            AND pcm.department NOT IN ('Cybersecurity Services', 'Pro Services') 
            WHERE pcm.project_status IN ({",".join([f'"{sts}"' for sts in ACTIVE_PROJECT_STATUSES])})
        """
        
        where_clause = []
        
        # Handling kbox exclusions
        if kbox_to_exclude and kbox_field:
            kbox_to_exclude_str = ",".join([f"'{val}'" if isinstance(val, str) else str(val) for val in kbox_to_exclude])
            where_clause.append(f"{kbox_field} NOT IN ({kbox_to_exclude_str})")
        
        # Handling user exclusions
        if user_to_exclude and user_field:
            user_to_exclude_str = ",".join([f"'{val}'" if isinstance(val, str) else str(val) for val in user_to_exclude])
            where_clause.append(f"{user_field} NOT IN ({user_to_exclude_str})")
        
        if where_clause:
            active_project_query += " AND " + " AND ".join(where_clause)

        print("Active Project Query: ", active_project_query)
        self.cursor.execute(active_project_query)
        active_project_data = self.cursor.fetchall()

        # Store the config_ids from active projects
        active_project_config_ids = {record[dashboard_field] for record in active_project_data}

        print(f"Total number of active project records: {len(active_project_data)}")
        
        # Query to get only the latest 'Completed' project per config_id
        if active_project_config_ids:
            completed_project_query = f"""
                SELECT rpt.*, pcm.project_id as Project_ID 
                FROM {report_name} rpt 
                LEFT JOIN project_config_mapping pcm 
                ON rpt.{dashboard_field} = pcm.config_id 
                AND pcm.department NOT IN ('Cybersecurity Services', 'Pro Services') 
                WHERE pcm.project_status = 'Completed' 
                AND pcm.config_id NOT IN ({",".join([str(config_id) for config_id in active_project_config_ids])})
                AND pcm.project_id IN (
                    SELECT MAX(project_id) 
                    FROM project_config_mapping 
                    WHERE project_status = 'Completed' 
                    GROUP BY config_id
                )
            """
            
            if where_clause:
                completed_project_query += " AND " + " AND ".join(where_clause)
            
            print("Completed Project Query: ", completed_project_query)
            self.cursor.execute(completed_project_query)
            completed_project_data = self.cursor.fetchall()

            print(f"Total number of completed project records: {len(completed_project_data)}")
        
            # Combine active and completed project data
            combined_data = list(active_project_data) + list(completed_project_data)
            return combined_data

        return active_project_data


    def write_report_to_sharepoint(self, report_name, report_data):
        '''
            Writing report for Timesheet_Data.csv
        '''
        response = {'error':False,'msg':'Data not found'}


        report_config = getCSVDetails(report_name)
        kbox_field = report_config["kbox_field"]
        user_field = report_config["user_field"]
        dashboard_field = report_config["dashboard_field"]
        ## Get sharepoint configs ##
        sharepoint_configs = get_sharepoint_configs('BI')

        report_config.update({"sharepoint_host":sharepoint_host, 'sharepoint_site_url':sharepoint_host+"/sites/"+sharepoint_configs['site_name'],"doc_base_library":sharepoint_configs['doc_base_library']})

        csv_data = []
        refresh_date_time = datetime.now()
        if report_data != None and len(report_data)>0:
            self.upsert_data(report_data, report_name, skip_existing_record=False)
            print("insert Done")
        report_data_from_db = self.get_report_data(report_name, kbox_field, user_field, kbox_to_exclude, user_to_exclude, dashboard_field)
        print('report_data_from_db' , report_data_from_db)
        for idx, row in enumerate(report_data_from_db):
            fields_mapping = report_config.get("fields_mapping")
            csv_header = report_config.get("csv_header")
            data = []
            for col in csv_header:
                data.append(row[fields_mapping[col]])

            csv_data.append(data)


        print(csv_data)


        # Writing data into csv file
        if len(csv_data)>0:

            # ## object invokation
            fn_obj = CSVEditor(report_config)

            ## Check if file exist
            if fn_obj.csvExist():
                csv_created = fn_obj.deleteOldCSV(fn_obj.s3_file_name)

            csv_created = fn_obj.createCSVWithHeaders()
            s3_file_name = fn_obj.writeDataToCSV(csv_data)
            response['error'] = fn_obj.upload_s3_report_to_sharepoint('BI')
            response['msg'] = s3_file_name

        else:
            response['msg'] = "No data found for report"

        return response

    def fetch_and_generate_report(self, report_name, params):

        metadata = self.get_report_metadata(report_name)
       
        self.update_report_status(1, report_name)
        # if report_name in ["ai_time_details", "questions_usage"]:
	    #     report_data = self.fetch_report_data(metadata, params)
	    #     print('report_data' , report_data)
        # else:
        #     report_data = []

        report_data = self.fetch_report_data(metadata, params) or []
        print('report_data' , report_data)
        resp = self.write_report_to_sharepoint(report_name, report_data)
        self.db_conn.close()
        return resp

    def mark_all_report_completed(self):
        self.update_report_status(0)

    def create_db(self):

        # query = "ALTER TABLE questions_usage ADD COLUMN inst_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE questions_usage ADD COLUMN response_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE thumbs_up_down ADD COLUMN smileback_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE thumbs_up_down ADD COLUMN response_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE ai_success_failure_count ADD COLUMN inst_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE ai_success_failure_count ADD COLUMN inst_dash_map_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE ai_pre_checks_status ADD COLUMN response_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE ai_pre_checks_status ADD COLUMN response_detail_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE ai_pre_checks_status ADD COLUMN inst_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE pre_checks_view_details ADD COLUMN ai_pvl_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE pre_checks_view_details ADD COLUMN inst_id INT"
        # self.cursor.execute(query)

        # query = "ALTER TABLE thumbs_up_down ADD COLUMN response_detail_id INT(10) UNSIGNED NOT NULL DEFAULT '0'," \
        # "ALTER TABLE thumbs_up_down ADD COLUMN link_code VARCHAR(250) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci;"
        # self.cursor.execute(query)        
        

        # query = "DROP TABLE ai_reports_manager;"
        # self.cursor.execute(query)

        # query = """CREATE TABLE ai_reports_manager (
        #     id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
        #     name varchar(100) NOT NULL,
        #     api_url varchar(100) NOT NULL,
        #     params varchar(100) NOT NULL,
        #     status int DEFAULT 0,
        #     last_execution TIMESTAMP,
        #     created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        #     modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        # );"""
        # self.cursor.execute(query)

        # query = "DROP TABLE questions_usage;"
        # self.cursor.execute(query)

        # query ="""CREATE TABLE IF NOT EXISTS questions_usage (
        #         id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
        #         KBOX VARCHAR(255) NOT NULL,
        #         Dashboard_ID INT NOT NULL,
        #         Dashboard_Name VARCHAR(255) NOT NULL,
        #         Uploaded_On DATE NOT NULL,
        #         Question_Number INT NOT NULL,
        #         Uploaded_By VARCHAR(255) NOT NULL,
        #         Precheck_Status VARCHAR(255) NOT NULL,
        #         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        #     );"""
        # self.cursor.execute(query)

        # query = "DROP TABLE thumbs_up_down;"
        # self.cursor.execute(query)

        # query ="""CREATE TABLE IF NOT EXISTS thumbs_up_down (
        #         id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
        #         KBOX VARCHAR(255) NOT NULL,
        #         Dashboard_ID INT NOT NULL,
        #         Dashboard_Name VARCHAR(255) NOT NULL,
        #         Precheck_Type VARCHAR(255) NOT NULL,
        #         Date DATE NOT NULL,
        #         Precheck_ID INT NOT NULL,
        #         Precheck_Text TEXT NOT NULL,
        #         Question_Number INT NOT NULL,
        #         User_Email VARCHAR(255) NOT NULL,
        #         Thumbs_Up_Down VARCHAR(10) NOT NULL,
        #         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        #     );"""
        # self.cursor.execute(query)

        query = "DROP TABLE IF EXISTS ai_embeddings;"
        self.cursor.execute(query)

        query = """
        CREATE TABLE IF NOT EXISTS ai_embeddings (
            id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
            KBOX VARCHAR(255) NOT NULL,
            Dashboard_ID INT(10) NOT NULL,
            Dashboard_Name VARCHAR(255) NOT NULL,
            Inst_ID INT NOT NULL,
            Uploaded_On DATE NOT NULL,
            Question_Number INT(10) NOT NULL,
            Uploaded_From ENUM('grc','api','policy') NOT NULL DEFAULT 'grc' COLLATE utf8mb4_unicode_ci,
            File_Master_ID INT(10) UNSIGNED NOT NULL,
            File_Name VARCHAR(250) NOT NULL COLLATE utf8mb4_unicode_ci,
            File_Hash VARCHAR(100) NOT NULL COLLATE utf8mb4_unicode_ci,
            Random_Name VARCHAR(250) NOT NULL COLLATE utf8mb4_unicode_ci,
            AI_Embeddings_Status ENUM('NotStarted','Initialized','Generated','Failed','Deleted','NotSupported') NOT NULL DEFAULT 'NotStarted' COLLATE utf8mb4_unicode_ci,
            AI_Embeddings_Reason TEXT NULL DEFAULT NULL COLLATE utf8mb4_unicode_ci,
            AI_Embd_Start_Time TIMESTAMP NULL DEFAULT NULL,
            AI_Embd_End_Time TIMESTAMP NULL DEFAULT NULL,
            Retry_Attempts TINYINT(3) NULL DEFAULT 0
        );
        """
        self.cursor.execute(query)


        

        # query = "DROP TABLE ai_success_failure_count;"
        # self.cursor.execute(query)

        # query ="""CREATE TABLE IF NOT EXISTS ai_success_failure_count (
        #         id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
        #         KBOX VARCHAR(255) NOT NULL,
        #         Dashboard_ID INT NOT NULL,
        #         Dashboard_Name VARCHAR(255) NOT NULL,
        #         Precheck_Success INT NOT NULL,
        #         Precheck_Error INT NOT NULL,
        #         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        #     );"""
        # self.cursor.execute(query)

        # query = "DROP TABLE IF EXISTS ai_time_details;"
        # self.cursor.execute(query)

        # query ="""CREATE TABLE IF NOT EXISTS ai_time_details (
        #         id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
        #         KBOX VARCHAR(255) NOT NULL,
        #         Dashboard_ID INT NOT NULL,
        #         Dashboard_Name VARCHAR(255),
        #         Question_Number INT NOT NULL,
        #         Regulation VARCHAR(255),
        #         AI_Full_Partial VARCHAR(255) NOT NULL,
        #         Current_Year_Accept_Time VARCHAR(255),
        #         Last_Year_Accept_Time VARCHAR(255),
        #         Current_Year_Total_Time VARCHAR(255),
        #         Last_Year_Total_Time VARCHAR(255),
        #         Current_Year_Iterations INT NOT NULL,
        #         Last_Year_Iterations INT NOT NULL,
        #         Current_Year_QA_Iterations INT NOT NULL,
        #         Last_Year_QA_Iterations INT NOT NULL,
        #         Current_Year_QA_Time VARCHAR(255),
        #         Last_Year_QA_Time VARCHAR(255),
        #         Was_Pre_Check_viewed_by_Assessor VARCHAR(255),
        #         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        #         Assessor_changed_status_UE_TO_ABA_OR_AQA VARCHAR(255)
        #     );"""
        # self.cursor.execute(query)

        # query = "DROP TABLE ai_pre_checks_status;"
        # self.cursor.execute(query)

        # query ="""CREATE TABLE IF NOT EXISTS ai_pre_checks_status (
        #         id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
        #         KBOX VARCHAR(255) NOT NULL,
        #         Dashboard_ID INT NOT NULL,
        #         Dashboard_Name VARCHAR(255),
        #         Question_Number INT NOT NULL,
        #         Precheck_ID INT NOT NULL,
        #         Precheck_Text TEXT NOT NULL,
        #         Date_Precheck_Performed DATE NOT NULL,
        #         Precheck_Status VARCHAR(255) NOT NULL,
        #         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        #     );"""
        # self.cursor.execute(query)

        # query = "DROP TABLE pre_checks_view_details;"
        # self.cursor.execute(query)

        # query ="""CREATE TABLE IF NOT EXISTS pre_checks_view_details (
        #         id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
        #         KBOX VARCHAR(255) NOT NULL,
        #         Dashboard_ID INT NOT NULL,
        #         Dashboard_Name VARCHAR(255) NOT NULL,
        #         Question_Number INT NOT NULL,
        #         Precheck_View_Date DATE NOT NULL,
        #         User VARCHAR(255) NOT NULL,
        #         Response_ID INT NOT NULL,
        #         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        #     );"""
        # self.cursor.execute(query)

        # query = """INSERT INTO ai_reports_manager(name, api_url, status) VALUES('questions_usage', '/oai/reports/grc/questions_usage', 0)"""
        # self.cursor.execute(query)
        # query = """INSERT INTO ai_reports_manager(name, api_url, status) VALUES('thumbs_up_down', '/oai/reports/grc/thumbs_up_down', 0)"""
        # self.cursor.execute(query)
        # query = """INSERT INTO ai_reports_manager(name, api_url, status) VALUES('ai_success_failure_count', '/oai/reports/grc/ai_success_failure_count', 0)"""
        # self.cursor.execute(query)
        # query = """INSERT INTO ai_reports_manager(name, api_url, status) VALUES('ai_time_details', '/oai/reports/grc/ai_time_details', 0)"""
        # self.cursor.execute(query)
        # query = """INSERT INTO ai_reports_manager(name, api_url, status) VALUES('ai_pre_checks_status', '/oai/reports/grc/ai_pre_checks_status', 0)"""
        # self.cursor.execute(query)
        # query = """INSERT INTO ai_reports_manager(name, api_url, status) VALUES('pre_checks_view_details', '/oai/reports/grc/pre_checks_view_details', 0)"""
        # self.cursor.execute(query)
        query = """INSERT INTO ai_reports_manager(name, api_url, status) VALUES('ai_embeddings', '/oai/reports/grc/ai_embeddings', 0)"""
        self.cursor.execute(query)

        self.db_conn.commit()

        return {
            "msg": "Table Processed successfully."
        }


    def update_last_execution_time(self,report_name):
        # Update the last_execution time for the given ID
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        update_query = f"UPDATE ai_reports_manager SET last_execution = '{current_time}' WHERE name='{report_name}'"
        self.cursor.execute(update_query)
        self.db_conn.commit()

