from typing import Dict, Optional, Any, List

import requests

from config import OA_HOST, OAI_X_API_KEY

class OASetup:
	def __init__(self):
		self.base_uri = OA_HOST # value derived from global variable
		self.headers = {
			'Content-Type': 'application/json',
			'x-api-key': OAI_X_API_KEY,
		}

	def api_call(self, uri: str, body: Dict[str, Any], headers: Optional[Dict[str, Any]] = None,
				method: Optional[str] = "POST"):

		headers = headers or {"Content-Type": "application/json"}
		print(headers, body, f"{self.base_uri}{uri}", method)

		try:
			if method.upper() == "GET":
				# For GET requests, construct the URL with parameters in the query string
				url = f"{self.base_uri}{uri}?{'&'.join([f'{key}={value}' for key, value in body.items()])}"
				print(url)
				response = requests.get(url, headers=headers)
			else:
				# For other methods (default to POST), send data in the request body
				response = requests.request(method, headers=headers, url=f"{self.base_uri}{uri}", json=body)
			# response = requests.request(method, headers=headers, url=f"{self.base_uri}{uri}", data=body)
			response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
			return response
		except requests.exceptions.RequestException as e:
			print(f"Error making API call: {e}")
			return None

	def extract_data_from_response(self, response):
		try:
			return response.json().get("data", {})
		except json.JSONDecodeError as e:
			print(f"Error decoding JSON response: {e}")
			return {}

	def create_instance(self, tpl_id, inst_name, dashboard_id, regln_id, workflow_id):
		print("Entered create_instance")
		metadata = {
			"uri": f"{self.url}instances",
			"body": json.dumps({"tpl_id": tpl_id,
					"inst_name": inst_name,
					"dashboard_mapping": [
						{
							"dashboard_id": dashboard_id,
							"regln_id": regln_id,
							"workflow_id": workflow_id
						}
					],
					"dashboard_permission": "disabled"
					}),
			"headers": self.headers,
			"method": "POST"
		}

		res = self.api_call(metadata.get("uri"), metadata.get("body"), metadata.get("headers"), metadata.get("method"))
		print("res---------",res.json())

		data = self.extract_data_from_response(res)
		if data.get("error") == 'false':
			return data.get("id")
		else:
			print(f"Error: {data.get('message')}")
		return None

	def assign_cust_group_to_cust_admin_role(self, users: List[str], groups: List[str]):
		
		metadata = {
			"uri": f"{self.url}roles/1/access",
			"body": json.dumps({
				"user_id": 1,
				"users": users, # it is a list
				"groups": groups # it is a list
			}),
			"headers": self.headers,
			"method": "POST"
		}

		res = self.api_call(metadata.get("uri"), metadata.get("body"), metadata.get("headers"), metadata.get("method"))
		if res.status_code == 200:
			# Extract the link code from the response JSON
			status = res.json().get("error", "")
			if status == 'false':
				id = res.json().get("data", {}).get("id")

				print(f"access_updated")
				return id
			else:
				print(metadata.get("uri"))
				print(f"Error: {res.text}")
				return None
				
		else:
			print(metadata.get("uri"))
			print(f"Error: {res.text}")
			return None

	def get_link_details(self):
		metadata = {
			"uri": f"{self.url}instances/links",
			"body": "",
			"headers": self.headers,
			"method": "GET"
		}

		res = self.api_call(metadata.get("uri"), metadata.get("body"), metadata.get("headers"), metadata.get("method"))
		if res:
			data = self.extract_data_from_response(res)
			link_id = data.get("link_id")
			if link_id:
				print(f"Link id: {link_id}")
				return link_id
			else:
				print(f"Error: {data.get('message')}")
		return None

	def get_current_access_details(self, link_id):
		metadata = {
			"uri": f"{self.url}instances/links/{link_id}/access",
			"body": "",
			"headers": self.headers,
			"method": "GET"
		}

		res = self.api_call(metadata.get("uri"), metadata.get("body"), metadata.get("headers"), metadata.get("method"))

		if res:
			data = self.extract_data_from_response(res)
			first_item = data[0]
			users = first_item.get("users", [])
			groups = first_item.get("groups", [])
			print(f"Existing users: {users}")
			print(f"Existing groups: {groups}")
			return users, groups
		return [], []

	def update_link_mapping(self, link_id: str, users: List[str], groups: List[str]):
		metadata = {
			"uri": f"{self.url}instances/links/{link_id}/access",
			"body": json.dumps({
					"users": users, # it is a list of integer
					"groups": groups # it is a list of integer
				}),
			"headers": self.headers,
			"method": "POST"
		}

		res = self.api_call(metadata.get("uri"), metadata.get("body"), metadata.get("headers"), metadata.get("method"))
		if res:
			print(f"Link mapping updated successfully")
		else:
			print(f"Error updating link mapping: {res.text}")