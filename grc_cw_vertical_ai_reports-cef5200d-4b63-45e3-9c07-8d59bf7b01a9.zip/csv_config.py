import os

#csv config
TEMP_PATH = '/tmp/'
SCRIPT_FOLDER = ''
CSV_FILENAME = ''
TEMP_FILEPATH = TEMP_PATH+CSV_FILENAME

# S3_BUCKET_FOR_TEMP_SLA = os.environ['S3_BUCKET_FOR_TEMP_REPORT']

CSV_HEADERS = []


def getCSVDetails(report_name='questions_usage'):

	csv_file_name = ''
	if report_name.lower() == 'questions_usage':

		csv_header = [
				'KBOX',
				'Dashboard ID',
				'Dashboard Name',
				'Uploaded On',
				'Question Number',
				'Uploaded By',
				'AI Precheck Status',
				'Project ID',
				'Inst ID',
				'Response ID',
				'Beta' 
			]

		fields_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Uploaded On": "Uploaded_On",
			"Question Number": "Question_Number",
			"Version": "beta",
			"Uploaded By": "Uploaded_By",
			"AI Precheck Status": "Precheck_Status",
			'Project ID': "Project_ID",
			"Beta": "beta",
			"Inst ID": "inst_id",
			"Response ID": "response_id",
		}

		# table_identifier = ["KBOX", "Dashboard ID", "Question Number", "Uploaded By", "Uploaded On"]
		table_identifier = ["KBOX", "inst_id", "response_id", "Dashboard ID", "Question Number"]

		table_field_mapping = {
			"KBOX":"KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name":"Dashboard_Name",
			"Uploaded On":"Uploaded_On",
			"Question Number": "Question_Number",
			"Uploaded By": "Uploaded_By",
			"Pre-check Status": "Precheck_Status",
			"Beta": "beta",
			"Version": "beta",
			"inst_id": "inst_id",
			"response_id": "response_id",
			"created_at": "created_at",
		}
		kbox_field = "KBOX"
		user_field = "Uploaded_By"
		dashboard_field = "Dashboard_ID"
		# {'': '3427', 'Dashboard ID': 4639, 'Dashboard Name': 'Test Hipaa Dashboard', 'Uploaded On': '2023-11-15', 'Question Number': 76, 'Uploaded By': 'ranjan.singh@controlcase.com', 'Pre-check Status': 'initiated'}

		csv_file_name = 'questions_usage.csv'

	elif report_name.lower() == 'thumbs_up_down':

		csv_header = [
				'KBOX',
				'Dashboard ID',
				'Dashboard Name',
				'Check_Type (System/User)',
				'Date',
				'AI Check ID',
				'Question Number',
				'User Email Address',
				'Thumbs Up/Down',
				'Project ID',
				'Smileback ID',
				'Response ID',
				'Beta',
				'Thumbs Down Reason',
				'Pre-check Text',
				'Response Detail ID',
				'Link Code'

			]

		# table_identifier = ["KBOX", "Dashboard ID", "Question Number"]
		table_identifier = ["KBOX", "smileback_id", "response_id"]

		fields_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Check_Type (System/User)": "Precheck_Type",
			"Date": "Date",
			"AI Check ID": "Precheck_ID",
			"Pre-check Text": "Precheck_Text",
			"Question Number": "Question_Number",
			"User Email Address": "User_Email",
			"Thumbs Up/Down": "Thumbs_Up_Down",
			'Project ID': "Project_ID",
			"Beta": "beta",
			"Version": "beta",
			"Thumbs Down Reason": "Thumbs_Down_Reason",
			"Smileback ID": "smileback_id",
			"Response ID": "response_id",
			"Response Detail ID": "response_detail_id",
			"Link Code": "link_code"
		}

		table_field_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Pre-check Type (System/User)": "Precheck_Type",
			"Date": "Date",
			"Pre-check ID": "Precheck_ID",
			"Pre-check Text": "Precheck_Text",
			"Question Number": "Question_Number",
			"User": "User_Email",
			"Thumbs Up/Down": "Thumbs_Up_Down",
			"Beta": "beta",
			"Version": "beta",
			"Thumbs Down Reason": "Thumbs_Down_Reason",
			"created_at": "created_at",
			"smileback_id": "smileback_id",
			"response_id": "response_id",
			"response_detail_id":"response_detail_id",
			"link_code": "link_code"			
		}

		kbox_field = "KBOX"
		user_field = "User_Email"
		dashboard_field = "Dashboard_ID"

		csv_file_name = 'thumbs_up_down.csv'
	
	elif report_name.lower() == 'ai_embeddings':
		csv_header = [
			'KBOX',
			'Dashboard ID',
			'Dashboard Name',
			'Inst ID',
			'Uploaded On',
			'Question Number',
			'Uploaded From',
			'File Master ID',
			'File Name',
			'File Hash',
			'Random Name',
			'AI Embedding Status',
			'AI Embedding Reason',
			'AI Embedding Start Time',
			'AI Embedding End Time',
			'Retry Attempts'
		]
		table_identifier = ["KBOX","Dashboard ID","Inst ID", "Question Number","File Master ID"]

		fields_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Inst ID": "Inst_ID",
			"Uploaded On":"Uploaded_On",
			"Question Number": "Question_Number",
			"Uploaded From": "Uploaded_From",
			"File Master ID": "File_Master_ID",
			"File Name": "File_Name",
			"File Hash": "File_Hash",
			"Random Name": "Random_Name",
			"AI Embeddings Status": "AI_Embeddings_Status",
			"AI Embeddings Reason": "AI_Embeddings_Reason",
			"AI Embd Start Time": "ai_embd_start_time",
			"AI Embd End Time": "AI_Embd_End_Time",
			"Retry Attempts": "Retry_Attempts"
		}

		table_field_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Inst ID": "Inst_ID",
			"Uploaded On":"Uploaded_On",
			"Question Number": "Question_Number",
			"Uploaded From": "Uploaded_From",
			"File Master ID": "File_Master_ID",
			"File Name": "File_Name",
			"File Hash": "File_Hash",
			"Random Name": "Random_Name",
			"AI Embeddings Status": "AI_Embeddings_Status",
			"AI Embeddings Reason": "AI_Embeddings_Reason",
			"AI Embd Start Time": "AI_Embd_Start_Time",
			"AI Embd End Time": "AI_Embd_End_Time",
			"Retry Attempts": "Retry_Attempts"
		}

		kbox_field = "KBOX"
		user_field = "User_Email"
		dashboard_field = "Dashboard_ID"

		csv_file_name = 'ai_embeddings.csv'

	elif report_name.lower() == 'ai_success_failure_count':

		csv_header = [
				'KBOX',
				'Dashboard ID',
				'Dashboard Name',
				'AI Precheck Success',
				'AI Precheck Error',
				"Project ID",
				"Inst ID",
				"Inst Dash Map ID",
				"Beta"
			]

		fields_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"AI Precheck Success": "Precheck_Success",
			"AI Precheck Error": "Precheck_Error",
			"Project ID": "Project_ID",
			"Beta": "beta",
			"Inst ID": "inst_id",
			"Inst Dash Map ID": "inst_dash_map_id",
		}

		# table_identifier = ["KBOX", "Dashboard ID"]
		table_identifier = ["KBOX", "inst_id", "inst_dash_map_id"]

		table_field_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Pre-check Success": "Precheck_Success",
			"Pre-check Error": "Precheck_Error",
			"Beta": "beta",
			"inst_id": "inst_id",
			"inst_dash_map_id": "inst_dash_map_id"
		}
		kbox_field = "KBOX"
		user_field = None
		dashboard_field = "Dashboard_ID"
		csv_file_name = 'ai_success_failure_count.csv'

	elif report_name.lower() == 'ai_time_details':

		csv_header = [
				'Kbox_Number',
				'Dashboard ID',
				'Dashboard_Name',
				'Question Number',
				'Regulation',
				'AI - Full/Partial',
				'Was Pre-Check viewed by Assessor',
				'Current Year - Accept Time in days (Under Evaluation to Accepted by Assessor/Assigned to QA)',
				'Last Year - Accept Time in days (Under Evaluation to Accepted by Assessor/Assigned to QA)',
				'Current Year - Total Time in days (Under Evaluation to Pass/Pass with Comments)',
				'Last Year - Total Time in days - (Under Evaluation to Pass/Pass with Comments)',
				'current Year - Iterations (Under Evaluation to Incomplete Information in 1 iteration)',
				'Last Year - Iterations (Under Evaluation to Incomplete Information in 1 iteration)',
				'Current Year - Iterations (Assigned for QA to Under Evaluation is 1 iteration)',
				'Last Year - Iterations (Assigned for QA to Under Evaluation is 1 iteration)',
				'Current Year - Time in days (Assigned for QA to Pass/Pass with comments)',
				'Last Year - Time in days (Assigned for QA to Pass/Pass with comments)',
				"Assessor_changed_status_UE_TO_ABA_OR_AQA",
				'Project ID',
				"Beta" 
			]

		fields_mapping = {
			"Kbox_Number":"KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard_Name": "Dashboard_Name",
			"Question Number": "Question_Number",
			"Regulation": "Regulation",
			"AI - Full/Partial": "AI_Full_Partial",
			"Was Pre-Check viewed by Assessor": "Was_Precheck_Viewed_By_Assessor",
			"Current Year - Accept Time in days (Under Evaluation to Accepted by Assessor/Assigned to QA)": "Current_Year_Accept_Time",
			"Last Year - Accept Time in days (Under Evaluation to Accepted by Assessor/Assigned to QA)": "Last_Year_Accept_Time",
			"Current Year - Total Time in days (Under Evaluation to Pass/Pass with Comments)": "Current_Year_Total_Time",
			"Last Year - Total Time in days - (Under Evaluation to Pass/Pass with Comments)": "Last_Year_Total_Time",
			"current Year - Iterations (Under Evaluation to Incomplete Information in 1 iteration)": "Current_Year_Iterations",
			"Last Year - Iterations (Under Evaluation to Incomplete Information in 1 iteration)": "Last_Year_Iterations",
			"Current Year - Iterations (Assigned for QA to Under Evaluation is 1 iteration)": "Current_Year_QA_Iterations",
			"Last Year - Iterations (Assigned for QA to Under Evaluation is 1 iteration)": "Last_Year_QA_Iterations",
			"Current Year - Time in days (Assigned for QA to Pass/Pass with comments)": "Current_Year_QA_Time",
			"Last Year - Time in days (Assigned for QA to Pass/Pass with comments)": "Last_Year_QA_Time",
			"Assessor_changed_status_UE_TO_ABA_OR_AQA": "Assessor_changed_status_UE_TO_ABA_OR_AQA",
			"Project ID": "Project_ID",
			"Beta": "beta",
			"Version": "beta",
		}

		table_identifier = ["KBOX", "Dashboard ID", "Question Number","Regulation"]
		table_field_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Question Number": "Question_Number",
			"Regulation": "Regulation",
			"AI - Full/Partial": "AI_Full_Partial",
			"Was Pre-Check viewed by Assessor":"Was_Precheck_Viewed_By_Assessor",
			"Current Year - Accept Time": "Current_Year_Accept_Time",
			"Last Year - Accept Time": "Last_Year_Accept_Time",
			"Current Year - Total Time": "Current_Year_Total_Time",
			"Last Year - Total Time": "Last_Year_Total_Time",
			"Current Year - Iterations": "Current_Year_Iterations",
			"Last Year - Iterations": "Last_Year_Iterations",
			"Current Year - QA Iterations": "Current_Year_QA_Iterations",
			"Last Year - QA Iterations": "Last_Year_QA_Iterations",
			"Current Year - QA Time": "Current_Year_QA_Time",
			"Last Year - QA Time": "Last_Year_QA_Time",
			"Was Pre-Check viewed by Assessor": "Was_Precheck_Viewed_By_Assessor",
			"Assessor_changed_status_UE_TO_ABA_OR_AQA": "Assessor_changed_status_UE_TO_ABA_OR_AQA",
			"Beta": "beta",
			"Version": "beta",
		}
		kbox_field = "KBOX"
		user_field = None
		dashboard_field = "Dashboard_ID"
		csv_file_name = 'ai_time_details.csv'

	elif report_name.lower() == 'ai_pre_checks_status':

		csv_header = [
				'KBOX',
				'Dashboard ID',
				'Dashboard Name',
				'Question Number',
				'AI Pre-Check ID',
				'AI Pre-check',
				'Date Pre-check Performed',
				'Pre-check Status',
				"Project ID",
				"Inst ID",
				"Response ID",
				"Response Detail ID",
				"Beta" 
			]

		fields_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Question Number": "Question_Number",
			"AI Pre-Check ID": "Precheck_ID",
			"AI Pre-check": "Precheck_Text",
			"Date Pre-check Performed": "Date_Precheck_Performed",
			"Pre-check Status": "Precheck_Status",
			"Project ID": "Project_ID",
			"Beta": "beta",
			"Version": "beta",
			"Inst ID": "inst_id",
			"Response ID": "response_id",
			"Response Detail ID": "response_detail_id",			
		}

		# table_identifier = ["KBOX", "Dashboard ID","Question Number","Pre-check ID"]
		table_identifier = ["KBOX", "inst_id", "response_id", "response_detail_id"]

		table_field_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Question Number": "Question_Number",
			"Pre-check ID": "Precheck_ID",
			"Pre-check Text": "Precheck_Text",
			"Date Pre-check Performed": "Date_Precheck_Performed",
			"Pre-check Status": "Precheck_Status",
			"Beta": "beta",
			"Version": "beta",
			"inst_id": "inst_id", 
			"response_id": "response_id", 
			"response_detail_id": "response_detail_id",
			"created_at": "created_at",
		}

		kbox_field = "KBOX"
		user_field = None
		dashboard_field = "Dashboard_ID"
		csv_file_name = 'ai_pre_checks_status.csv'

	elif report_name.lower() == 'pre_checks_view_details':

		csv_header = [
				'KBOX',
				'Dashboard ID',
				'Dashboard Name',
				'Pre-Check View Date',
				'Question Number',
				'User Email Address',
				'Response ID',
				"Project ID",
				"AI PVL ID",
				"Inst ID",
				"Beta" 
			]

		fields_mapping = {
				"KBOX": "KBOX",
				"Dashboard ID": "Dashboard_ID",
				"Dashboard Name": "Dashboard_Name",
				"Pre-Check View Date": "Precheck_View_Date",
				"Question Number": "Question_Number",
				"User Email Address": "User",
				"Response ID": "Response_ID",
				"Project ID": "Project_ID",
				"Beta": "beta",
				"Version": "beta",
				"AI PVL ID": "ai_pvl_id",
				"Inst ID": "inst_id",
			}

		# table_identifier = ["KBOX", "Dashboard ID","Question Number"]
		table_identifier = ["KBOX", "inst_id", "Response ID", "ai_pvl_id"]

		table_field_mapping = {
			"KBOX": "KBOX",
			"Dashboard ID": "Dashboard_ID",
			"Dashboard Name": "Dashboard_Name",
			"Question Number": "Question_Number",
			"Pre-check View Date": "Precheck_View_Date",
			"User": "User",
			"Response ID": "Response_ID",
			"Beta": "beta",
			"Version": "beta",
			"inst_id": "inst_id", 
			"ai_pvl_id": "ai_pvl_id",
		}

		kbox_field = "KBOX"
		user_field = "User"
		dashboard_field = "Dashboard_ID"
		csv_file_name = 'pre_checks_review_status.csv'

	elif report_name.lower() == 'ai_alert_report':

		csv_header = [
			'KBOX', 'Transaction ID', 'Dashboard ID', 'Dashboard Name', 'Inst ID', 'Inst Name',
			'Question Number', 'AI Alert', 'Assessor Status', 'AI Worked',
			'Assessor Email', 'Regln ID', 'Tran Created On', 'Tran Modified On'
		]

		fields_mapping = {
			'KBOX': 'KBOX',
			'Transaction ID': 'transaction_id',
			'Dashboard ID': 'dashboard_id',
			'Dashboard Name': 'dashboard_name',
			'Inst ID': 'inst_id',
			'Inst Name': 'inst_name',
			'Question Number': 'question_number',
			'AI Alert': 'ai_alert',
			'Assessor Status': 'assessor_status',
			'AI Worked': 'ai_worked',
			'Assessor Email': 'assessor_email',
			'Regln ID': 'regln_id',
			'Tran Created On': 'tran_created_on',
			'Tran Modified On': 'trans_modified_on'
		}

		table_identifier = ['KBOX', 'Transaction ID', 'Regln ID']

		table_field_mapping = {
			'KBOX': 'KBOX',
			'Transaction ID': 'transaction_id',
			'Dashboard ID': 'dashboard_id',
			'Dashboard Name': 'dashboard_name',
			'Inst ID': 'inst_id',
			'Inst Name': 'inst_name',
			'Question Number': 'question_number',
			'AI Alert': 'ai_alert',
			'Assessor Status': 'assessor_status',
			'AI Worked': 'ai_worked',
			'Assessor Email': 'assessor_email',
			'Regln ID': 'regln_id',
			'Tran Created On': 'tran_created_on',
			'Tran Modified On': 'trans_modified_on'
		}

		kbox_field = 'KBOX'
		user_field = 'assessor_email'
		dashboard_field = 'dashboard_id'
		csv_file_name = 'ai_alert_report.csv'

	report_config = {
		"script_folder": 'Database Files', ## decide later
		"sub_folder": 'AI Reports',
		"csv_filename": csv_file_name,
		"csv_header": csv_header,
		"fields_mapping": fields_mapping,
		"table_field_mapping": table_field_mapping,
		"table_identifier": table_identifier,
		"kbox_field": kbox_field,
		"user_field": user_field,
		"dashboard_field": dashboard_field
	}
	return report_config




def getFeedbackCSVDetails(report_name='type_1_rejection'):

	csv_file_name = ''
	if report_name.lower() in ['type_1_rejection','type_2_rejection']:

		csv_header = [
				'Portal Number',
				'Client Name',
				'Email Address',
				'Response Time',
				"Beta"
			]

		fields_mapping = {
			'Portal Number':'portal_number',
			'Client Name':'client_name',
			'Email Address':'email_address',
			'Response Time':'response_time',
			"Beta": "beta"

		}

		table_field_mapping = {
			'Portal Number':'portal_number',
			'Client Name':'client_name',
			'Email Address':'email_address',
			'Response Time':'response_time',
			"Beta": "beta"
		}

		csv_file_name = 'survey_type_1_rejection.csv'
		if report_name.lower() == 'type_2_rejection':
			csv_file_name = 'survey_type_2_rejection.csv'

	if report_name.lower() in ['type_1_all', 'type_2_all']:

		if report_name.lower() == 'type_1_all':

			csv_header = [
					'Portal Number',
					'Client Name',
					'Email Address',
					'Response Time',
					"Please rate your experience with our user interface and dashboard.",
					"We Promise to do better,  Please take out a few minutes to help us improve.",
					"Beta"
				]

			fields_mapping = {
				'Portal Number':'portal_number',
				'Client Name':'client_name',
				'Email Address':'email_address',
				'Response Time':'response_time',
				"Please rate your experience with our user interface and dashboard.":"rate_your_experience",
				"We Promise to do better,  Please take out a few minutes to help us improve.":"help_us_improve",
				"Beta": "beta"

			}

			table_field_mapping = {
				'Portal Number':'portal_number',
				'Client Name':'client_name',
				'Email Address':'email_address',
				'Response Time':'response_time',
				"Please rate your experience with our user interface and dashboard.":"rate_your_experience",
				"We Promise to do better,  Please take out a few minutes to help us improve.":"help_us_improve",
				"Beta": "beta"
			}

		if report_name.lower() == 'type_2_all':
			csv_header = [
					'Portal Number',
					'Client Name',
					'Email Address',
					'Response Time',
					"Please rate your experience with our AI Pre-checks Assistant",
					"We Promise to do better,  Please take out a few minutes to help us improve.",
					"Beta"
				]

			fields_mapping = {
				'Portal Number':'portal_number',
				'Client Name':'client_name',
				'Email Address':'email_address',
				'Response Time':'response_time',
				"Please rate your experience with our AI Pre-checks Assistant":"rate_your_experience",
				"We Promise to do better,  Please take out a few minutes to help us improve.":"help_us_improve",
				"Beta": "beta"

			}

			table_field_mapping = {
				'Portal Number':'portal_number',
				'Client Name':'client_name',
				'Email Address':'email_address',
				'Response Time':'response_time',
				"Please rate your experience with our AI Pre-checks Assistant":"rate_your_experience",
				"We Promise to do better,  Please take out a few minutes to help us improve.":"help_us_improve",
				"Beta": "beta"
			}

		csv_file_name = 'survey_type_1_all.csv'
		if report_name.lower() == 'type_2_all':
			csv_file_name = 'survey_type_2_all.csv'

	report_config = {
		"script_folder": 'Database Files', ## decide later
		"sub_folder": 'AI Reports',
		"csv_filename": csv_file_name,
		"csv_header": csv_header,
		"fields_mapping": fields_mapping,
		"table_field_mapping": table_field_mapping
	}
	return report_config


def getReportHandlerConfig(report_name='get_exported_best_practice_report'):
	# Configuration for reports
	reports_config = {
		'get_download_certificate_report': {
			'csv_header': [
				'KBOX',
				'Dashboard ID',
				'Dashboard Name',
				'User ID',
				'Email',
				'Count',
				"last_accessed_time",
				"Project ID"
			],
			'fields_mapping': {
				"KBOX": "kbox",
				"Dashboard ID": "dashboard_id",
				"Dashboard Name": "dashboard_name",
				"User ID": "user_id",
				"Email": "email",
				"Count": "count",
				"last_accessed_time":"last_accessed_time",
				"Project ID" : "Project_ID"
			},
			'table_name': 'download_certificate_report',
			'table_identifier': ["KBOX", "Dashboard ID", "User ID"],
			'csv_file_name': 'download_certificate_report.csv',
			'report_api_name': 'get_download_certificate_report',
			'kbox_field': "kbox",
			'user_field': "email",
			'dashboard_field': "dashboard_id",
		},
		'get_exported_best_practice_report': {
			'csv_header': [
				'KBOX',
				'Dashboard ID',
				'Dashboard Name',
				'User ID',
				'Email',
				'Inst ID',
				'Count',
				"last_accessed_time",
				"Project ID"
			],
			'fields_mapping': {
				"KBOX": "kbox",
				"Dashboard ID": "dashboard_id",
				"Dashboard Name": "dashboard_name",
				"User ID": "user_id",
				"Email": "email",
				"Inst ID": "inst_id",
				"Count": "count",
				"last_accessed_time":"last_accessed_time",
				"Project ID" : "Project_ID"

			},
			'table_name': 'exported_best_practice_report',
			'table_identifier': ["KBOX", "Dashboard ID", "User ID", "Inst ID"],
			'csv_file_name': 'exported_best_practice_report.csv',
			'report_api_name': 'get_exported_best_practice_report',
			'kbox_field': "kbox",
			'user_field': "email",
			'dashboard_field': "dashboard_id",
		},

		'get_users_using_best_practice_hashtag': {
			'csv_header': [
				'KBOX',
				'Dashboard ID',
				'Dashboard Name',
				'User ID',
				'Email',
				'Inst ID',
				'Count',
				"last_accessed_time",
				"Project ID"
			],
			'fields_mapping': {
				"KBOX": "KBOX",
				"Dashboard ID": "dashboard_id",
				"Dashboard Name": "dashboard_name",
				"User ID": "user_id",
				"Email": "email",
				"Inst ID": "inst_id",
				"Count": "count",
				"last_accessed_time":"last_accessed_time",
				"Project ID" : "Project_ID"
			},
			'table_name': 'users_using_best_practice_hashtag',
			'table_identifier': ["KBOX", "Dashboard ID", "User ID", "Inst ID"],
			'csv_file_name': 'users_using_best_practice_hashtag.csv',
			'report_api_name': 'get_users_using_best_practice_hashtag',
			'kbox_field': "kbox",
			'user_field': "email",
			'dashboard_field': "dashboard_id",
		},
		'get_entity_and_user_assignment_report': {
			'csv_header': [
				'KBOX',
				'Dashboard ID',
				'Dashboard Name',
				'Inst ID',
				'No of Questions Having Entity',
				'No of Questions Having Owner',
				'Total Instance Questions',
				"Project ID"
			],
			'fields_mapping': {
				"KBOX": "KBOX",
				"Dashboard ID": "dashboard_id",
				"Dashboard Name": "dashboard_name",
				"Inst ID": "inst_id",
				"No of Questions Having Entity": "no_of_ques_having_entity",
				"No of Questions Having Owner": "no_of_ques_having_owner",
				"Total Instance Questions": "total_inst_ques",
				"Project ID" : "Project_ID"
			},
			'table_name': 'entity_and_user_assignment_report',
			'table_identifier': ["KBOX", "Dashboard ID", "Inst ID"],
			'csv_file_name': 'entity_and_user_assignment_report.csv',
			'report_api_name': 'get_entity_and_user_assignment_report',
			'kbox_field': "KBOX",
			'user_field': "",
			'dashboard_field': "dashboard_id",
		}
		# Add more reports here...
	}

	# Getting the specific report configuration
	report_config = reports_config[report_name]

	# Creating a simplified report configuration
	simplified_report_config = {
		"script_folder": 'Database Files',  # Decide later
		"sub_folder": 'AI Reports',
		"csv_filename": report_config['csv_file_name'],
		"csv_header": report_config['csv_header'],
		"fields_mapping": report_config['fields_mapping'],
		"table_identifier": report_config['table_identifier'],
		"kbox_field": [],
		"user_field": [],
		"dashboard_field": report_config['dashboard_field'],
		'table_name': report_config['table_name'],
		'table_identifier': report_config['table_identifier'],
		'csv_file_name': report_config['csv_file_name'],
		'report_api_name': report_config['report_api_name'],
		'kbox_field': report_config['kbox_field'],
		'user_field': report_config['user_field'],
		'dashboard_field': report_config['dashboard_field']
	}
	return simplified_report_config

def getDirectReportsCsvDetails(report_name):
	report_config = {}
	csv_file_name = ''
	table_name = ''
	dashboard_field = ''
		
	if report_name.lower() == 'ev_ready_for_review':
		
		csv_header = [
				'KBOX',
				'dashboard_id',
				'dashboard_name',
				'inst_id',
				'inst_name',
				'review_status',
				'user_id',
				'email',
				'beta',
				'created_on',
				'modified_on',
				'Project ID'
			]

		fields_mapping = {
			'KBOX':'KBOX',
			'dashboard_id':'dashboard_id',
			'dashboard_name':'dashboard_name',
			'inst_id':'inst_id',
			'inst_name':'inst_name',
			'review_status':'review_status',
			'user_id':'user_id',
			'email':'email',
			'beta':'beta',
			'created_on':'created_on',
			'modified_on':'modified_on',
			'Project ID': "Project_ID",
		}

		csv_file_name = 'Submit For Review Reports.csv'
		table_name='ev_ready_for_review'
		kbox_field = 'KBOX'
		dashboard_field= "dashboard_id"
	
	elif report_name.lower() == 'ev_user_noti_settings_log':
		
		csv_header = [
				'KBOX',
				'user_id',
				'email',
				'notification',
				'created_on',
				'modified_on',
				'status',
			]

		fields_mapping = {
			'KBOX':'KBOX',
			'user_id':'user_id',
			'email':'email',
			'notification':'notification',
			'created_on':'created_on',
			'modified_on':'modified_on',
			'status':'status',
		}

		csv_file_name = 'ev_user_noti_settings_log.csv'
		table_name='ev_user_noti_settings_log'
		kbox_field = 'KBOX'
		dashboard_field= None

	elif report_name.lower() == 'ev_policy_tpl_download_logs':
		csv_header = [
			'KBOX',
			'Policy Template ID',
			'Policy File Name',
            'User ID',
			'User Email',
			'created_on',
			'modified_on',
			'Status'
		]
		fields_mapping = {
            "KBOX": "KBOX",
            "Policy Template ID": "policy_tpl_id",
            "Policy File Name": "policy_file_name",
            "User ID": "user_id",
            "User Email": "email",
            "created_on": "created_on",
			"modified_on": "modified_on",
            "Status": "status"
        }

		csv_file_name = 'ev_policy_tpl_download_logs.csv'
		table_name = "ev_policy_tpl_download_logs"
		kbox_field = "KBOX"
		dashboard_field = None

	elif report_name.lower() == 'ev_audit_log_export':
		csv_header = [
            'KBOX',
			'Dashboard ID',
			'Dashboard Name',
            'inst_id',
			'inst_name',
			'User ID',
            'User Email',
			'created_on',
			'modified_on',
			'Status'
        ]
		fields_mapping = {
            "KBOX": "KBOX",
            "Dashboard ID": "dashboard_id",
            "Dashboard Name": "dashboard_name",
            "inst_id": "inst_id",
            "inst_name": "inst_name",
            "User ID": "user_id",
            "User Email": "email",
            "created_on": "created_on",
			"modified_on": "modified_on",
            "Status": "status"
        }
		
		csv_file_name = 'ev_audit_log_export.csv'
		table_name = "ev_audit_log_export"
		kbox_field = "KBOX"
		dashboard_field = "dashboard_id"

	
	report_config = {
		"script_folder": 'Database Files', ## decide later
		"sub_folder": 'AI Reports',
		"csv_filename": csv_file_name,
		"csv_header": csv_header,
		"fields_mapping": fields_mapping,
		"table_name":table_name,
		"kbox_field":kbox_field,
		"dashboard_field":dashboard_field,
	}
	return report_config


