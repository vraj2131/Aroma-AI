import os
from config import sharepoint_host, kbox_to_exclude, user_to_exclude, ACTIVE_PROJECT_STATUSES
from generic_function import get_sharepoint_configs
from CSVEditor import CSVEditor

class TableProcessor:
    def __init__(self, db_conn, cursor):
        self.db_conn = db_conn
        self.cursor = cursor

    def get_table_detail(self, todo):
        if todo == "ev_custom_sample_table_processor":
            csv_file_name = "ev_custom_sample_table_processor.csv"
            csv_header = [
                'KBOX',
                'dashboard_id',
                'dashboard_name',
                'inst_id',
                'inst_name',
                'total_file_count',
                'user_id',
                'email',
                'last_uploaded'
            ]

            fields_mapping = {
                "KBOX": "KBOX",
                "dashboard_id": "Dashboard ID",
                "dashboard_name": "Dashboard Name",
                "inst_id": "Inst Id",
                "inst_name": "Inst Name",
                "total_file_count": "Total File Count",
                "user_id": "User_Id",
                "email": "Email",
                "last_uploaded": "Last Uploaded"
            }
            table_config = {
                "script_folder": 'Database Files',
                "sub_folder": 'AI Reports',
                "csv_filename": csv_file_name,
                "csv_header": csv_header,
                "fields_mapping": fields_mapping,
                "kbox_field": "KBOX",
                "dashboard_field": "dashboard_id",
                "user_field": "email"
                
            }
            sharepoint_configs = get_sharepoint_configs('BI')

            table_config.update({
                "sharepoint_host": sharepoint_host,
                'sharepoint_site_url': sharepoint_host + "/sites/" + sharepoint_configs['site_name'],
                "doc_base_library": sharepoint_configs['doc_base_library']
            })

            return table_config

    def get_table_data(self, table_name, table_config, kbox_to_exclude=[], user_to_exclude=[]):
        csv_header = table_config["csv_header"]
        fields_mapping = table_config["fields_mapping"]
        kbox_field = table_config["kbox_field"]
        user_field = table_config["user_field"]
        dashboard_field = table_config["dashboard_field"]
        # Build the SELECT query dynamically
        # select_columns = ", ".join(csv_header)
        # query = f"SELECT {select_columns} FROM {table_name}"

        query = f"SELECT rpt.*, pcm.project_id as Project_ID FROM {table_name} rpt LEFT JOIN project_config_mapping pcm ON rpt.{dashboard_field}=pcm.config_id AND pcm.department NOT IN ('Cybersecurity Services','Pro Services') "
        where_clause = []
    
        if kbox_to_exclude and kbox_field:
            kbox_to_exclude_str = ",".join([f"'{val}'" if isinstance(val, str) else str(val) for val in kbox_to_exclude])
            where_clause.append(f"{kbox_field} NOT IN ({kbox_to_exclude_str})")
    
        if user_to_exclude and user_field:
            user_to_exclude_str = ",".join([f"'{val}'" if isinstance(val, str) else str(val) for val in user_to_exclude])
            where_clause.append(f"{user_field} NOT IN ({user_to_exclude_str})")
    
        UPDATED_PROJECT_STATUSES = ACTIVE_PROJECT_STATUSES + ['Completed']
        project_statuses = ",".join([f'"{sts}"' for sts in UPDATED_PROJECT_STATUSES])
        query += f" AND pcm.project_status IN ({project_statuses})"
      
        if where_clause:
            where_clause_str = " AND ".join(where_clause)
            query += f" WHERE {where_clause_str}"
        if "last_uploaded" in fields_mapping:
            query += " order by last_uploaded desc"
        

        print("query", query)
        # Execute the query
        self.cursor.execute(query)
        records = self.cursor.fetchall()

        # Map the data based on fields_mapping
        mapped_records = []
        if "Project_ID" not in csv_header:
            csv_header.append("Project_ID")
        for record in records:
            # Collect values in the order of csv_header
            if isinstance(record, dict):
                mapped_record = [record[column] for column in csv_header if column in record]
            else:
                mapped_record = [record[idx] for idx, column in enumerate(csv_header)]
            mapped_records.append(mapped_record)
        # print(f"mapped_records --> {mapped_records}")

        return mapped_records

    def write_table_data_to_sharepoint(self, table_name, table_data, table_config):
        response = {'error': False, 'msg': 'Data not found'}

        if len(table_data) > 0:
            # Object invocation
            fn_obj = CSVEditor(table_config)

            # Check if file exists
            if fn_obj.csvExist():
                csv_created = fn_obj.deleteOldCSV(fn_obj.s3_file_name)

            csv_created = fn_obj.createCSVWithHeaders()

            s3_file_name = fn_obj.writeDataToCSV(table_data)

            response['error'] = fn_obj.upload_s3_report_to_sharepoint('BI')
            response['msg'] = s3_file_name
        else:
            response['msg'] = "No data found for table"

        return response

    def process_table(self, todo, table_name):
        if todo == "ev_custom_sample_table_processor":
            table_config = self.get_table_detail(todo)
            table_data = self.get_table_data(table_name, table_config)
            resp = self.write_table_data_to_sharepoint(table_name, table_data, table_config)
            return resp
