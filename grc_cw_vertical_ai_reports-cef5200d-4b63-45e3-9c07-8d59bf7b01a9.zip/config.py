# from aws_secrets import Secretes

# sec_obj = Secretes()
# oa_secret_data = sec_obj.get_secret('oa_secret_data') #get_oa_secret()
import os
import boto3
import json
from enum import Enum
from get_secret_function import *

from get_secret_function import (
    get_mysql_secret, 
    get_sharepoint_secret,get_oa_db_secret
)

script_env = os.environ["ENV"]

OA_DB_SECRET = get_oa_db_secret()

# print(OA_DB_SECRET.get('CLUSTER_DB_HOST'))
# print(OA_DB_SECRET.get('CLUSTER_DB_PW'))
# print(OA_DB_SECRET.get('CLUSTER_DB_USER'))
# print(OA_DB_SECRET.get('OA_API_KEY_OAI'))
# exit()
 
# OA_HOST = "https://cs-api.controlcase.com"
# OAI_X_API_KEY = "XQKiKm3TIW7oNtLpkXYTuj4gMsj3xa22eu9kqM76" #OA_DB_SECRET.get('OA_API_KEY_OAI')

# OA_HOST = "https://cs-internal-api.controlcase.com"
# OAI_X_API_KEY = "XQKiKm3TIW7oNtLpkXYTuj4gMsj3xa22eu9kqM76" #OA_DB_SECRET.get('OA_API_KEY_OAI')

OA_HOST = "https://cs-dev2-api.controlcase.com"
# OA_HOST = "https://ogyjp7x0xj.execute-api.us-east-1.amazonaws.com/beta"
OAI_X_API_KEY = "ebMzbVOZyB1T6V0wJv3Dt5g9x8F1qUkN7z5Xb2pp" 

UAT_OA_HOST = "https://cs-uat-internal-api.controlcase.com"
UAT_OAI_X_API_KEY = "AJjOA5fs4e2sHbEijTRLc4DTGYx0F5va2GQ98620"


db_configs = get_mysql_secret()
db_host = db_configs['host']
db_user = db_configs['username']
db_pw = db_configs['password']
db_name = db_configs['database']
print("DB_NAME")
print(db_name)

sharepoint_configs = get_sharepoint_secret()

if script_env.lower() != 'dev':
    sharepoint_configs = json.loads(sharepoint_configs['details'])
sharepoint_host = sharepoint_configs['host']
o365_username = sharepoint_configs['username']
o365_password = sharepoint_configs['password']
sharepoint_host = "https://controlcaseint.sharepoint.com"
o365_username = "cc-api-user@controlcase.com"
o365_password = "SOjhg1DpmVt2LuFymnsH2"

kbox_to_exclude = []
user_to_exclude = []

oneaudit_db_host = "oneaudit-cluster-v2.colz6boynabd.us-east-1.rds.amazonaws.com"
oneaudit_db_user = "rds_infra"
oneaudit_db_pw = "8b4Ry.Y|)fgmYg"
oneaudit_db_name = "evs_regln_master"

ACTIVE_PROJECT_STATUSES = ['New', 'Scheduled', 'In Progress', 'In Progress - AT RISK', 'On Hold', 'Suspended']
azure_secret_name = os.environ["AZURE_APP_CRED_LOC"]

AZURE_CRED = get_secret(azure_secret_name)

AZURE_APP_CLIENT_ID = AZURE_CRED["AZURE_APP_CLIENT_ID"]
AZURE_APP_CLIENT_SECRET = AZURE_CRED["AZURE_APP_CLIENT_SECRET"]
AZURE_APP_TENANT_ID = AZURE_CRED["AZURE_APP_TENANT_ID"]

azure_sharepoint_host = "https://controlcasetest.sharepoint.com"
azure_sharepoint_site_url = azure_sharepoint_host+"/sites/TestAutomation"
