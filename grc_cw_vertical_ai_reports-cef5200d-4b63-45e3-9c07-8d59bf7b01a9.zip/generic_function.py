import time, re, xlsxwriter, json, os, pymysql

from config import *
# import mysql.connector

from datetime import datetime, date, timedelta
# from cwvar import *
from office365.runtime.auth.authentication_context import AuthenticationContext
from office365.sharepoint.client_context import ClientContext
from office365.sharepoint.files.creation_information import FileCreationInformation


fname_for_root_dir = ''

def connect_db(db_host=db_host, db_user=db_user, db_pw=db_pw, db_name=db_name):
	print('--- Checking DB Connection --- ')

	response = {}
	response['success'] = "false"

	try:
		# db_conn = mysql.connector.connect(host=db_host, user=db_user, passwd=db_pw, database=db_name)
		db_conn = pymysql.connect(host=db_host, user=db_user, passwd=db_pw, database=db_name)
		#cursor = db_conn.cursor(dictionary=True)
		response['success'] = "true"
		response['message'] = "DB Connection successful."
		response['data'] = db_conn
	except Exception as e:
		print ("Error: ", e)
		response['message'] = str(e)

	return response

def get_sharepoint_configs(report_type=''):
	sharepoint_configs = {}

	print('Inside function : get_sharepoint_configs')
	response = connect_db()

	env = os.environ["ENV"] if 'ENV' in os.environ else ""
	if env == '':
		env = 'DEV'

	if report_type != '':
		env = report_type+'_'+env

	if response["success"] == "true":
		db_conn = response["data"]
		# cursor = db_conn.cursor(dictionary=True)
		cursor = db_conn.cursor(pymysql.cursors.DictCursor)

		sel_query = "select `site_name`, `doc_base_library` from report_config where env = %s and is_deleted = %s"
		args = (str(env),'0')
		cursor.execute(sel_query,args)
		result = cursor.fetchall()
		if len(result) > 0:
			for row in result:
				sharepoint_configs = row

	return sharepoint_configs

def generate_report_file(response_data,extra_params):

	filename = ""
	report_initials = ""
	header_col_excel_name = {}

	if 'report_for' in extra_params and extra_params['report_for'] != '':
		report_initials = extra_params['report_for']

	if 'header_col_excel_name' in extra_params and len(extra_params['header_col_excel_name']) > 0:
		header_col_excel_name = extra_params['header_col_excel_name']

	global fname_for_root_dir
	timestr = time.strftime("%Y%m%d-%H%M%S")
	filename = report_initials+'_'+timestr+'.xlsx'
	fname_for_root_dir = report_initials+'.xlsx'
	filepath = tmp_path+filename
	workbook = xlsxwriter.Workbook(filepath)
	worksheet = workbook.add_worksheet()

	if len(response_data) > 0:
		'''
		timestr = time.strftime("%Y%m%d-%H%M%S")
		#filename = 'CCCertDateForecast_'+timestr+'.xlsx'
		filename = report_initials+'_'+timestr+'.xlsx'
		filepath = tmp_path+filename
		workbook = xlsxwriter.Workbook(filepath)
		worksheet = workbook.add_worksheet()
		'''

		row = 0
		for key,row_data in response_data.items():
			header_col = 0
			col = 0

			if row == 0:
				##-- To Add the Headers of CSV --##
				cell_format = workbook.add_format({'bold': True, 'font_color': '#003366'})
				for key1, val2 in response_data[key].items():
					header_col_name = key1
					if key1 in header_col_excel_name:
						header_col_name = header_col_excel_name[key1]
					worksheet.write(0, header_col, header_col_name, cell_format)
					header_col += 1
				##-- To Add the Headers of CSV --##

			##-- To Add the Data of CSV --##
			row += 1
			for key1, val2 in response_data[key].items():
				val2 = str(val2)
				#if (val2 != '' and val2 != None and val2.startswith('=', 0) == True):
				if (val2 != '' and val2 != None and re.match('[=\-"@+]', val2)):
					val2 = " "+val2

				if re.match('\d{2}/\d{2}/\d{4}', val2):
					date_time = datetime.strptime(val2, '%d/%m/%Y')
					date_format = workbook.add_format({'num_format': 'dd/mm/yyyy'})
					worksheet.write(row, col, date_time, date_format)
				else:
					worksheet.write(row, col, val2)
				col += 1
		workbook.close()
	else:
		worksheet.write(0, 0, 'No Results')
		workbook.close()
	return filename

def upload_file_to_sharepoint(filename):

	response = {}
	response['success'] = 'false'

	username = o365_username
	password = o365_password
	sharepoint_base_url = sharepoint_host

	## Get sharepoint configs ##
	sharepoint_configs = get_sharepoint_configs()

	#username = sharepoint_configs['username']
	#password = sharepoint_configs['password']
	#sharepoint_base_url = sharepoint_configs['sharepoint_base_url']
	site_name = sharepoint_configs['site_name']
	doc_base_library = sharepoint_configs['doc_base_library']
	sharepoint_site_url = sharepoint_base_url+"/sites/"+site_name
	## Get sharepoint configs ##

	#username = o365_username
	#password = o365_password

	temp_file_path = tmp_path+filename

	ctx_auth = AuthenticationContext(url=sharepoint_base_url)
	if ctx_auth.acquire_token_for_user(username=username,password=password):
		ctx = ClientContext(sharepoint_site_url, ctx_auth)

		local_path = temp_file_path
		with open(local_path, 'rb') as content_file:
			file_content = content_file.read()

		global fname_for_root_dir
		info = FileCreationInformation()
		info.content = file_content
		info.overwrite = True
		#info.url = filename
		info.url = fname_for_root_dir


		info_root = FileCreationInformation()
		info_root.content = file_content
		info_root.overwrite = True
		info_root.url = fname_for_root_dir

		folder_name = create_folder_at_sharepoint()
		power_bi_folder = create_folder_at_sharepoint('power_bi')
		try:
			#result_file = ctx.web.get_folder_by_server_relative_url(doc_library).files.add(info)
			result_file = ctx.web.get_folder_by_server_relative_url(doc_base_library+'/'+folder_name).files.add(info)
			result_file_root = ctx.web.get_folder_by_server_relative_url(doc_base_library+'/'+power_bi_folder).files.add(info_root)
			ctx.execute_query()
			response['success'] = "true"
			response['message'] = filename+" : Uploaded successfully."
			print('File {0} has been uploaded successfully'.format(result_file.properties['ServerRelativeUrl']))
			print('File {0} has been uploaded successfully (root dir)'.format(result_file_root.properties['ServerRelativeUrl']))
		except:
			print("Error occurred while uploading the file : "+filename+" on sharepoint. Sharepoint site url : "+sharepoint_site_url)
			response['message'] = filename+" : Error occurred while uploading the file."
	else:
		print(ctx_auth.get_last_error())
		response['message'] = "Failed to get authentication token with given username/password."
		print("Failed to get authentication token with given username/password.")
	return response

def create_folder_at_sharepoint(para=''):
	print("Inside Function : create_folder_at_sharepoint")

	date = time.strftime("%Y-%m-%d")
	folder_name = date
	if(para == 'power_bi'):
		folder_name = 'Power BI'

	username = o365_username
	password = o365_password
	sharepoint_base_url = sharepoint_host

	## Get sharepoint configs ##
	sharepoint_configs = get_sharepoint_configs()

	#username = sharepoint_configs['username']
	#password = sharepoint_configs['password']
	#sharepoint_base_url = sharepoint_configs['sharepoint_base_url']
	site_name = sharepoint_configs['site_name']
	doc_base_library = sharepoint_configs['doc_base_library']
	sharepoint_site_url = sharepoint_base_url+"/sites/"+site_name
	## Get sharepoint configs ##

	ctx_auth = AuthenticationContext(url=sharepoint_base_url)
	if ctx_auth.acquire_token_for_user(username=username,password=password):
		ctx = ClientContext(sharepoint_site_url, ctx_auth)

		try:
			result_file = ctx.web.get_folder_by_server_relative_url(doc_base_library).folders.add(folder_name)
			ctx.execute_query()
			print('Folder {0} has been created successfully'.format(result_file.properties['ServerRelativeUrl']))
		except:
			print("Error occurred while creating the folder")

	return folder_name

def get_headers(cursor,cw_fields):
	header_col_excel_name = {}
	excel_col_mapping = {}
	cw_fields_list = []

	cursor.execute("select `cw_field_name`, `excel_col_name` from report_excel_col_names_mapping")
	result = cursor.fetchall()
	if len(result) > 0:
		for row in result:
			excel_col_mapping[row['cw_field_name']] = row['excel_col_name']

	cw_fields_list = list(cw_fields.split(","))
	for key in cw_fields_list:
		header_col_excel_name[key] = excel_col_mapping[key]

	return header_col_excel_name

def get_headers_old(report_name):
	header_col_excel_name = {}

	if report_name == 'CCCertDateForecast':
		header_col_excel_name = {
			'company_name': 'Company Name',
			'company_identifier': 'KBOX',
			'site': 'Site',
			'assessor': 'Assessor',
			'csegment': 'Segmentation',
			'certdate': 'Cert Date',
			'targetcert': 'Target Cert Date',
			'warrantyExpirationDate': 'Expiry Date',
			'contact_name': 'Contact Name',
			'email' : 'Email',
			'asv': 'ASV',
			'iva': 'IVA',
			'managedcdd': 'Managed CDD',
			'enpt': 'ENPT',
			'inpt': 'INPT',
			'cddsw-f': 'CDDSW-F',
			'cddsw-s': 'CDDSW-S',
			'extids': 'Ext IDS',
			'intids': 'Int IDS',
			'lm': 'LM',
			'awaretrain': 'Aware Train',
			'owasptrain': 'OWASPTrain',
			'useraccess': 'User Access',
			'proservices': 'Pro Services',
			'productgrou': 'Product Grou',
		}

	if report_name == 'CCAmericasCertDSR':
		header_col_excel_name = {
			'company_name' : 'Company Name',
			'company_identifier' : 'KBOX',
			#'cc_dept' : 'CC Dept',
			#'cc_team' : 'CC Team',
			'cc_dept' : 'Vertical',
			'cc_team' : 'Industry',
			'config_name' : 'Configuration Name',
			'territory' : 'Territory',
			'product_group' : 'Product Grou',
			'segmentation' : 'Segmentation',
			'assessor' : 'Assessor',
			'ticket_no' : 'Ticket#',
			'status' : 'Status',
			'resolution' : 'Resolution',
			'resources' : 'Resources',
			'start_date' : 'Start Date',
			'date_required' : 'Date Required',
			'target_cert_date' : 'Target Cert Date',
			'target_kc' : 'Target KC',
			'actual_kc' : 'Actual KC',
			'target_su' : 'Target SU',
			'actual_su' : 'Actual SU',
			'target_sp' : 'Target SP',
			'actual_sp' : 'Actual SP',
			'target_50u' : 'Target50U',
			'actual_50u' : 'Actual50U',
			'target_50p' : 'Target50P',
			'actual_50p' : 'Actual50P',
			'target_100u' : 'Target100U',
			'actual_100u' : 'Actual100U',
			'target_100p' : 'Target100P',
			'actual_100p' : 'Actual100P',
			'target_rr' : 'Target RR',
			'actual_rr' : 'Actual RR',
			'pcidss' : 'PCI DSS',
			'hipaa' : 'HIPAA',
			'iso' : 'ISO',
			'soc' : 'SOC',
			'other_cert' : 'Other Cert',
			'ei3pa' : 'EI3PA',
			'pa_dss' : 'PA DSS',
			'warrantyExpirationDate' : 'Warranty Expiration',
			'new_cert' : 'New Cert',
			'pm' : 'PM',
			'internal_notes' : 'Internal Notes',
		}

	if report_name == 'CCHealthcareDSR' or report_name == 'CCFederalDSR' or report_name == 'CCHITRUSTDSR' or report_name == 'CCAPACCaaSDSR':
		header_col_excel_name = {
			'company_name' : 'Company Name',
			'company_identifier' : 'KBOX',
			'config_name' : 'Configuration Name',
			'territory' : 'Territory',
			'product_group' : 'Product Grou',
			'cc_dept' : 'Vertical',
			#'cc_team' : 'Industry',
			'segmentation' : 'Segmentation',
			'assessor' : 'Assessor',
			'ticket_no' : 'Ticket#',
			'status' : 'Status',
			'resolution' : 'Resolution',
			'resources' : 'Resources',
			'start_date' : 'Start Date',
			'date_required' : 'Date Required',
			'target_cert_date' : 'Target Cert Date',
			'target_kc' : 'Target KC',
			'actual_kc' : 'Actual KC',
			'target_su' : 'Target SU',
			'actual_su' : 'Actual SU',
			'target_sp' : 'Target SP',
			'actual_sp' : 'Actual SP',
			'target_50u' : 'Target50U',
			'actual_50u' : 'Actual50U',
			'target_50p' : 'Target50P',
			'actual_50p' : 'Actual50P',
			'target_100u' : 'Target100U',
			'actual_100u' : 'Actual100U',
			'target_100p' : 'Target100P',
			'actual_100p' : 'Actual100P',
			'target_rr' : 'Target RR',
			'actual_rr' : 'Actual RR',
			'pcidss' : 'PCI DSS',
			'hipaa' : 'HIPAA',
			'iso' : 'ISO',
			'soc' : 'SOC',
			'other_cert' : 'Other Cert',
			'ei3pa' : 'EI3PA',
			'pa_dss' : 'PA DSS',
			'warrantyExpirationDate' : 'Warranty Expiration',
			'new_cert' : 'New Cert',
		}

	return header_col_excel_name

def generate_timesheet_report_file(response_data,extra_params):

	filename = ""
	report_initials = ""
	header_col_excel_name = {}

	if 'report_for' in extra_params and extra_params['report_for'] != '':
		report_initials = extra_params['report_for']

	if 'header_col_excel_name' in extra_params and len(extra_params['header_col_excel_name']) > 0:
		header_col_excel_name = extra_params['header_col_excel_name']

	global fname_for_root_dir
	timestr = time.strftime("%Y%m%d-%H%M%S")
	filename = report_initials+'_'+timestr+'.xlsx'
	fname_for_root_dir = report_initials+'.xlsx'
	filepath = tmp_path+filename

	workbook = xlsxwriter.Workbook(filepath)
	worksheet = workbook.add_worksheet()

	##-- To Add the Headers of CSV --##
	cell_format = workbook.add_format({'bold': True, 'font_color': '#003366'})
	row = 0

	header_col = 0

	for header_col_name, val2 in header_col_excel_name.items():
		worksheet.write(row, header_col, header_col_name, cell_format)
		header_col += 1
	##-- To Add the Headers of CSV --##

	if len(response_data) > 0:

		row = 1
		for row_data in response_data:

			col = 0
			for header_col_name, db_reff in header_col_excel_name.items():
				val2 = str(row_data[header_col_name])

				if (val2 != '' and val2 != None and re.match('[=\-"@+]', val2)):
					val2 = " "+val2

				if len(val2)==10 and  re.match('\d{4}-\d{2}-\d{2}', val2):
					date_time = datetime.strptime(val2, '%Y-%m-%d')
					date_format = workbook.add_format({'num_format': 'dd/mm/yyyy'})
					worksheet.write(row, col, date_time, date_format)
				else:
					worksheet.write(row, col, val2)
				col += 1

			row += 1

		workbook.close()
	else:
		worksheet.write(1, 0, 'No Results')
		workbook.close()

	return filename


def process_timesheet_report(rep_data,extra_params):
	response = {}

	print('--- Proceed to generate xlsx file ---')
	filename = generate_timesheet_report_file(rep_data,extra_params)

	if filename != '':
		temp_file_path = tmp_path+filename

		##Upload file to sharepoint
		upload_res = upload_file_to_sharepoint(filename)
		response[extra_params['report_for']] = {}
		response[extra_params['report_for']]['success'] = upload_res['success']
		response[extra_params['report_for']]['message'] = upload_res['message']

		## Delete file from tmp directory if exist ##
		if os.path.exists(temp_file_path):
			os.remove(temp_file_path)
			print("Removed the file %s" % temp_file_path)
		else:
			print("File %s does not exist." % temp_file_path)
	else:
		response['message'] = "File not generated as there is no data present."
		print("File not generated as there is no data present.")

	return response

def process_report(rep_data,extra_params):
	response = {}
	print('--- Proceed to generate xlsx file ---')
	filename = generate_report_file(rep_data,extra_params)
	if filename != '':
		temp_file_path = tmp_path+filename

		##Upload File in S3 just to check ##
		#s3 = boto3.resource('s3')
		#s3.meta.client.upload_file(temp_file_path, BUCKET_NAME, bucket_upload_folder_path+filename)

		##Upload file to sharepoint
		upload_res = upload_file_to_sharepoint(filename)
		response[extra_params['report_for']] = {}
		response[extra_params['report_for']]['success'] = upload_res['success']
		response[extra_params['report_for']]['message'] = upload_res['message']

		## Delete file from tmp directory if exist ##
		if os.path.exists(temp_file_path):
			os.remove(temp_file_path)
			print("Removed the file %s" % temp_file_path)
		else:
			print("File %s does not exist." % temp_file_path)
	else:
		response['message'] = "File not generated as there is no data present."
		print("File not generated as there is no data present.")

	return response

def check_sharepoint_authentication():
	print('--- Checking Sharepoint Authentication --- ')

	response = {}
	response['success'] = "false"
	response['message'] = "Authentication failed."

	username = o365_username
	password = o365_password
	sharepoint_base_url = sharepoint_host
	## Get sharepoint configs ##
	sharepoint_configs = get_sharepoint_configs()

	#username = sharepoint_configs['username']
	#password = sharepoint_configs['password']
	#sharepoint_base_url = sharepoint_configs['sharepoint_base_url']
	site_name = sharepoint_configs['site_name']
	doc_base_library = sharepoint_configs['doc_base_library']
	sharepoint_site_url = sharepoint_base_url+"/sites/"+site_name
	## Get sharepoint configs ##


	ctx_auth = AuthenticationContext(url=sharepoint_base_url)
	try:
		if ctx_auth.acquire_token_for_user(username=username,password=password):
			response['success'] = "true"
			response['message'] = "Authentication successful."
		else:
			response['message'] = "Authentication failed."
	except:
		print(ctx_auth.get_last_error())
		response['message'] = ctx_auth.get_last_error()

	return response

def get_dash_config_conditions_old(cursor,report_id):
	dash_config_conditions = {}
	cursor.execute("select `req_fields`, `conditions`, `custom_field_conditions`, `custom_field_conditions_extra` from report_get_configuration_conditions where report_id = %s",(report_id,))
	result = cursor.fetchall()
	if len(result) > 0:
		for row in result:
			dash_config_conditions = row

	return dash_config_conditions


def get_reports_criteria(cursor,report_chunk = 0):
	report_detail = {}

	## -- Fetch reports -- ##
	reports = {}
	sql_cond = ""
	if report_chunk != 0:
		sql_cond = " and report_chunk = "+str(report_chunk)

	get_reports_sql = "select * from report_names where is_deleted = 0"+sql_cond
	#print(get_reports_sql)
	#exit()
	cursor.execute(get_reports_sql)
	reports_result = cursor.fetchall()
	if len(reports_result) > 0:
		for row in reports_result:
			reports[row['id']] = row
			#reports[row['id']] = row['report_name']
	#print(reports)
	#exit()
	if len(reports) > 0:
		for key, value_dict in reports.items():
			value = value_dict['report_name']

			## Get dashboard config conditions from db##
			report_detail[value] = {}
			report_detail[value]['report_for'] = value
			report_detail[value]['report_type'] = value_dict['report_type']
			report_detail[value]['get_config_cond'] = get_dash_config_conditions(cursor,key)
			report_detail[value]['get_ticket_cond'] = get_ticket_conditions(cursor,key)
			report_detail[value]['get_company_cond'] = get_company_conditions(cursor,key)
			report_detail[value]['get_teams_cond'] = get_teams_conditions(cursor,key)
			report_detail[value]['get_report_headers'] = get_report_headers(cursor,key)
			report_detail[value]['get_contact_cond'] = get_contact_conditions(cursor,key)
			report_detail[value]['report_chunk'] = value_dict['report_chunk']
			report_detail[value]['is_report_data_exist'] = value_dict['is_report_data_exist']

	return report_detail
	## -- Fetch reports -- ##

def get_dash_config_conditions(cursor,report_id):
	dash_config_conditions = {}
	cursor.execute("select `req_fields`, `conditions`, `custom_field_conditions`, `custom_field_conditions_extra`, `order_by` from report_get_configuration_conditions where report_id = %s",(report_id,))
	result = cursor.fetchall()
	if len(result) > 0:
		for row in result:
			dash_config_conditions = row

	return dash_config_conditions

def get_ticket_conditions(cursor,report_id):
	ticket_conditions = {}
	cursor.execute("select `req_fields`, `conditions`, `custom_field_conditions`, `custom_field_conditions_extra`, `custom_field_date_conditions_extra`, `order_by` from report_get_ticket_conditions where report_id = %s",(report_id,))
	result = cursor.fetchall()
	if len(result) > 0:
		for row in result:
			ticket_conditions = row

	return ticket_conditions

def get_contact_conditions(cursor,report_id):
	contact_conditions = {}
	cursor.execute("select `req_fields`, `conditions`, `custom_field_conditions`, `custom_field_conditions_extra`, `order_by` from report_get_contacts_conditions where report_id = %s",(report_id,))
	result = cursor.fetchall()
	if len(result) > 0:
		for row in result:
			contact_conditions = row

	return contact_conditions

def get_company_conditions(cursor,report_id):
	company_conditions = {}
	cursor.execute("select `req_fields`, `conditions`, `custom_field_conditions`, `custom_field_conditions_extra`, `order_by` from report_get_company_conditions where report_id = %s",(report_id,))
	result = cursor.fetchall()
	if len(result) > 0:
		for row in result:
			company_conditions = row

	return company_conditions

def get_teams_conditions(cursor,report_id):
	teams_conditions = {}
	cursor.execute("select `req_fields`, `conditions`, `custom_field_conditions`, `custom_field_conditions_extra`, `order_by` from report_get_teams_conditions where report_id = %s",(report_id,))
	result = cursor.fetchall()
	if len(result) > 0:
		for row in result:
			teams_conditions = row

	return teams_conditions

def get_report_headers(cursor,report_id):
	headers = {}
	cursor.execute("select `headers` from report_headers where report_id = %s",(report_id,))
	result = cursor.fetchall()
	if len(result) > 0:
		for row in result:
			headers = row

	return headers

def get_report_tik_id(cursor,report_id):
	tik_id = ''
	sel_query = "SELECT MIN(ticket_no) AS ticket_no FROM report_data WHERE report_id = %s"
	args = (str(report_id),)
	cursor.execute(sel_query,args)
	result = cursor.fetchall()

	if len(result) > 0:
		for row in result:
			tik_id = row['ticket_no']

	return tik_id

def get_report_config_id(cursor,report_id):
	config_id = ''
	sel_sql = "SELECT MIN(config_id) AS config_id from report_data WHERE report_id = %s"
	args = (str(report_id),)
	cursor.execute(sel_sql,args)
	result = cursor.fetchall()

	if len(result) > 0:
		for row in result:
			config_id = row['config_id']

	return config_id

def get_report_data(cur,report_cond):
	final_formated_report_data = {}
	sel_sql = "SELECT * FROM report_data WHERE report_id = %s"
	args = (str(report_cond['report_chunk']),)
	cur.execute(sel_sql,args)
	res = cur.fetchall()

	if len(res) > 0:

		cw_fields_list = []
		if 'get_report_headers' in report_cond and 'headers' in report_cond['get_report_headers']:
			cw_fields_list = list(report_cond['get_report_headers']['headers'].split(","))
			#print(cw_fields_list)
		key = 0
		for row in res:
			data_to_add = {}

			for cw_field in cw_fields_list:
				if cw_field == 'cddsw-s':
					row[cw_field] = row['cddsw_s']

				if cw_field == 'cddsw-f':
					row[cw_field] = row['cddsw_f']

				if cw_field == 'cddsw-e':
					row[cw_field] = row['cddsw_e']

				if cw_field not in row:
					data_to_add[cw_field] = ''
				else:
					data_to_add[cw_field] = row[cw_field]


			if len(final_formated_report_data) == 0:
				final_formated_report_data = {key : data_to_add}
			else:
				final_formated_report_data.update({key : data_to_add})

			key = key + 1

	return final_formated_report_data

def delete_report_data(cur,db_conn,report_id):
	if report_id > 0:
		del_sql = "DELETE FROM report_data WHERE report_id = %s"
		args=(str(report_id),)
		cur.execute(del_sql,args)
		db_conn.commit()

		deleted_row_count = cur.rowcount
		if deleted_row_count > 0:
			print('Records deleted for report id:'+str(report_id))
		else:
			print('Problem while  deleting records for report id:'+str(report_id))

def update_report_data_status(cur,db_conn,report_id,flag):
	if flag == '1':
		upd_sql = "UPDATE report_names SET is_report_data_exist = %s WHERE report_chunk = %s"
		args = ('1',str(report_id),)
		cur.execute(upd_sql,args)
	elif flag == '0':
		upd_sql = "UPDATE report_names SET is_report_data_exist = %s"
		args = ('0',)
		cur.execute(upd_sql,args)

	db_conn.commit()
	upd_row_count = cur.rowcount
	if upd_row_count > 0:
		print('Records updated for [is_report_data_exist] report_chunk:'+str(report_id))
	else:
		print('Problem while updatinng records for [is_report_data_exist] report_chunk:'+str(report_id))


def multi_rec_insert(cur,db_conn,ins_query,ins_data,size):
	start = 0
	end = size
	temp_list = []

	for ins_val in ins_data:
		temp_list = ins_data[start:end]
		if not temp_list:
			break
		else:
			cur.executemany(ins_query, temp_list)
			db_conn.commit()
			temp_list.clear()

		start = start + size
		end = end + size


def getConfigAndSiteDataFromDb(cursor,db_conn, condition=[]):

	dashboard_data = {}
	site_data = {}
	s1= ' and '
	sql_part= ''
	if len(condition)>0:
		sql_part = ' where ' + s1.join(condition)

	get_sql = "SELECT * from cw_configuration" + sql_part + " ORDER BY config_id desc"
	cursor.execute(get_sql)
	reports_result = cursor.fetchall()
	if len(reports_result) > 0:
		for conf_data in reports_result:
			if conf_data['config_id'] not in dashboard_data:
				dashboard_data[conf_data['config_id']]=conf_data
				dashboard_data[conf_data['config_id']]['test_date'] = str(conf_data['test_date'])
				dashboard_data[conf_data['config_id']]['target_cert_date'] = str(conf_data['target_cert_date'])
				dashboard_data[conf_data['config_id']]['cert_date'] = str(conf_data['cert_date'])
				dashboard_data[conf_data['config_id']]['status'] = str(conf_data['status'])
			if conf_data['site_id'] not in site_data:
				site_data[conf_data['site_id']] = conf_data['config_id']

	return dashboard_data, site_data


def getCompanyDataFomDB(cursor,db_conn):

	formated_comp_data = {}

	cursor.execute("SELECT * from cw_companies")
	reports_result = cursor.fetchall()
	if len(reports_result) > 0:
		for comp_data in reports_result:
			if comp_data['company_id'] not in formated_comp_data:
				formated_comp_data[comp_data['company_id']] = {
					'company_id' : comp_data['company_id'],
					'name' : comp_data['name'],
					'identifier' : comp_data['identifier'],
					'status' : comp_data['status'],
					'dateAcquired' : comp_data['dateacquired'],
					'cc_team' : comp_data['cc_team'] ,
					'cc_dept' : comp_data['cc_dept'],
					'territory': comp_data['territory'],
					'cmp_product_group': comp_data['cmp_product_group'] ,
					'cmp_segmentation': comp_data['cmp_segmentation']
				}

	return formated_comp_data


def getTicketConfigMapping(cursor,db_conn):

	ticket_config_mapping ={}
	cursor.execute("SELECT ticket_id, dashboard_id from cw_tickets_config_reff where cron_status = 2 and dashboard_id != 0")
	result_data = cursor.fetchall()
	if len(result_data) > 0:
		for each_row in result_data:
			if each_row['ticket_id'] not in ticket_config_mapping:
				ticket_config_mapping.update({each_row['ticket_id']:each_row['dashboard_id']})

	return ticket_config_mapping



def getConfigAndProjectsFromDb(cursor,db_conn, condition=[]):

	s1= ' and '
	sql_part= ''
	if len(condition)>0:
		sql_part = ' where ' + s1.join(condition)

	format_strings = ','.join(['%s'] * len(PROJECT_BOARD_ACTIVE_STATUS))

	cursor.execute("SELECT c.config_id, c.dash_config_name ,c.`status` AS dashboard_status, c.additional_data, c.cert_date,c.target_cert_date , c.product_group, p.project_id,p.site_id,p.site_name, p.`status` AS project_status, p.department, p.project_data \
	FROM cw_configuration c JOIN cw_project_data p ON p.site_id = c.site_id AND p.status in (%s) "% format_strings,tuple(PROJECT_BOARD_ACTIVE_STATUS))
	reports_result = cursor.fetchall()

	cw_project_data = {}
	cyber_Security = []
	other_type = []
	if len(reports_result) > 0:

		for conf_data in reports_result:

			project_id = conf_data['project_id']
			product_group = conf_data['product_group']
			department = conf_data['department']

			if product_group != None and product_group.lower() == 'projects' and department != None and department.lower() == 'cybersecurity services':
				cyber_Security.append(project_id)
			else:
				other_type.append(project_id)

			additional_prj_data = {}
			additional_prj_data_str = conf_data['project_data']

			if additional_prj_data_str is not None and len(additional_prj_data_str)>0:
				additional_prj_data = json.loads(additional_prj_data_str)

			pname = additional_prj_data['project_name']
			ptype = additional_prj_data['project_type']
			pstatus = additional_prj_data['status']

			additional_dash_data = {}
			additional_dash_data_str = conf_data['additional_data']
			if additional_dash_data_str is not None and len(additional_dash_data_str)>0:
				additional_dash_data = json.loads(additional_dash_data_str)

			#get cer details
			cw_certs = []
			if len(additional_dash_data)>0:
				cw_certs = getCertDetailsForConfig(additional_dash_data)

			if project_id not in cw_project_data:
				cw_project_data.update({project_id:{
					'dashboard_id':conf_data['config_id'],
					'dashboard':conf_data['dash_config_name'],
					'dashboard_status':conf_data['dashboard_status'],
					'cert_date':conf_data['cert_date'],
					'target_cert_date':conf_data['target_cert_date'],
					'site_id':conf_data['site_id'],
					'site_name':conf_data['site_name'],
					'project_name': pname,
					'project_type': ptype,
					'project_status': pstatus,
					'dashboard_certs': cw_certs,
					'dashboard_cert_found': True if len(cw_certs)>0 else False,
				}})

	return cw_project_data, cyber_Security ,other_type



def getCertDetailsForConfig(config_data):

	certs =[]

	for cw_field in CERT_FIELDS:
		if cw_field in config_data and len(config_data[cw_field])>0 and config_data[cw_field].lower() != "none":
			certs.append(config_data[cw_field])

	return certs


def getTestDateFrmConfigData(status_conf_data):
	test_date = ''
	for config_id,conf_data in status_conf_data.items():
		if 'test_date' in conf_data and conf_data['test_date'] != '':
			test_date = datetime.strptime(conf_data['test_date'],'%Y-%m-%dT%H:%M:%SZ')

	return test_date

def get_formated_datetime_mysql(date_str,return_type=str):
	
	formated_date_str = 'None'
	if type(date_str)==str and len(date_str)>0:
		if 't' in date_str.lower():
			formated_date = datetime.strptime(date_str, '%Y-%m-%dT%H:%M:%SZ')
			formated_date_str = formated_date.strftime('%Y-%m-%d')
		
	return formated_date_str
	
def get_insert_query(table_name, records, mapping_field=None, has_replace=False):
	row_fields = None
	all_values = []
	rows_fields = []
	for row in records:
		print(row)
		print(mapping_field)
		if row_fields is None:
			if mapping_field:
				rows_fields = [row_field for row_field in row.keys() if row_field in mapping_field.keys()]
			else:
				rows_fields = [row_field for row_field in row.keys()]

		values =','.join([f"{json.dumps(row[data])}" if isinstance(row[data], str) else (f"{row[data]}" if row[data] is not None else "''") for data in rows_fields])
		all_values.append(f"({values})")
	
	query_values = ",".join(all_values)
	if mapping_field:
		columns = ','.join([mapping_field[table_field] for table_field in rows_fields if table_field in mapping_field])
	else:
		if rows_fields:
			columns = ",".join(rows_fields)
		
	query = f"""{'INSERT' if not has_replace else 'REPLACE'} INTO {table_name}({columns})
	VALUES{query_values}"""
	print("#####",query)
	return query
	
def get_delete_query(table_name, records, mapping_field, identifiers):
	row_fields = None
	where_clause_or = []
	
	for row in records:
		where_clause =' AND '.join([f"{mapping_field[key]}={row[key]}" if isinstance(row[key], int) else f"{mapping_field[key]}={json.dumps(row[key])}" for key in identifiers])
		where_clause_or.append(f"({where_clause})")
	
	whereclause_str = " OR ".join(where_clause_or)

	query = f"""DELETE FROM {table_name} WHERE {whereclause_str}"""
	
	return query

def get_select_query(table_name, records, mapping_field, identifiers):
	row_fields = None
	where_clause_or = []
	cols = ",".join(list(mapping_field.values()))

	for row in records:
		where_clause =' AND '.join([f"{mapping_field[key]}={row[key]}" if isinstance(row[key], int) else f"{mapping_field[key]}={json.dumps(row[key])}" for key in identifiers])
		where_clause_or.append(f"({where_clause})")
	
	whereclause_str = " OR ".join(where_clause_or)

	query = f"""SELECT {cols} FROM {table_name} WHERE {whereclause_str}"""
	
	return query

def get_update_query(table_name, row, mapping_field, identifiers):

	if "Beta" in mapping_field and "Version" in row:
		row["Beta"] = row["Version"] if row["Version"] else "No"

	rows_fields = [row_field for row_field in row.keys()]

	new_vals_list = [
		f"{mapping_field[data]}={json.dumps(row[data])}" if isinstance(row[data], str) else (
			f"{mapping_field[data]}={row[data]}" if row[data] is not None else f"{mapping_field[data]}=''"
		)
		for data in rows_fields if data in mapping_field and data not in ["Version", "Beta"]
	]

	# Add the Beta field separately to avoid duplication
	if "Beta" in row:
		new_vals_list.append(f"beta={json.dumps(row['Beta'])}")

	# Create the SET clause string
	new_vals = ','.join(new_vals_list)

	where_clause =' AND '.join([f"{mapping_field[key]}={row[key]}" if isinstance(row[key], int) else f"{mapping_field[key]}={json.dumps(row[key])}" for key in identifiers])

	query = f"""UPDATE {table_name} SET {new_vals} WHERE {where_clause}"""

	return query

# Function to calculate x days before today in m/d/y format
def calculate_x_days_before_today(x):
    today = datetime.now()
    start_date = (today - timedelta(days=x)).strftime("%d/%m/%Y")
    return start_date
