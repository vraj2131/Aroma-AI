#!/bin/bash

# Fail if any command fails
set -e

# Input: Combined layer name
if [ -z "$1" ]; then
  echo "❌ Please provide a name for the combined layer."
  echo "Usage: ./combine_lambda_layers.sh my_combined_layer"
  exit 1
fi

LAYER_NAME="$1"
TMP_DIR="./tmp_combined_layer"
FINAL_ZIP="${LAYER_NAME}.zip"

# Clean temporary directory
rm -rf "$TMP_DIR"
mkdir -p "$TMP_DIR/python"

echo "🔄 Combining Lambda layers..."

# Loop through all ZIP files
for zip in *.zip; do
  echo "📦 Extracting $zip..."
  unzip -q "$zip" -d "tmp_zip"
  if [ -d "tmp_zip/python" ]; then
    cp -rn tmp_zip/python/* "$TMP_DIR/python/" 2>/dev/null || true
  else
    # Some layers might not follow the python/ subdir structure
    cp -rn tmp_zip/* "$TMP_DIR/python/" 2>/dev/null || true
  fi
  rm -rf tmp_zip
done


REBUILT_NAME="$1"
TMP_LAYER_DIR="tmp_combined_layer"
ORIG_PYTHON_DIR="$TMP_LAYER_DIR/python"
NEW_LAYER_DIR="rebuilt_layer_${REBUILT_NAME}_py312"
NEW_PYTHON_DIR="$NEW_LAYER_DIR/python"
NEW_LAYER_ZIP="python312_${REBUILT_NAME}.zip"
REQUIREMENTS_FILE="tmp_requirements.txt"

if [ ! -d "$ORIG_PYTHON_DIR" ]; then
  echo "❌ Directory $ORIG_PYTHON_DIR not found. Run the combine script first."
  exit 1
fi

echo "✅ Done. Combined layer created: $TMP_DIR"
