#!/bin/bash

set -e

if [ -z "$1" ]; then
  echo "❌ Provide a name for the rebuilt Python 3.12 layer"
  echo "Usage: ./rebuild_from_tmp_combined_layer.sh mylayer"
  exit 1
fi

REBUILT_NAME="$1"
TMP_LAYER_DIR="tmp_combined_layer"
ORIG_PYTHON_DIR="$TMP_LAYER_DIR/python"
NEW_LAYER_DIR="rebuilt_layer_${REBUILT_NAME}_py312"
NEW_PYTHON_DIR="$NEW_LAYER_DIR/python"
NEW_LAYER_ZIP="python312_${REBUILT_NAME}.zip"
REQUIREMENTS_FILE="tmp_requirements.txt"

if [ ! -d "$ORIG_PYTHON_DIR" ]; then
  echo "❌ Directory $ORIG_PYTHON_DIR not found. Run the combine script first."
  exit 1
fi


# # Clean previous output
# rm -rf "$NEW_LAYER_DIR"
# mkdir -p "$NEW_PYTHON_DIR"

# echo "📦 Extracting valid package names from $ORIG_PYTHON_DIR..."

# find "$ORIG_PYTHON_DIR" -maxdepth 1 -mindepth 1 \
#   \( -type d -o -name "*.py" \) \
#   | grep -Ev '(\.dist-info$|\.egg-info$|__pycache__)' \
#   | sed -e "s|$ORIG_PYTHON_DIR/||" -e 's|/||g' -e 's|\.py$||' \
#   | sort -u > "$REQUIREMENTS_FILE"

# echo "📝 Packages to reinstall using Python 3.12:"
# cat "$REQUIREMENTS_FILE"

echo "🔁 Installing packages freshly..."
while read -r pkg; do
  echo "- Installing: $pkg"
  python3.13 -m pip install "$pkg" -t "$NEW_PYTHON_DIR" || echo "⚠️ Failed to install $pkg"
done < "$REQUIREMENTS_FILE"

echo "🧼 Cleaning up __pycache__ and .pyc files..."
find "$NEW_LAYER_DIR" -name '__pycache__' -type d -exec rm -r {} +
find "$NEW_LAYER_DIR" -name '*.pyc' -delete


echo "✅ Done! Clean Python 3.12 Lambda layer ready: $NEW_LAYER_ZIP"


# bin
# Crypto
# cwRest
# docx
# easy_install
# examples
# generator
# getSecreteKeys
# mysql
# pip
# pkg_resources
# tests