import os

#csv config
TEMP_PATH = '/tmp/'
SCRIPT_FOLDER = ''
CSV_FILENAME = ''
TEMP_FILEPATH = TEMP_PATH+CSV_FILENAME

# S3_BUCKET_FOR_TEMP_SLA = os.environ['S3_BUCKET_FOR_TEMP_REPORT']
def getDirectReportsCsvDetails(report_name):
    if report_name.lower() == 'finalize_report':
        csv_header = [
            'Company Name',
            'KBOX Number',
            'Full Name',
            'Status',
            'Last Login',
            'User Name',
            'Email Address',
            'Groups',
            'Countuserlogin',
            'Deactivated On'
        ]
        fields_mapping = {
            'Company Name': "grc_name",
            'KBOX Number': "KBOX",
            'Full Name': "fullname",
            'Status': "status",
            'Last Login': "last_login",
            'User Name': "uname",
            'Email Address': "emailadd",
            'Groups': "Groups",
            'Countuserlogin': "countuserlogin",
            'Deactivated On': "deactivated_on",
        }
        csv_file_name = 'all_mgw_user_info.csv'

        return {
            "script_folder": 'Database Files',
            "sub_folder": 'All MGW User Info',
            "csv_filename": csv_file_name,
            "csv_header": csv_header,
            "fields_mapping": fields_mapping,
        }
    return {}