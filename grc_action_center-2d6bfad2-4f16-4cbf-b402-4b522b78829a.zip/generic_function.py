from config import *
import time, re, xlsxwriter, json, os, pymysql


def connect_db(db_host=db_host, db_user=db_user, db_pw=db_pw, db_name=db_name):
	print('--- Checking DB Connection --- ')

	response = {}
	response['success'] = "false"

	try:
		# db_conn = mysql.connector.connect(host=db_host, user=db_user, passwd=db_pw, database=db_name)
		db_conn = pymysql.connect(host=db_host, user=db_user, passwd=db_pw, database=db_name)
		#cursor = db_conn.cursor(dictionary=True)
		response['success'] = "true"
		response['message'] = "DB Connection successful."
		response['data'] = db_conn
	except Exception as e:
		print ("Error: ", e)
		response['message'] = str(e)

	return response

def get_sharepoint_configs(report_type=''):
	sharepoint_configs = {}

	print('Inside function : get_sharepoint_configs')
	response = connect_db()

	env = os.environ["ENV"] if 'ENV' in os.environ else ""
	if env == '':
		env = 'DEV'

	if report_type != '':
		env = report_type+'_'+env

	if response["success"] == "true":
		db_conn = response["data"]
		# cursor = db_conn.cursor(dictionary=True)
		cursor = db_conn.cursor(pymysql.cursors.DictCursor)

		sel_query = "select `site_name`, `doc_base_library` from report_config where env = %s and is_deleted = %s"
		args = (str(env),'0')
		cursor.execute(sel_query,args)
		result = cursor.fetchall()
		if len(result) > 0:
			for row in result:
				sharepoint_configs = row

	return sharepoint_configs

def get_select_query(table_name, records, mapping_field, identifiers):
    if not records or not identifiers:
        return None
    cols = ",".join([mapping_field[key] for key in identifiers])
    where_clause_or = []
    for row in records:
        conditions = []
        for key in identifiers:
            value = row[key]
            if isinstance(value, int):
                conditions.append(f"{mapping_field[key]}={value}")
            else:
                conditions.append(f"{mapping_field[key]}={json.dumps(value)}")  # Auto quotes
        where_clause_or.append(f"({' AND '.join(conditions)})")
    whereclause_str = " OR ".join(where_clause_or)
    query = f"SELECT {cols} FROM {table_name} WHERE {whereclause_str}"
    return query