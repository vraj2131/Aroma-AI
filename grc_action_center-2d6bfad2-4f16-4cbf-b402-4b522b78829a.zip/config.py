import os
from getSecretFunc import *

script_env = os.environ["ENV"]

SM_KEYS = get_cchub_db_secret()

cchub_db_config = {
	'host': SM_KEYS["host"],
	'user': SM_KEYS["username"],
	'password': SM_KEYS["password"],
	'database': SM_KEYS["database"],
}

db_configs = get_mysql_secret()
db_host = db_configs['host']
db_user = db_configs['username']
db_pw = db_configs['password']
db_name = db_configs['database']

SM_KEYS1 = get_webseal_db_secret()
webseal_db_config = {
	'host': SM_KEYS1["host"],
	'user': SM_KEYS1["username"],
	'password': SM_KEYS1["password"],
	'database': SM_KEYS1["database"]
}


tables_to_sync = [
    ("kbox_list", "primary_id"),
    ("kboxprocess", "processId"),
    ("reportabuse", "primaryId"),
    ("rocentry", "primaryId"),
    ("saq_asv_scan", "primaryId"),
    ("iso_certificate_mgmt", "primary_id"),
    ("csa_star_mgmt", "primary_id")
]

# sharepoint_configs = get_sharepoint_secret()

# if script_env.lower() != 'dev':
#     sharepoint_configs = json.loads(sharepoint_configs['details'])
# sharepoint_host = sharepoint_configs['host']
# o365_username = sharepoint_configs['username']
# o365_password = sharepoint_configs['password']
sharepoint_host = "https://controlcaseint.sharepoint.com"
o365_username = "cc-api-user@controlcase.com"
o365_password = "SOjhg1DpmVt2LuFymnsH2"
azure_secret_name = os.environ["AZURE_APP_CRED_LOC"]

AZURE_CRED = get_secret(azure_secret_name)

AZURE_APP_CLIENT_ID = AZURE_CRED["AZURE_APP_CLIENT_ID"]
AZURE_APP_CLIENT_SECRET = AZURE_CRED["AZURE_APP_CLIENT_SECRET"]
AZURE_APP_TENANT_ID = AZURE_CRED["AZURE_APP_TENANT_ID"]


azure_sharepoint_host = "https://controlcasetest.sharepoint.com"
azure_sharepoint_site_url = azure_sharepoint_host+"/sites/TestAutomation"