import boto3
import base64
import json
import os

from botocore.exceptions import ClientError

db_secret_name = os.environ["DB_SECRET_NAME"]
sharepoint_secret_name = os.environ["SHAREPOINT_SECRET_NAME"]

def get_smptp_secret():
    return get_secret(os.environ["SMTP_SECRET"])

def get_mysql_secret():
    return get_secret(db_secret_name)

def get_cchub_db_secret():
    return get_secret(os.environ["CCHUB_DB"])

def get_webseal_db_secret():
    return get_secret(os.environ["WEBSEAL_DB"])

def get_sharepoint_secret():
    return get_secret(sharepoint_secret_name)

def get_secret(secret_name):

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=os.environ["SECRET_REGION_NAME"]
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )

    except ClientError as e:

        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.

        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            secret_details = json.loads(secret)
            # configs = json.loads(secret_details['details'])
            # return_config = configs
            return_config = secret_details
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            return_config = decoded_binary_secret

    return return_config
