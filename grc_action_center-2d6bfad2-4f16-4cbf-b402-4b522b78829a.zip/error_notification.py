import os
import boto3
import base64
import json
import smtplib
from enum import Enum
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from getSecretFunc import get_smptp_secret

class EmailConfig(Enum):

    smtp_configs = get_smptp_secret()

    if 'details' in smtp_configs:

        smtp_host_json = json.loads(smtp_configs['details'])
        MAIL_CONFIG = {
                "host":smtp_host_json["host"],
                "port":smtp_host_json["port"],
                "username":smtp_host_json["user"],
                "password":smtp_host_json["pass"]

    	}
    elif "host" in smtp_configs:

        MAIL_CONFIG = {
                "host":smtp_configs["host"],
                "port":smtp_configs["port"],
                "username":smtp_configs["username"],
                "password":smtp_configs["password"]

        }

    host = MAIL_CONFIG["host"]
    port = MAIL_CONFIG["port"]
    username = MAIL_CONFIG["username"]
    password = MAIL_CONFIG["password"]


class TodoFailureMailer:

    MAIL_HOST = ""
    MAIL_PORT = ""
    MAIL_USER = ""
    MAIL_PASSWORD = ""
    RECIPIENT_EMAIL = ""

    def __init__(self, MAIL_CONFIG):
        self.MAIL_HOST = MAIL_CONFIG['host']
        self.MAIL_PORT = MAIL_CONFIG['port']
        self.MAIL_USER = MAIL_CONFIG['username']
        self.MAIL_PASSWORD = MAIL_CONFIG['password']
        self.RECIPIENT_EMAIL = os.getenv("NOTIFICATION_MAIL") # mail for sent the failure notification

    def normalize(self, error_details):
        """
        Method to normalize the error details whether they come in raw JSON or as an Exception.
        """
        # If the error details are in JSON format, parse and extract relevant information
        if isinstance(error_details, str):
            try:
                error_json = json.loads(error_details)  # Try parsing the string as JSON
                error_message = error_json.get('message', 'No error message provided')
                error_code = error_json.get('code', 'No error code provided')
                additional_info = error_json.get('details', 'No additional details provided')
                stack_trace = ''
            except json.JSONDecodeError:
                # If it's not valid JSON, fall back to treating it as a string
                error_message = error_details
                error_code = ''
                additional_info = ''
                stack_trace = ''
        elif isinstance(error_details, Exception):
            # If it's an exception, normalize the error message and stack trace
            import traceback
            error_message = str(error_details)
            stack_trace = traceback.format_exc()
            error_code = ''
            additional_info = ''
        else:
            # Default case for non-JSON, non-Exception errors
            error_message = str(error_details)
            error_code = ''
            additional_info = ''
            stack_trace = ''
        
        # Clean up the stack trace for email readability
        stack_trace_clean = "\n".join([line for line in stack_trace.splitlines() if "your_project" not in line])

        # Constructing a normalized error message
        normalized_error = f"Error Message: {error_message}\nError Code: {error_code}\nAdditional Info: {additional_info}\n\nStack Trace:\n{stack_trace_clean}"
        
        return normalized_error

    def draft_failure_email(self, event, error_details):
        lambda_function_name = os.getenv("AWS_LAMBDA_FUNCTION_NAME")
        normalized_error = self.normalize(error_details)
        event_normalized = str(event)
        
        """
        Method to send a failure notification email when a todo task fails.
        """
        SENDER = self.MAIL_USER
        SUBJECT = f"Lambda Function Error: '{lambda_function_name}'"
        BODY_HTML = f"""
        <p><strong>Event Data:</strong></p>
        <pre>{event_normalized}</pre>
        <p><strong>Error Details:</strong></p>
        <pre>{normalized_error}</pre>
        <p>Please look into this issue and resolve it at the earliest.</p>
        """

        try:
            # Create a secure connection with the mail server
            with smtplib.SMTP(self.MAIL_HOST, self.MAIL_PORT) as server:
                server.login(self.MAIL_USER, self.MAIL_PASSWORD)

                # Prepare the email message
                message = MIMEMultipart("alternative")
                message["Subject"] = SUBJECT
                message["From"] = SENDER
                message["To"] = self.RECIPIENT_EMAIL

                # Attach the body of the email in HTML format
                part = MIMEText(BODY_HTML, "html")
                message.attach(part)

                # Send the email to the recipient
                server.sendmail(SENDER, self.RECIPIENT_EMAIL, message.as_string())
                print(f"Failure email sent to {self.RECIPIENT_EMAIL}")

        except Exception as err:
            import traceback
            print(traceback.format_exc())
            print(f"Failed to send email: {str(err)}")
            return False
        else:
            return True


def draft_failure_email(event, error_details):
    try:
        config = {
            "host": EmailConfig.host.value,
            "port": EmailConfig.port.value,
            "username": EmailConfig.username.value,
            "password": EmailConfig.password.value,
        }

        rpt = TodoFailureMailer(config)
        status = rpt.draft_failure_email(event, error_details)
        return status
        
    except Exception as e:
        import traceback
        print(traceback.format_exc())
        return False