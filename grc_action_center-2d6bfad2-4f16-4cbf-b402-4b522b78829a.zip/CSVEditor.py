import time
import boto3
import botocore
import csv
import os
import requests
from msal import ConfidentialClientApplication

from config import AZURE_APP_CLIENT_ID, AZURE_APP_CLIENT_SECRET, AZURE_APP_TENANT_ID, azure_sharepoint_host, azure_sharepoint_site_url


class CSVEditor:

    script_date = None
    s3 = None
    s3_file_name = None

    SCRIPT_FOLDER = ''
    SUB_FOLDER = ''
    CSV_FILENAME = ''
    CSV_HEADERS = ''
    TEMP_FILEPATH = ''
    SHAREPOINT_DOC_FOLDER = ''

    SHAREPOINT_BASE_URL = azure_sharepoint_host
    SHAREPOINT_Site_URL = ''
    S3_BUCKET_FOR_TEMP_SLA = ''

    AZURE_APP_CLIENT_ID = AZURE_APP_CLIENT_ID
    AZURE_APP_CLIENT_SECRET = AZURE_APP_CLIENT_SECRET
    AZURE_APP_TENANT_ID = AZURE_APP_TENANT_ID

    def __init__(self, report_config={}, TEMP_PATH='/tmp/'):
        self.S3_BUCKET_FOR_TEMP_SLA = os.environ['S3_BUCKET_FOR_TEMP_REPORT']
        if not self.S3_BUCKET_FOR_TEMP_SLA:
            raise ValueError("S3_BUCKET_FOR_TEMP_REPORT environment variable is not set.")

        self.s3 = boto3.resource('s3')
        self.script_date = time.strftime('%Y-%m-%d')

        if len(report_config) > 0:
            self.SCRIPT_FOLDER = report_config["script_folder"]
            self.SUB_FOLDER = report_config.get("sub_folder", "")
            self.CSV_FILENAME = report_config["csv_filename"]
            self.CSV_HEADERS = report_config["csv_header"]
            self.TEMP_FILEPATH = TEMP_PATH + self.CSV_FILENAME

            self.SHAREPOINT_BASE_URL = azure_sharepoint_host
            self.SHAREPOINT_Site_URL = azure_sharepoint_site_url

            self.SHAREPOINT_DOC_FOLDER = report_config["doc_base_library"]

        self.s3_file_name = f"{self.SCRIPT_FOLDER}/{self.script_date}/{self.CSV_FILENAME}"
        self.access_token = self.graph_authentication()

    def graph_authentication(self):
        app = ConfidentialClientApplication(
            client_id=self.AZURE_APP_CLIENT_ID,
            client_credential=self.AZURE_APP_CLIENT_SECRET,
            authority=f"https://login.microsoftonline.com/{self.AZURE_APP_TENANT_ID}"
        )

        result = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
        if "access_token" in result:
            print("Graph API authenticated successfully")
            return result["access_token"]
        else:
            raise Exception(f"Graph API auth failed: {result.get('error_description')}")

    def csvExist(self):
        try:
            self.s3.Object(self.S3_BUCKET_FOR_TEMP_SLA, self.s3_file_name).load()
            return True
        except botocore.exceptions.ClientError as e:
            return False if e.response['Error']['Code'] == "404" else False

    def deleteOldCSV(self, filename):
        self.s3.Object(self.S3_BUCKET_FOR_TEMP_SLA, filename).delete()

    def createCSVWithHeaders(self):
        with open(self.TEMP_FILEPATH, 'w') as f:
            writer = csv.writer(f)
            writer.writerow(self.CSV_HEADERS)

        self.s3.Bucket(self.S3_BUCKET_FOR_TEMP_SLA).upload_file(self.TEMP_FILEPATH, self.s3_file_name)
        return self.s3_file_name

    def writeDataToCSV(self, report_data):
        if os.path.exists(self.TEMP_FILEPATH):
            os.remove(self.TEMP_FILEPATH)

        self.s3.Bucket(self.S3_BUCKET_FOR_TEMP_SLA).download_file(self.s3_file_name, self.TEMP_FILEPATH)

        with open(self.TEMP_FILEPATH, mode='a', newline='') as f:
            writer = csv.writer(f)
            writer.writerows(report_data)

        self.s3.Bucket(self.S3_BUCKET_FOR_TEMP_SLA).upload_file(self.TEMP_FILEPATH, self.s3_file_name)
        return self.s3_file_name

    def check_sharepoint_authentication(self):
        return bool(self.access_token)

    def upload_s3_report_to_sharepoint(self, report_type=''):
        if not self.csvExist():
            print("CSV does not exist in S3.")
            return False

        if os.path.exists(self.TEMP_FILEPATH):
            os.remove(self.TEMP_FILEPATH)

        self.s3.Bucket(self.S3_BUCKET_FOR_TEMP_SLA).download_file(self.s3_file_name, self.TEMP_FILEPATH)

        folders_to_create = []
        if report_type == '':
            folders_to_create = [
                {"folder_name": self.script_date, "parent": self.SHAREPOINT_DOC_FOLDER},
                {"folder_name": "Power BI", "parent": self.SHAREPOINT_DOC_FOLDER}
            ]
            upload_path = f"{self.SHAREPOINT_DOC_FOLDER}/{self.script_date}/{self.CSV_FILENAME}"
        else:
            base_path = f"{self.SHAREPOINT_DOC_FOLDER}/{self.SCRIPT_FOLDER}"
            if self.SUB_FOLDER:
                folders_to_create.append({"folder_name": self.SUB_FOLDER, "parent": base_path})
                upload_path = f"{base_path}/{self.SUB_FOLDER}/{self.CSV_FILENAME}"
            else:
                upload_path = f"{base_path}/{self.CSV_FILENAME}"

        for folder in folders_to_create:
            self.create_folder_at_sharepoint(folder["parent"], folder["folder_name"])

        upload_url = f"https://graph.microsoft.com/v1.0/sites/{self.get_site_id()}/drive/root:/{upload_path}:/content"
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/octet-stream"
        }

        with open(self.TEMP_FILEPATH, 'rb') as file_data:
            response = requests.put(upload_url, headers=headers, data=file_data.read())

        if response.status_code in [200, 201]:
            print("File uploaded to SharePoint successfully.")
            return True
        else:
            print(f"Upload failed: {response.status_code} {response.text}")
            return False

    def create_folder_at_sharepoint(self, parent_folder, folder_name):
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }

        create_url = f"https://graph.microsoft.com/v1.0/sites/{self.get_site_id()}/drive/root:/{parent_folder}:/children"
        payload = {
            "name": folder_name,
            "folder": {},
            "@microsoft.graph.conflictBehavior": "replace"
        }

        response = requests.post(create_url, headers=headers, json=payload)
        if response.status_code in [200, 201, 409]:
            print(f"Folder '{folder_name}' created or already exists.")
            return True
        else:
            print(f"Error creating folder: {response.status_code} {response.text}")
            return False

    def get_site_id(self):
        domain = self.SHAREPOINT_Site_URL.split("/sites/")[0].replace("https://", "")
        site_path = self.SHAREPOINT_Site_URL.split("/sites/")[1]
        url = f"https://graph.microsoft.com/v1.0/sites/{domain}:/sites/{site_path}"

        headers = {"Authorization": f"Bearer {self.access_token}"}
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            return response.json()["id"]
        else:
            raise Exception(f"Could not fetch site ID: {response.status_code} {response.text}")
