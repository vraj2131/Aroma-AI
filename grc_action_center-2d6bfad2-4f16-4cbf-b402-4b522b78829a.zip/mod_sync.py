import mysql.connector
from mysql.connector import Error
from datetime import datetime, timedelta
import logging
import time
import uuid
from config import *
from csv_config import getDirectReportsCsvDetails
import os
from CSVEditor import CSVEditor
from generic_function import get_sharepoint_configs

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Suppress MySQL connector plugin logs
for logger_name in logging.root.manager.loggerDict:
    if logger_name.startswith("mysql"):
        logging.getLogger(logger_name).setLevel(logging.WARNING)

class DatabaseConnection:
    def __init__(self, config):
        self.config = config
        self.connection = None

    def connect(self):
        try:
            self.connection = mysql.connector.connect(**self.config)
            logging.info(f"Connected to {self.config['database']} successfully.")
        except Error as e:
            logging.error(f"Error connecting to database {self.config['database']}: {e}")
            raise

    def execute(self, query, params=None, fetch=False):
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute(query, params or ())
            if fetch:
                return cursor.fetchall()
            else:
                self.connection.commit()
        except Error as e:
            logging.error(f"SQL Error: {e} | Query: {query} | Params: {params}")
            return None

    def close(self):
        if self.connection and self.connection.is_connected():
            self.connection.close()
            logging.info(f"Connection to {self.config['database']} closed.")

    def fetch_rows(self, table_name):
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = f"SELECT * FROM {table_name} WHERE bkstatus = 0"
            cursor.execute(query)
            return cursor.fetchall()
        except Error as e:
            logging.error(f"Error fetching rows from {table_name}: {e}")
            raise

    def upsert_rows(self, table_name, rows, primary_key):
        if not rows:
            logging.info(f"No rows to sync for {table_name}.")
            return

        try:
            cursor = self.connection.cursor()
            # Remove 'bkstatus' from insert/update
            columns = [col for col in rows[0].keys() if col != 'bkstatus']
            col_names = ", ".join(columns)
            placeholders = ", ".join(["%s"] * len(columns))
            update_clause = ", ".join([f"{col}=VALUES({col})" for col in columns if col != primary_key])

            query = (
                f"INSERT INTO {table_name} ({col_names}) VALUES ({placeholders}) "
                f"ON DUPLICATE KEY UPDATE {update_clause}"
            )

            values = [tuple(row[col] for col in columns) for row in rows]
            cursor.executemany(query, values)
            self.connection.commit()
            logging.info(f"{cursor.rowcount} rows upserted into {table_name}")
        except Error as e:
            logging.error(f"Error upserting rows into {table_name}: {e}")
            raise

    def mark_synced(self, table_name, ids, primary_key):
        if not ids:
            return
        try:
            cursor = self.connection.cursor()
            format_strings = ','.join(['%s'] * len(ids))
            query = f"UPDATE {table_name} SET bkstatus = 1 WHERE {primary_key} IN ({format_strings})"
            cursor.execute(query, ids)
            self.connection.commit()
            logging.info(f"Marked {cursor.rowcount} rows as synced in {table_name}")
        except Error as e:
            logging.error(f"Error updating bkstatus in {table_name}: {e}")
            raise

class TableSync:
    def __init__(self, source_db, target_db, table_name, primary_key):
        self.source_db = source_db
        self.target_db = target_db
        self.table_name = table_name
        self.primary_key = primary_key

    def sync(self):
        try:
            logging.info(f"--- Starting sync for table: {self.table_name} ---")
            rows = self.source_db.fetch_rows(self.table_name)
            if not rows:
                logging.info("No new records found to sync.")
                return

            self.target_db.upsert_rows(self.table_name, rows, self.primary_key)

            ids = [row[self.primary_key] for row in rows]

            self.source_db.mark_synced(self.table_name, ids, self.primary_key)

        except Exception as e:
            logging.error(f"Error during sync for {self.table_name}: {e}")
        finally:
            logging.info(f"--- Sync completed for table: {self.table_name} ---")



class KboxTableSync:
    def __init__(self, db):
        self.db = db
        self.api_data = {}
        self.added_entries = []
        self.deleted_entries = []

    def log(self, msg, tag='info'):
        if tag == 'info':
            logging.info(msg)
        elif tag == 'error':
            logging.error(msg)

    def get_server_instance_info_for_swf(self, params):
        hour_ago = None
        if params.get('is_cond') and params.get('interval'):
            hour_ago = int((datetime.now() - timedelta(hours=int(params['interval']))).timestamp())


        servers = self.db.execute(
            "SELECT e_id, server_ip, server_port, server_user_name, server_user_password, server_environment FROM prm_grc_server",
            fetch=True
        )
        if not servers:
            return {'result': 'fail', 'data': 'No records are found for Server.'}


        server_info = {s['e_id']: s for s in servers}

        # Build query for instances
        base_query = """
            SELECT g.*, e.status, e.modified_on
            FROM prm_grc g
            JOIN prm_entity e ON g.e_id = e.prm_id
            WHERE g.grc_creation_status IN (6, 35)
        """
        conditions = []
        params_list = []

        if hour_ago:
            conditions.append("e.modified_on >= %s")
            params_list.append(hour_ago)

        if params.get('grc_name'):
            conditions.append("g.grc_name = %s")
            params_list.append(params['grc_name'])

        if conditions:
            base_query += " AND " + " AND ".join(conditions)

        instances = self.db.execute(base_query, params_list, fetch=True)

        if not instances:
            return {'result': 'fail', 'data': 'No records are found for Instance.'}

        status_options = {
            '': 'Select',
            0: 'Enabled',
            1: 'Disabled',
            2: 'Under Maintenance',
            3: 'Deleted',
            4: 'Removed From System',
            5: 'On Hold / Waiting'
        }
        result = {}

        for instance in instances:
            eid = instance['e_id']
            source_server = server_info.get(instance.get('grc_sourcecode_server'), {})
            db_server = server_info.get(instance.get('grc_database_server'), {})
            db8_server = server_info.get(instance.get('grc8_database_server'), {})

            result[eid] = {
                'cccm_client_name': instance['grc_client_name'],
                'cccm_name': instance['grc_name'],
                'cccm_db': instance['grc_db'],
                'cccm_sourcecode_server': instance.get('grc_sourcecode_server'),
                'cccm_database_server': instance.get('grc_database_server'),
                'instance_status': status_options.get(instance['status'],""),
                'instance_status_id': instance['status'],

                'sc_server_ip': source_server.get('server_ip', ''),
                'sc_server_port': source_server.get('server_port', ''),
                'sc_server_user_name': source_server.get('server_user_name', ''),
                'sc_server_user_password': source_server.get('server_user_password', ''),
                'server_environment': source_server.get('server_environment', ''),

                'db_server_ip': db_server.get('server_ip', ''),
                'db_server_port': db_server.get('server_port', ''),
                'db_server_user_name': db_server.get('server_user_name', ''),
                'db_server_user_password': db_server.get('server_user_password', ''),

                'grc8_database_server': db8_server.get('server_ip', '')
            }

        return {'result': 'success', 'data': result}


    def kbox_exists(self, table, clientkbox_db):
        query = f"SELECT * FROM {table} WHERE clientkbox_db = '{clientkbox_db}'"
        result = self.db.execute(query, fetch=True)
        return result[0] if result else None

    def update_kbox_list(self, updates, clientkbox_db):
        if updates:
            set_clause = ', '.join(updates) + ", bkstatus=0"
            query = f"UPDATE kbox_list SET {set_clause} WHERE clientkbox_db = '{clientkbox_db}'"
            self.db.execute(query)
            self.log(f"Updated: {clientkbox_db}", "info")
        else:
            self.log(f"{clientkbox_db} : No details to update")

    def delete_from_kbox_list(self, clientkbox_db):
        query = f"DELETE FROM kbox_list WHERE clientkbox_db = '{clientkbox_db}'"
        self.db.execute(query)
        self.log(f"{clientkbox_db} : Entry deleted from kbox_list", "info")

    def insert_into_kbox_list_prm_status(self, data):
        keys = ', '.join(data.keys())
        values = ', '.join([f"'{str(v)}'" if v is not None else "NULL" for v in data.values()])
        query = f"INSERT INTO kbox_list_prm_status ({keys}) VALUES ({values})"
        self.db.execute(query)

    def add_value_to_kbox_list(self, data):
        keys = ', '.join(data.keys())
        values = ', '.join([f"'{v}'" if v is not None else 'NULL' for v in data.values()])
        query = f"INSERT INTO kbox_list ({keys}) VALUES ({values})"

        try:
            cursor = self.db.connection.cursor()
            cursor.execute(query)
            self.db.connection.commit()
            self.log(f"Inserted into kbox_list: {data.get('clientkbox_db', '')}")
            return cursor.lastrowid  # 🔥 Return the auto-generated primary_id
        except Exception as e:
            self.log(f"Failed to insert into kbox_list: {e}", "error")
            return None


    def sync(self):


        for eid, kbox in self.api_data['data'].items():

            clientkbox_db = kbox['cccm_db']
            client_name = kbox['cccm_client_name'].replace("'", "\\'")
            kbox_name = kbox['cccm_name'].replace("'", "\\'")
            dbhost = kbox['db_server_ip']
            serverNo = kbox.get('server_environment', 0)
            status_msg = kbox['instance_status']
            status_code = kbox['instance_status_id']

            existing_kbox = self.kbox_exists("kbox_list", clientkbox_db)
            kbox_id = existing_kbox['primary_id'] if existing_kbox else None
            status = existing_kbox['status'] if existing_kbox else 0
            bkstatus = existing_kbox['bkstatus'] if existing_kbox else 0

            updates = []
            if existing_kbox:
                if existing_kbox['serverNo'] != serverNo:
                    updates.append(f"serverNo={serverNo}")
                if existing_kbox['client_name'] != client_name:
                    updates.append(f"client_name='{client_name}'")
                if existing_kbox['kbox_name'] != kbox_name:
                    updates.append(f"kbox_name='{kbox_name}'")

            status_code = int(status_code)

            if existing_kbox:
                if status_code == 0:
                    self.update_kbox_list(updates, clientkbox_db)
                    if self.kbox_exists("kbox_list_prm_status", clientkbox_db):
                        self.delete_from_table("kbox_list_prm_status", clientkbox_db)
                else:
                    self.delete_from_kbox_list(clientkbox_db)
                    self.deleted_entries.append({
                        'kbox': kbox_name, 'client': client_name, 'status': status_msg
                    })
                    if self.kbox_exists("kbox_list_prm_status", clientkbox_db):
                        self.update_kbox_list_prm_status(clientkbox_db, kbox_id, client_name, kbox_name, status_code, status_msg)
                    else:
                        self.insert_into_kbox_list_prm_status({
                            'primary_id_kbox_list': kbox_id,
                            'client_name': client_name,
                            'clientkbox_db': clientkbox_db,
                            'kbox_name': kbox_name,
                            'status': status,
                            'serverNo': serverNo,
                            'bkstatus': bkstatus,
                            'prm_status': status_code,
                            'prm_status_details': status_msg
                        })
            else:
                kbox_id = self.add_value_to_kbox_list({
                    'clientkbox_db': clientkbox_db,
                    'client_name': client_name,
                    'kbox_name': kbox_name,
                    'serverNo': serverNo,
                    'status': 0,
                    'bkstatus': 0
                })

                self.insert_into_kbox_list_prm_status({
                    'primary_id_kbox_list': kbox_id,
                    'client_name': client_name,
                    'clientkbox_db': clientkbox_db,
                    'kbox_name': kbox_name,
                    'status': status,
                    'serverNo': serverNo,
                    'bkstatus': bkstatus,
                    'prm_status': status_code,
                    'prm_status_details': status_msg
                })
                self.added_entries.append({
                    'kbox': kbox_name, 'client': client_name, 'status': 'added'
                })

                # Update migrated table
                # self.update_migrated_details(clientkbox_db, dbhost)

    def delete_from_table(self, table, clientkbox_db):
        query = f"DELETE FROM {table} WHERE clientkbox_db = '{clientkbox_db}'"
        self.db.execute(query)

    def update_kbox_list_prm_status(self, clientkbox_db, kbox_id, client_name, kbox_name, status, msg):
        query = f"""UPDATE kbox_list_prm_status SET
            primary_id_kbox_list='{kbox_id}',
            client_name='{client_name}',
            kbox_name='{kbox_name}',
            prm_status='{status}',
            prm_status_details='{msg}'
            WHERE clientkbox_db='{clientkbox_db}'"""
        self.db.execute(query)

    def update_migrated_details(self, clientkbox_db, dbhost):
        record = self.kbox_exists("kbox_list_migrated", clientkbox_db)
        if record:
            if record['dbhost'] != dbhost:
                query = f"UPDATE kbox_list_migrated SET dbhost = '{dbhost}' WHERE clientkbox_db = '{clientkbox_db}'"
                self.db.execute(query)
        else:
            query = f"INSERT INTO kbox_list_migrated (clientkbox_db, dbhost) VALUES ('{clientkbox_db}', '{dbhost}')"
            self.db.execute(query)



class ReportProcessor:

    def __init__(self, report_name):
        self.report_name = report_name
        self.report_config = getDirectReportsCsvDetails(report_name)

    def process_report_data(self, all_user_data):
        if not all_user_data:
            return {"success": False, "msg": f"No data found for the report: {self.report_config.get('csv_filename')}"}

        csv_header = self.report_config.get("csv_header")
        fields_mapping = self.report_config.get("fields_mapping")

        csv_data = []
        for row in all_user_data:
            data = []
            for col in csv_header:
                data.append(row[fields_mapping[col]])
            csv_data.append(data)
        if csv_data:
            sharepoint_configs = {'site_name': 'DEV', 'doc_base_library': 'Team%20Drive/vertical%20report/OPA/Connectwise'}
            sharepoint_host = "https://controlcaseint.sharepoint.com"

            self.report_config.update({
                "sharepoint_host": sharepoint_host,
                'sharepoint_site_url': f"{sharepoint_host}/sites/{sharepoint_configs['site_name']}",
                "doc_base_library": sharepoint_configs['doc_base_library']
            })
            fn_obj = CSVEditor(self.report_config)

            if fn_obj.csvExist():
                fn_obj.deleteOldCSV(fn_obj.s3_file_name)
            fn_obj.createCSVWithHeaders()
            s3_file_name = fn_obj.writeDataToCSV(csv_data)
            error = fn_obj.upload_s3_report_to_sharepoint('BI')

            return {"success": error, "msg": s3_file_name}
        else:
            return {"success": False, "msg": "CSV data preparation failed."}

GRC_QUERY = """
    SELECT 
        pg.grc_name, 
        pg.grc_db, 
        pgs.server_ip, 
        pgs.server_port,
        pgs.server_user_name,
        pgs.server_user_password,
        pgs.server_environment
    FROM prm_grc AS pg 
    LEFT JOIN prm_entity AS pe ON pg.e_id = pe.prm_id 
    LEFT JOIN prm_grc_server AS pgs ON pg.grc_database_server = pgs.e_id 
    WHERE pgs.server_environment = 0 
    AND (pg.grc_creation_status = 6 OR pg.grc_creation_status = 35) 
    AND pe.set_type = 'instance' 
    AND pe.status IN (0, 1, 2)
"""

COLUMN_CHECK_QUERY = """
    SELECT COUNT(*) AS col_count
    FROM information_schema.COLUMNS 
    WHERE TABLE_SCHEMA = %s 
    AND TABLE_NAME = 'mgw_users' 
    AND COLUMN_NAME = 'deactivated_on'
"""

class MGWUserFetcher:

    def __init__(self, report_name):
        self.report_name = report_name
        self.processor = ReportProcessor(report_name)
    
    def fetch_db_entries(self):
        main_db = DatabaseConnection(cchub_db_config)
        main_db.connect()
        db_entries = main_db.execute(GRC_QUERY, fetch=True)
        response_id = str(uuid.uuid4())
        main_db.close()
        return {"db_entries": db_entries, "response_id": response_id}
    
    def process_single_db_entry(self, event):
        entry = event.get("db_entry")
        if not entry:
            return {"success": False, "msg": "Missing db_entry"}
        else:
            try:
                response_id = event.get("response_id")
                grc_name = entry["grc_name"]
                grc_db = entry["grc_db"]
                server_ip = entry["server_ip"]
                server_port = entry["server_port"]
                server_user = entry["server_user_name"]
                server_pass = (
                    "uQ!szELroYn!rylS2QR@5Cs" if entry.get("server_environment") == 1
                    else "C0ntr0lC@s3GrC7Pr0dInD!@C@n@D@"
                )
                dynamic_config = {
                    'host': server_ip,
                    'user': server_user,
                    'password': server_pass,
                    'database': grc_db,
                    'port': int(server_port)
                }

                db = DatabaseConnection(dynamic_config)
                db.connect()
                col_check = db.execute(COLUMN_CHECK_QUERY, params=(grc_db,), fetch=True)
                has_deactivated_on = col_check[0]["col_count"] > 0

                user_query = self.get_user_query(has_deactivated_on)
                results = db.execute(user_query, fetch=True)
                db.close()

                main_db = DatabaseConnection(cchub_db_config)
                main_db.connect()

                for user in results:
                    sql = """
                        INSERT INTO staging_mgw_users
                        (grc_name, KBOX, fullname, status, last_login, uname, emailadd, `Groups`, countuserlogin, deactivated_on, Response_ID)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                    values = (
                        grc_name,
                        grc_db,
                        user.get('fullname', ''),
                        user.get('status', ''),
                        user.get('lastlogin', ''),
                        user.get('uname', ''),
                        user.get('emailadd', ''),
                        user.get('Groups', ''),
                        user.get('countuserlogin', ''),
                        user.get('deactivated_on') if user.get('status') == 3 else None,
                        response_id
                    )

                    main_db.execute(sql, values)

                main_db.close()
                return {"success": True, "msg": grc_name, "response_id": response_id}

            except Exception as e:
                if "Access denied" in str(e):
                    return {"success": False, "msg": f"Skipping unauthorized DB {grc_db}", "response_id": None}
                else:
                    return {"success": False, "msg": str(e), "response_id": None}
    def finalize_report(self, response_id):
        staging_db = DatabaseConnection(cchub_db_config)
        staging_db.connect()
        if response_id:
            query = "SELECT * FROM staging_mgw_users WHERE Response_ID = %s"
            all_user_data = staging_db.execute(query, params=(response_id,), fetch=True)
        staging_db.close()
        fetcher = ReportProcessor(report_name="finalize_report")
        response = fetcher.process_report_data(all_user_data)
        return response

    def get_user_query(self, has_deactivated):
        if has_deactivated:
            return """
                SELECT 
                    CONCAT(mu.firstname, ' ', mu.lastname) AS fullname,
                    mu.level AS status,
                    mu.username AS uname,
                    mu.email AS emailadd,
                    mu.lastin AS lastlogin,
                    GROUP_CONCAT(mg.name) AS `Groups`,
                    (SELECT COUNT(user_id) FROM mgw_user_track WHERE user_id = mu.id) AS countuserlogin,
                    mu.deactivated_on
                FROM mgw_users mu
                LEFT JOIN mgw_groups_members mgm ON mu.id = mgm.userid
                LEFT JOIN mgw_groups mg ON mgm.groupid = mg.id
                WHERE mu.id <> mu.username AND mu.level IN (9,3)
                GROUP BY mu.id
            """
        else:
            return """
                SELECT 
                    CONCAT(mu.firstname, ' ', mu.lastname) AS fullname,
                    mu.level AS status,
                    mu.username AS uname,
                    mu.email AS emailadd,
                    mu.lastin AS lastlogin,
                    GROUP_CONCAT(mg.name) AS `Groups`,
                    (SELECT COUNT(user_id) FROM mgw_user_track WHERE user_id = mu.id) AS countuserlogin
                FROM mgw_users mu
                LEFT JOIN mgw_groups_members mgm ON mu.id = mgm.userid
                LEFT JOIN mgw_groups mg ON mgm.groupid = mg.id
                WHERE mu.id <> mu.username AND mu.level = 9
                GROUP BY mu.id
            """

operation_config = {
    "add_user": {"table": "prm_user_add_activity_data"},
    "offboard_user": {"table": "prm_offboard_user_activity"}
}

operation_labels = {
    "add_user": "ADD",
    "offboard_user": "Remove"
}
class JobProcessor:
    def __init__(self):
        pass

    def job__get_entities_to_process(self, status):
        now_ts = int(time.time())
        thirty_mins_ago = now_ts - (30 * 60)
        main_db = DatabaseConnection(cchub_db_config)
        main_db.connect()
        print(status, status, thirty_mins_ago, now_ts)
        query = """
            SELECT e.prm_id, a.id, a.activity_title AS set_type, e.modified_on
            FROM prm_entity e
            JOIN prm_activities a ON a.e_id = e.prm_id
            WHERE e.status = %s 
              AND a.status = %s
              AND e.modified_on BETWEEN %s AND %s
        """
        entities = main_db.execute(query, (status, status, thirty_mins_ago, now_ts), fetch=True)
        main_db.close()
        return {
            "success": True,
            "todo": "job__get_entities_to_process",
            "count": len(entities),
            "entities": entities
        }
    
    def job__get_kbox_for_entity(self, data):
        main_db = DatabaseConnection(cchub_db_config)
        main_db.connect()
        results = []
        for rec in data:
            table_name = operation_config[rec["set_type"]]["table"]
            query = f"""
                SELECT email, kbox_id
                FROM {table_name}
                WHERE e_id = %s AND status = 5
            """
            rows = main_db.execute(query, (rec["prm_id"],), fetch=True)

            email_map = {}
            for r in rows:
                if not r["kbox_id"] or str(r["kbox_id"]) == "0":
                    continue
                email_map.setdefault(r["email"], []).append(str(r["kbox_id"]))
            results.append({
                "prm_id": rec["prm_id"],
                "set_type": rec["set_type"],
                "email_kbox_map": email_map
            })
        main_db.close()
        return {
            "success": True,
            "todo": "job__get_kbox_for_entity",
            "results": results
        }

    def job__create_job_and_queue(self, data):
        job_ids = []
        entity_ids = []
        jobq_count = 0
        main_db = DatabaseConnection(cchub_db_config)
        main_db.connect()
        try:
            cursor = main_db.connection.cursor()
            for rec in data:
                op_label = operation_labels[rec["set_type"]]
                for email, kbox_ids in rec["email_kbox_map"].items():
                    job_query = """
                        INSERT INTO action_job_table (email, kbox, operation, status, comment)
                        VALUES (%s, %s, %s, %s, %s)
                    """
                    kbox_str = ",".join(f"ClientK{kid}" for kid in sorted(kbox_ids))
                    cursor.execute(job_query, (email, kbox_str, op_label, "Pending", ""))
                    job_id = cursor.lastrowid 
                    job_ids.append(job_id)
                    entity_ids.append(rec["prm_id"])

                    job_queue_data = [
                        (job_id, email, f"ClientK{kid}", op_label, "Pending", "")
                        for kid in sorted(kbox_ids)
                    ]
                    queue_query = """
                        INSERT INTO action_job_queue (job_id, email, kbox, operation, status, comment)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """
                    cursor.executemany(queue_query, job_queue_data)
                    jobq_count += len(job_queue_data)

            main_db.connection.commit()
            main_db.close()
            return {
                "success": True,
                "job_ids": job_ids,
                "jobq_created_count": jobq_count,
                "entity_ids": entity_ids
            }

        except Exception as e:
            logging.error(f"Error in job__create_job_and_queue: {e}")
            raise


    def job__update_job_and_queue_status(self, job_ids, status, entity_ids=None):
        if not job_ids:
            return {
                "success": False,
                "todo": "job__update_job_and_queue_status",
                "error": "No job_ids provided"
            }

        main_db = DatabaseConnection(cchub_db_config)
        main_db.connect()
        try:
            job_id_placeholders = ",".join(["%s"] * len(job_ids))
            job_update_query = f"""
                UPDATE action_job_table SET status = %s WHERE id IN ({job_id_placeholders})
            """
            main_db.execute(job_update_query, tuple([status] + job_ids))
            queue_update_query = f"""
                UPDATE action_job_queue SET status = %s WHERE job_id IN ({job_id_placeholders})
            """
            main_db.execute(queue_update_query, tuple([status] + job_ids))

            main_db.connection.commit()
            main_db.close()

            return {
                "success": True,
                "job_ids": job_ids,
                "new_status": status,
                "entity_ids": entity_ids
            }

        except Exception as e:
            logging.error(f"Error in job__update_job_and_queue_status: {e}")
            raise


    def job__update_entity_and_activity_status(self, entity_ids, status):
        main_db = DatabaseConnection(cchub_db_config)
        main_db.connect()
        try:
            # Update prm_entity
            if entity_ids:
                entity_update_query = """
                    UPDATE prm_entity SET status = %s WHERE prm_id IN (%s)
                """ % ("%s", ",".join(["%s"] * len(entity_ids)))
                main_db.execute(entity_update_query, tuple([status] + entity_ids))

                activity_update_query = """
                    UPDATE prm_activities SET status = %s WHERE e_id IN (%s)
                """ % ("%s", ",".join(["%s"] * len(entity_ids)))
                main_db.execute(activity_update_query, tuple([status] + entity_ids))

            main_db.connection.commit()
            main_db.close()
            return {
                "success": True,
                "msg": "Entity and activity status updated successfully"
            }
        except Exception as e:
            logging.error(f"Error in job__update_entity_and_activity_status: {e}")
            raise