import json
import os
import traceback
from error_notification import draft_failure_email

from config import *
from mod_sync import DatabaseConnection, TableSync, KboxTableSync, MGWUserFetcher, JobProcessor

def lambda_handler(event, context):

    ## -- Get step to do -- ##
    print("event------")
    print(event)
    todo = ''

    if 'body' in event :
        event = json.loads(event['body'])
    if 'todo' in event:
        todo = event["todo"]

    response = {"msg":""}

    try:

        response = {"msg":"Execution completed"}

        if todo =="sync_webseal":

            source_db = DatabaseConnection(cchub_db_config)
            target_db = DatabaseConnection(webseal_db_config)

            source_db.connect()
            target_db.connect()

            for table_name, primary_key in tables_to_sync:
                sync_job = TableSync(source_db, target_db, table_name, primary_key)
                sync_job.sync()
            source_db.close()
            target_db.close()

            response = {"msg":"webseal has been synced"}

        if todo =="sync_kbox_list":

            params = {
                'interval': event.get("interval", 24)
            }

            db = DatabaseConnection(cchub_db_config)
            db.connect()

            sync = KboxTableSync(db)
            api_data = sync.get_server_instance_info_for_swf(params)

            if api_data['result'] == 'success':
                sync.api_data = api_data
                sync.sync()

            db.close()

            response = {"msg":"kbox list has been synced"}

        elif todo == "fetch_db_entries":
            fetcher = MGWUserFetcher(report_name="fetch_db_entries")
            result = fetcher.fetch_db_entries()
            response = {
                "msg": "Database entries fetched",
                "success": True,
                "db_entries": result.get("db_entries"),
                "response_id": result.get("response_id")
            }

        elif todo == "process_single_db_entry":
            fetcher = MGWUserFetcher(report_name="process_single_db_entry")
            result = fetcher.process_single_db_entry(event)
            response = {
                "msg": "Single database entry processed",
                "success": result.get("success", False),
                "response_id": result.get("response_id"),
                "db_name": result.get("msg")
            }

        elif todo == "finalize_report":
            fetcher = MGWUserFetcher(report_name="finalize_report")
            result = fetcher.finalize_report(event.get("response_id"))
            response = {
                "msg": "User details fetched",
                "csv_path": result.get("msg"),
                "success": result.get("success", False),
                "response_id": event.get("response_id")
            }


        elif todo == "job__get_entities_to_process":
            job_processor = JobProcessor()
            response = job_processor.job__get_entities_to_process(event.get("status", 5))

        elif todo == "job__get_kbox_for_entity":
            job_processor = JobProcessor()
            response = job_processor.job__get_kbox_for_entity(event.get("data"))

        elif todo == "job__create_job_and_queue":
            job_processor = JobProcessor()
            response = job_processor.job__create_job_and_queue(event.get("data"))

        elif todo == "job__update_job_and_queue_status":
            job_processor = JobProcessor()
            response = job_processor.job__update_job_and_queue_status(
                event.get("job_id"), event.get("status"), event.get("entity_ids")
            )

        elif todo == "job__update_entity_and_activity_status":
            job_processor = JobProcessor()
            response = job_processor.job__update_entity_and_activity_status(
                event.get("entity_ids"), event.get("status")
            )
        
        else:
            response = {"error": "Invalid todo"}

    except Exception as e:
        import traceback
        status = draft_failure_email(event, traceback.format_exc())
        print(f"failure mail sent - {status}")
        raise Exception("Dev exception") from e

    return {
        'statusCode': 200,
        'headers': { 'Content-Type': 'application/json' },
        'body': json.dumps(response)
    }
